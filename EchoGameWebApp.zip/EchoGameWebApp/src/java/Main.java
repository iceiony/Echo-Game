
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import javax.swing.*;



import services.AdminService;

/**
 * Initial code
 * User: Alan P. Sexton
 * Date: 16-Mar-2008
 * Time: 19:59:24
 *
 * Modified by
 * User: Adrian Ionita
 * Date: 2-Jul-2010
 * Time: 3:31:00
 */
public class Main {

    public static void main(String[] args) {
        String command;
        JOptionPane pane = new JOptionPane("Create new database?",
                JOptionPane.QUESTION_MESSAGE,
                JOptionPane.YES_NO_OPTION,
                null);
        JDialog d = pane.createDialog(null, "Database Creation");

        d.setVisible(true);
        command = "create";
        Integer returnValue = (Integer) pane.getValue();
        d.dispose();

        if (returnValue == null) {
            System.err.println("Program was cancelled. Will exit");
            System.exit(1);
        }

        if (returnValue != JOptionPane.YES_OPTION) {
            command = "resetAdmin";
            pane = new JOptionPane("Reset 'admin' password ?",
                    JOptionPane.QUESTION_MESSAGE,
                    JOptionPane.YES_NO_OPTION,
                    null);
            d = pane.createDialog(null, "Database Creation");
            d.setVisible(true);
            returnValue = (Integer) pane.getValue();
            d.dispose();
            if (returnValue == null) {
                System.err.println("Program was cancelled. Will exit");
                System.exit(1);
            }

            if (returnValue != JOptionPane.YES_OPTION) {
                command = "clearBehaviour";
                pane = new JOptionPane("Clear UserIndicatorValues ? No will delete the database.",
                        JOptionPane.QUESTION_MESSAGE,
                        JOptionPane.YES_NO_OPTION,
                        null);
                d = pane.createDialog(null, "Database Creation");
                d.setVisible(true);
                returnValue = (Integer) pane.getValue();
                d.dispose();
                if (returnValue == null) {
                    System.err.println("Program was cancelled. Will exit");
                    System.exit(1);
                }
                  if (returnValue != JOptionPane.YES_OPTION) {
                      command="drop";
                  }
            }

        }



        ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
        AdminService service = (AdminService) context.getBean("adminService");
        try {
            if ("create".equals(command)) {
                service.createDB(context);
            } else if ("drop".equals(command)) {
                service.dropDB();
            } else if ("resetAdmin".equals(command)) {
                service.resetAdminPassword(context);
            } else if (("clearBehaviour").equals(command)) {
                service.clearBehaviour();
            }
        } catch (Exception e) {
            System.err.println("Error: " + e.getMessage());
            System.exit(1);
        }
        System.exit(0);
    }

    /**
     * Shows a dialog box for the user to enter a password . Note that using this
     * method means that the application must be terminated by calling <code>System.exit(0)</code>
     * to ensure that all the Swing threads created by this method are terminated and the JVM
     * can exit.
     * <p/>
     * Exit the program if the user clicked on the <code>CANCEL</code> button or on
     * the window close button.
     *
     * @return The <code>String</code> value of the password entered.
     */
    public static String getDBPassword() {
        JPasswordField password = new JPasswordField(20);

        final Object[] fields = {"Enter your database password:", password};
        JOptionPane pane = new JOptionPane(fields,
                JOptionPane.QUESTION_MESSAGE,
                JOptionPane.OK_CANCEL_OPTION,
                null);
        JDialog d = pane.createDialog(null, "Database Access");
        d.setVisible(true);

        Integer returnValue = (Integer) pane.getValue();
        d.dispose();

        if (returnValue == null || returnValue != JOptionPane.OK_OPTION) {
            System.err.println("Password entry cancelled: program will exit");
            System.exit(1);
        }

        char[] value = password.getPassword();
        return new String(value);
    }

    public static String getAdminPassword() {
        JPasswordField password = new JPasswordField(20);

        final Object[] fields = {"Admin username is 'admin'. Enter the desired admin password:", password};
        JOptionPane pane = new JOptionPane(fields,
                JOptionPane.QUESTION_MESSAGE,
                JOptionPane.OK_CANCEL_OPTION,
                null);
        JDialog d = pane.createDialog(null, "Admin Access");
        d.setVisible(true);

        Integer returnValue = (Integer) pane.getValue();
        d.dispose();

        if (returnValue == null || returnValue != JOptionPane.OK_OPTION) {
            System.err.println("Password entry cancelled: program will exit");
            System.exit(1);
        }

        char[] value = password.getPassword();
        return new String(value);
    }

    public static String getDBEncryptionPassword() {
        JPasswordField password = new JPasswordField(20);

        final Object[] fields = {"Database field encryption password:", password};
        JOptionPane pane = new JOptionPane(fields,
                JOptionPane.QUESTION_MESSAGE,
                JOptionPane.OK_CANCEL_OPTION,
                null);
        JDialog d = pane.createDialog(null, "Field Password");
        d.setVisible(true);

        Integer returnValue = (Integer) pane.getValue();
        d.dispose();

        if (returnValue == null || returnValue != JOptionPane.OK_OPTION) {
            System.err.println("Password entry cancelled: program will exit");
            System.exit(1);
        }

        char[] value = password.getPassword();
        return new String(value);
    }
}
