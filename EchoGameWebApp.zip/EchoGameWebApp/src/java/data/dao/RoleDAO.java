package data.dao;

import data.model.Role;

import java.util.List;

/**
 * User: Alan P. Sexton
 * Date: 16-Mar-2008
 * Time: 20:15:17
 */
public interface RoleDAO
{
    public List<Role> getRoles();

    public Role get(String rolename);

    public void save(Role role);

    public void remove(String rolename);
}
