/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package data.dao.hibernate;

import data.dao.BehaviourDAO;
import data.model.BehaviourIndicator;
import data.model.GameMode;
import data.model.IndicatorOption;
import java.util.List;
import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.orm.hibernate3.HibernateCallback;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

/**
 *
 * @author icerrr
 */
public class BehaviourDAOImpl extends HibernateDaoSupport implements BehaviourDAO {

    public List<BehaviourIndicator> getIndicatorByName(final String name,final GameMode mode) {
        return (List<BehaviourIndicator>) getHibernateTemplate().execute(
                new HibernateCallback() {

                    public Object doInHibernate(Session session) {
                        Query hql=session.createQuery("from BehaviourIndicator where displayName=:name and gameMode=:gameMode order by displayOrder asc");
                        hql.setEntity("name",name);
                        return hql.setEntity("gameMode",mode).list();
                    }
                });
    }

    public List<BehaviourIndicator> getIndicators(final GameMode mode) {
          return (List<BehaviourIndicator>) getHibernateTemplate().execute(
                new HibernateCallback() {

                    public Object doInHibernate(Session session) {
                        Query hql=session.createQuery("from BehaviourIndicator where gameMode=:gameMode order by displayOrder asc");
                         return hql.setEntity("gameMode",mode).list();
                    }
                });
    }

    public void save(BehaviourIndicator indicator) {
        if(getHibernateTemplate().contains(indicator)) getHibernateTemplate().merge(indicator);
        else getHibernateTemplate().saveOrUpdate(indicator);
    }

    public void save(IndicatorOption option) {
        if(getHibernateTemplate().contains(option)) getHibernateTemplate().merge(option);
        else getHibernateTemplate().saveOrUpdate(option);
    }

    public void removeFromSession(IndicatorOption option)
    {
        getHibernateTemplate().evict(option);
    }

        public void removeFromSession(BehaviourIndicator indicator)
    {
        getHibernateTemplate().evict(indicator);
    }

    public void remove(BehaviourIndicator indicator) {
        getHibernateTemplate().delete(indicator);
    }
    public void remove(IndicatorOption option) {
        getHibernateTemplate().delete(option);
    }

    public BehaviourIndicator getIndicatorById(long id) {
        return (BehaviourIndicator) getHibernateTemplate().get(BehaviourIndicator.class, id);
    }

    public void removeUserIndicator(final BehaviourIndicator existing) {
        getHibernateTemplate().execute(
                new HibernateCallback() {

                    public Object doInHibernate(Session session) {
                        Query hql=session.createQuery("delete from UserIndicatorValues as val " +
                                "where val.behaviour=:behaviour");
                        hql.setEntity("behaviour",existing);
                        return hql.executeUpdate();
                    }
                });
    }

        
}
