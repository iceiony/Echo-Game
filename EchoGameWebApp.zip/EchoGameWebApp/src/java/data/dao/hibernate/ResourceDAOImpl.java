/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package data.dao.hibernate;

import data.dao.ResourceDAO;
import data.model.GameMode;
import data.model.Resource;
import java.sql.SQLException;
import java.util.List;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.orm.hibernate3.HibernateCallback;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
/**
 *
 * @author icerrr
 */
public class ResourceDAOImpl extends HibernateDaoSupport implements ResourceDAO {

    public List<Resource> getAllResources(final GameMode mode) {
        return (List<Resource>) getHibernateTemplate().execute(
        new HibernateCallback()
        {
            public Object doInHibernate(Session session) throws HibernateException, SQLException {
               Query hql= session.createQuery("from Resource where gameMode=:gameMode order by id");
               return hql.setEntity("gameMode",mode).list();
            }
        }
        );
    }
    

    public Resource getResourceByName(final String name,final GameMode mode) {
         return (Resource) getHibernateTemplate().execute(
        new HibernateCallback()
        {
            public Object doInHibernate(Session session) throws HibernateException, SQLException {
               Query hql= session.createQuery("from Resource where name=:name order by id");
               hql.setString("name",name);
               return hql.setEntity("gameMode",mode).uniqueResult();
            }
        }
        );
    }

    public void save(Resource resource) {

        //getHibernateTemplate().merge(resource);// to reattach transient objects
        if(getHibernateTemplate().contains(resource)) getHibernateTemplate().merge(resource);
        else getHibernateTemplate().saveOrUpdate(resource);
    }

    public void delete(Resource resource) {
        getHibernateTemplate().delete(resource);
    }

    public Resource getResourceById(long id) {
       return (Resource) getHibernateTemplate().get(Resource.class, id);
    }


}
