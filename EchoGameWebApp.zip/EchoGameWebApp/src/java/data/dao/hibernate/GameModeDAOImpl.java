/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package data.dao.hibernate;

import data.dao.GameModeDAO;
import data.model.GameMode;
import java.sql.SQLException;
import java.util.List;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.springframework.orm.hibernate3.HibernateCallback;

/**
 *
 * @author icerrr
 */
public class GameModeDAOImpl extends HibernateDaoSupport implements GameModeDAO {

    public List<GameMode> getGameModes() {
        return getHibernateTemplate().find("from GameMode");
    }

    public GameMode getGameModeByName(final String name) {
        return (GameMode) getHibernateTemplate().execute(
                new HibernateCallback() {

                    public Object doInHibernate(Session session) throws HibernateException, SQLException {
                        return session.createQuery("from GameMode where name=:name order by name").setString("name", name).uniqueResult();
                    }
                });
    }

    public void save(GameMode game) {
        if(getHibernateTemplate().contains(game)) getHibernateTemplate().merge(game);
        else getHibernateTemplate().saveOrUpdate(game);
    }

    public void delete(GameMode game) {
         getHibernateTemplate().delete(game);
    }
}
