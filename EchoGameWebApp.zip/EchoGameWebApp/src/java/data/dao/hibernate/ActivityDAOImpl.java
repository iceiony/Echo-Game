/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package data.dao.hibernate;

import data.dao.ActivityDAO;
import data.model.Activity;
import data.model.ActivityChoice;
import data.model.ChoiceCostExpression;
import data.model.GameMode;
import data.model.UserChoices;
import data.model.Variable;
import java.sql.SQLException;
import java.util.LinkedList;
import java.util.List;
import org.hibernate.Criteria;
import org.hibernate.FetchMode;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.orm.hibernate3.HibernateCallback;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

/**
 * The methods return information vis-a-vis the current gamemode
 * @author icerrr
 */
public class ActivityDAOImpl extends HibernateDaoSupport implements ActivityDAO{

    public List<Activity> getActivityByName(final String name,final GameMode mode) {
        return (List<Activity>) getHibernateTemplate().execute(
        new HibernateCallback()
        {

            public Object doInHibernate(Session session) throws HibernateException, SQLException {
               Query hql=session.createQuery("from Activity where name=:name and gameMode=:gameMode order by displayOrder asc");
               hql.setString("name",name);
               hql.setEntity("gameMode", mode);
               return hql.list();
            }
        }
        );
    }

    public List<String> getCategories(final GameMode mode)
    {
       return (List<String>) getHibernateTemplate().execute(
        new HibernateCallback()
        {
            public Object doInHibernate(Session session) throws HibernateException, SQLException {
               Query hql=session.createQuery("select distinct category from Activity where gameMode=:gameMode order by category");
               hql.setEntity("gameMode", mode);
               return hql.list();
            }
        }
        );
    }

    public List<Activity> getActivityByCategory(final String category,final boolean eager_all,final GameMode mode)
    {
        return (List<Activity>) getHibernateTemplate().execute(
        new HibernateCallback()
        {
            public Object doInHibernate(Session session) throws HibernateException, SQLException {

                Query hql;
                if(eager_all)
                {
                    hql=session.createQuery("from Activity as activ where activ.category=:category and activ.gameMode=:gameMode order by activ.displayOrder asc");
                    List<Activity> rez=hql.setString("category",category).setEntity("gameMode",mode).list();
                    //now for each activity eagerly fetch the list of choices
                    for(Activity activ:rez)
                    {
                        hql=session.createQuery("select distinct choice from ActivityChoice as choice left join fetch choice.costExpressions where choice.activity=:activity order by choice.id");
                        activ.setChoices(hql.setLong("activity", activ.getId()).list());
                    }
                    return rez;
                }
               hql=session.createQuery("from Activity where category=:category and gameMode=:gameMode order by displayOrder asc");
               hql.setString("category",category);
               hql.setEntity("gameMode",mode);
               return hql.list();
            }
        }
        );
    }

    /**
     * Each list element is a list of activities from a a specific category
     * @return
     */
    public List<List<Activity>> getActivities(boolean eager_all,GameMode mode) {
        List<List<Activity>>  rez=new LinkedList<List<Activity>>();
        List<String> categories=getCategories(mode);
       
        for(String category:categories)
        {
         rez.add(getActivityByCategory(category,eager_all,mode));
        }

        return rez;
    }

    public void save(Activity indicator) {
        if(getHibernateTemplate().contains(indicator)) getHibernateTemplate().merge(indicator);
        else getHibernateTemplate().saveOrUpdate(indicator);
//        //save variables
//        for(Variable variable:indicator.getVariables())
//        {
//            if(getHibernateTemplate().contains(variable)) getHibernateTemplate().merge(variable);
//            else getHibernateTemplate().saveOrUpdate(variable);
//        }
    }

    public void save(ActivityChoice indicator) {
        if(getHibernateTemplate().contains(indicator))getHibernateTemplate().merge(indicator);
        else getHibernateTemplate().saveOrUpdate(indicator);
    }

    public void remove(ActivityChoice indicator) {
        getHibernateTemplate().delete(indicator);
    }

    public void remove(Activity indicator) {
      getHibernateTemplate().delete(indicator);
    }

    public void remove(Variable var)
    {
        getHibernateTemplate().delete(var);
    }

    public void renameCategory(final String oldName,final String newName) {
       getHibernateTemplate().execute(
        new HibernateCallback()
        {
            public Object doInHibernate(Session session) throws HibernateException, SQLException {
               return session.createQuery("update Activity set category=:newName where category=:oldName").setString("newName", newName).setString("oldName",oldName).executeUpdate();
            }
        }
        );
    }

    public Activity getActivityById(long id) {
        return (Activity) getHibernateTemplate().get(Activity.class, id);
    }

    public ActivityChoice getActivityChoiceById(long id) {
       return (ActivityChoice) getHibernateTemplate().get(ActivityChoice.class,id);
    }

    public ActivityChoice getActivityChoiceByIdEagerly(final long id) {
        return (ActivityChoice)getHibernateTemplate().execute(
                new HibernateCallback()
        {

            public Object doInHibernate(Session session) throws HibernateException, SQLException {
              Query hql=session.createQuery("select distinct choice from ActivityChoice as choice left join fetch choice.costExpressions as exp left join fetch exp.resource" +
                " where choice.id=:id");
                return hql.setLong("id",id).uniqueResult();
            }

        }
        );
    }

    public ChoiceCostExpression getCostbyResourceAndChoice(final long resId,final long choiceId) {
        return (ChoiceCostExpression) getHibernateTemplate().execute(
        new HibernateCallback()
        {

            public Object doInHibernate(Session session) throws HibernateException, SQLException {
               Query hql=session.createQuery("select expression from ChoiceCostExpression as expression where expression.activityChoice=:choiceId and expression.resource=:resourceId");
               hql.setLong("choiceId",choiceId);
               hql.setLong("resourceId", resId);
               return hql.uniqueResult();
            }
        }
        );
    }

    /** Returns the latest ( according to turn ) stored choice
     * @param activity
     * @param username
     * @param sessionNumber
     * @return
     */

    public UserChoices getStoredChoice(final Activity activity,final String username) {
        return (UserChoices)  getHibernateTemplate().execute(
        new HibernateCallback()
        {
            public Object doInHibernate(Session session) throws HibernateException, SQLException {
               Query hql=session.createQuery("select uc from UserChoices as uc join uc.choice as choice" +
                       " where choice.activity=:activity_id and uc.gameUser=:username ");

               hql.setLong("activity_id",activity.getId());
               hql.setString("username", username);
               return hql.uniqueResult();
            }
        }
        );
    }

    public int getMaxSessionNumber() {
       return (Integer) getHibernateTemplate().execute(
        new HibernateCallback()
        {
            public Object doInHibernate(Session session) throws HibernateException, SQLException {
               Query hql=session.createQuery("select max(uc.sessionNumber) from UserChoices as uc");
               Object result=hql.uniqueResult();
               if(result==null) return new Integer(0);
               else return result;
            }
        }
        );
    }

    public List<ActivityChoice> getChoicesWithCostExpressions() {
          return (List<ActivityChoice>) getHibernateTemplate().execute(
        new HibernateCallback()
        {
            public Object doInHibernate(Session session) throws HibernateException, SQLException {
               Query hql=session.createQuery("select distinct activ from ChoiceCostExpression as cost " +
                       "join cost.activityChoice as activ");
             return hql.list();
            }
        }
        );
    }

    public void removeFromSession(ActivityChoice choice) {
        getHibernateTemplate().evict(choice);
    }

}
