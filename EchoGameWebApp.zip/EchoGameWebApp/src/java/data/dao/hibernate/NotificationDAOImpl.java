/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package data.dao.hibernate;

import data.dao.NotificationDAO;
import data.model.Notification;
import java.util.Date;
import java.util.Vector;

/**
 * Class does not persist notifications it pools them and makes them available to the users
 * It also cleares the notifications when a certain number has been reached in the case that
 * the last received notification was grater than 5 minutes
 * w
 * 
 * @author icerrr
 */
public class NotificationDAOImpl implements NotificationDAO {

    private final Vector<Notification> poolVector = new Vector<Notification>(5);
    private Date lastMessage=new Date();

    public NotificationDAOImpl() {
    }

    public long save(Notification note) {
        int index = 0;
        
        synchronized (poolVector) {
            //check if I have to clear the old notifications
            Date newMessage=new Date();
            if(poolVector.size()>4)
            {
                if(newMessage.getTime()-lastMessage.getTime()>300000)
                    poolVector.clear();
                lastMessage=newMessage;
            }
            //add the new notification to the vector
            poolVector.add(note);
            index = poolVector.indexOf(note);
        }

        return index;
    }

    public Notification getNotification(long id) {
        Notification rez = null;
        try {
            synchronized (poolVector) {
                rez = poolVector.get((int) id);
            }
        } catch (Exception e) {
            rez = null;
        }

        return rez;
    }

    public void remove(Notification note) {
        synchronized (poolVector) {
            poolVector.remove(note);
        }
    }

    public void remove(long idNotification) {
        synchronized (poolVector) {
            poolVector.remove((int) idNotification);
        }

    }
}
