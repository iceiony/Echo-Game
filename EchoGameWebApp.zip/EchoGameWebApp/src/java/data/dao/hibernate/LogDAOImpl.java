/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package data.dao.hibernate;

import data.dao.LogDAO;
import data.model.LoggedUserChoice;
import data.model.LoggedUserResource;
import data.model.LoggedUserVariable;
import java.sql.SQLException;
import java.util.List;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.orm.hibernate3.HibernateCallback;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

/**
 *
 * @author icerrr
 */
public class LogDAOImpl extends HibernateDaoSupport implements LogDAO {

    public void save(LoggedUserChoice loggedChoice) {
        getHibernateTemplate().save(loggedChoice);
    }

    public void save(LoggedUserResource loggedResource) {
        getHibernateTemplate().save(loggedResource);
    }

    public void save(LoggedUserVariable loggedVariable) {
        getHibernateTemplate().save(loggedVariable);
    }

    public List<LoggedUserChoice> getLogedChoices(final long mode_id) {
        return (List<LoggedUserChoice>) getHibernateTemplate().execute(
                new HibernateCallback() {

                    public Object doInHibernate(Session session) throws HibernateException, SQLException {
                        Query hql = session.createQuery("from LoggedUserChoice as log where "
                                + "log.gamemode_id=:mode_id order by log.sessionNumber asc");
                        hql.setLong("mode_id", mode_id);

                        return hql.list();
                    }
                });
    }

    public List<LoggedUserVariable> getLoggedVariables(final long mode_id) {
        return (List<LoggedUserVariable>) getHibernateTemplate().execute(
                new HibernateCallback() {

                    public Object doInHibernate(Session session) throws HibernateException, SQLException {
                        Query hql = session.createQuery("from LoggedUserVariable as log where "
                                + "log.gameMode_id=:mode_id order by log.sessionNumber asc");
                        hql.setLong("mode_id", mode_id);
                        return hql.list();
                    }
                });
    }

    public List<LoggedUserResource> getLoggedResources(final long mode_id) {
        return (List<LoggedUserResource>) getHibernateTemplate().execute(
                new HibernateCallback() {

                    public Object doInHibernate(Session session) throws HibernateException, SQLException {
                        Query hql = session.createQuery("from LoggedUserResource as log where "
                                + "log.gameMode_id=:mode_id order by log.sessionNumber asc");
                        hql.setLong("mode_id", mode_id);
                        return hql.list();
                    }
                });
    }

    public void clearActions() {
        getHibernateTemplate().execute(
                new HibernateCallback() {

                    public Object doInHibernate(Session session) throws HibernateException, SQLException {
                        Query hql = session.createQuery("delete from LoggedUserChoice");
                        return hql.list();
                    }
                });
    }

    public void clearVariables() {
                getHibernateTemplate().execute(
                new HibernateCallback() {

                    public Object doInHibernate(Session session) throws HibernateException, SQLException {
                        Query hql = session.createQuery("delete from LoggedUserVariable");
                        return hql.list();
                    }
                });
    }

    public void clearResources() {
                       getHibernateTemplate().execute(
                new HibernateCallback() {

                    public Object doInHibernate(Session session) throws HibernateException, SQLException {
                        Query hql = session.createQuery("delete from LoggedUserResource");
                        return hql.list();
                    }
                });
    }
}
