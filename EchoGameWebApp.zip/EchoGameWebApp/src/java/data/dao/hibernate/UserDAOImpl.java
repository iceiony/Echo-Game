package data.dao.hibernate;

import data.model.UserChoices;
import data.model.UserResource;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import org.springframework.dao.DataAccessException;
import org.acegisecurity.userdetails.UserDetails;
import org.acegisecurity.userdetails.UsernameNotFoundException;
import data.dao.UserDAO;
import data.model.GameMode;
import data.model.GameUser;
import data.model.UserIndicatorValues;
import java.sql.SQLException;
import java.util.List;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.orm.ObjectRetrievalFailureException;
import org.springframework.orm.hibernate3.HibernateCallback;

/**
 * Initial code by
 * GameUser: Alan P. Sexton
 * Date: 16-Mar-2008
 * Time: 20:22:46
 *
 * Recoded by
 * GameUser: Adrian Ionita
 * Date: 3-Jul-2010
 * Time: 21:00:10
 */
public class UserDAOImpl extends HibernateDaoSupport implements UserDAO
{

      public UserDetails loadUserByUsername(String username)
            throws UsernameNotFoundException, DataAccessException
    {
        try
        {
            GameUser user = getGameUser(username);
            if(user==null) throw new UsernameNotFoundException("No such user");
            return user;
        }
        catch (ObjectRetrievalFailureException e)
        {
            throw new UsernameNotFoundException("user '" + username + "' not found");
        }
    }

    @SuppressWarnings({"unchecked"})
    public List<GameUser> getUsers()
    {
        return (List<GameUser>) getHibernateTemplate().find("from BookingUser");
    }

    public GameUser getGameUser(String username)
    {
        return (GameUser) getHibernateTemplate().get(GameUser.class, username);
    }

    public void save(GameUser bookingUser)
    {
        getHibernateTemplate().saveOrUpdate(bookingUser);
    }

    /**
     * Returns all user names that have behaviour indicators values registered
     * @param mode
     * @return
     */
    public List<String> getAllUserNames(final GameMode mode){
        return (List<String>) getHibernateTemplate().execute(
        new HibernateCallback()
        {
            public Object doInHibernate(Session session) throws HibernateException, SQLException {
               Query hql=session.createQuery("select distinct user.username from UserIndicatorValues as info " +
                                             "left join info.behaviour as behaviour " +
                                             "left join info.gameUser as user " +
                                             "where behaviour.gameMode=:gameMode");
               hql.setEntity("gameMode",mode);
               return hql.list();
            }
        }
        );
    }

    /**
     * Returns the a list of UserIndicatorValues for the specified gamemode
     * @param username
     * @param mode
     * @return
     */
    public List<UserIndicatorValues> getUserIndicatorValues(final String username,final GameMode mode)
    {
        return (List<UserIndicatorValues>) getHibernateTemplate().execute(
        new HibernateCallback()
        {
            public Object doInHibernate(Session session) throws HibernateException, SQLException {
               Query hql=session.createQuery("select info from UserIndicatorValues as info " +
                       "left join info.behaviour as behaviour " +
                       "where info.gameUser=:userName and behaviour.gameMode=:gameMode");
               hql.setString("userName", username);
               hql.setEntity("gameMode", mode);
               return hql.list();
            }
        }
        );
    }

    public UserResource getLatestUserResourceByResourceID(final String username,final long res_id) {
        return (UserResource) getHibernateTemplate().execute(
        new HibernateCallback()
        {
            public Object doInHibernate(Session session) throws HibernateException, SQLException {
               Query hql=session.createQuery("select ur from UserResource as ur " +
                       "where ur.gameuser=:userName and ur.resource=:resource_id ");
               hql.setString("userName", username);
               hql.setLong("resource_id", res_id);
               return hql.uniqueResult();
            }
        }
        );

    }

    
    public void save(UserChoices choice) {
       getHibernateTemplate().saveOrUpdate(choice);
    }

    public void remove(UserChoices choice) {
        getHibernateTemplate().delete(choice);
    }

    public void save(UserResource userResource) {
       getHibernateTemplate().save(userResource);
    }

    public void clearUserBehaviour() {
                getHibernateTemplate().execute(
                new HibernateCallback() {

                    public Object doInHibernate(Session session) {
                        Query hql=session.createQuery("delete from UserIndicatorValues");
                        return hql.executeUpdate();
                    }
                });
    }

    public void deleteAllUserChoices(final String username) {
                        getHibernateTemplate().execute(
                new HibernateCallback() {

                    public Object doInHibernate(Session session) {
                        Query hql=session.createQuery("delete from UserChoices where " +
                                "gameUser=:username");
                        hql.setString("username",username);
                        return hql.executeUpdate();
                    }
                });
    }
}
