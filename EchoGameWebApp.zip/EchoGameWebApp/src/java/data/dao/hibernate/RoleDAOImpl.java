package data.dao.hibernate;

import data.model.Role;
import data.dao.RoleDAO;

import java.util.List;

import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

/**
 * Initial code by
 * User: Alan P. Sexton
 * Date: 16-Mar-2008
 * Time: 20:15:41
 */
public class RoleDAOImpl extends HibernateDaoSupport implements RoleDAO
{
    @SuppressWarnings("unchecked")
    public List<Role> getRoles()
    {
        return (List<Role>)getHibernateTemplate().find("from Role");
    }

    public Role get(String rolename)
    {
        return (Role) getHibernateTemplate().get(Role.class, rolename);
    }

    public void save(Role role)
    {
        getHibernateTemplate().saveOrUpdate(role);
    }

    public void remove(String rolename)
    {
        Object role = getHibernateTemplate().load(Role.class, rolename);
        getHibernateTemplate().delete(role);
    }
}
