/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package data.dao;

import data.model.GameMode;
import data.model.Resource;
import java.util.List;

/**
 *
 * @author icerrr
 */
public interface ResourceDAO {

    
    public Resource getResourceById(long id);
    public List<Resource> getAllResources(GameMode mode);
    public Resource getResourceByName(final String name,final GameMode mode);
    
    public void save(Resource resource);
    public void delete(Resource resource);
}
