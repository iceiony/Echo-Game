/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package data.dao;

import data.model.Activity;
import data.model.ActivityChoice;
import data.model.ChoiceCostExpression;
import data.model.GameMode;
import data.model.Resource;
import data.model.UserChoices;
import data.model.Variable;
import java.util.List;

/**
 *
 * @author icerrr
 */
public interface ActivityDAO {

    public List<Activity> getActivityByName(String name,GameMode mode);

    public Activity getActivityById(long id);
    
    public List<Activity> getActivityByCategory(String category,boolean eager_all,GameMode mode);
    public List<String> getCategories(GameMode mode);

     /**
     * Each list element is a list of activities from a a specific category
     * @return
     */
    public List<List<Activity>> getActivities(boolean eager_all,GameMode mode);

    public void save(Activity indicator);
    public void save(ActivityChoice indicator);

    public void remove(ActivityChoice indicator);
    public void remove(Activity indicator);
    public void remove(Variable var);

    public void removeFromSession(ActivityChoice choice);

    public void renameCategory(String oldName,String newName);

    public ActivityChoice getActivityChoiceById(long id);

    public ActivityChoice getActivityChoiceByIdEagerly(long id);

    public ChoiceCostExpression getCostbyResourceAndChoice(long resId, long choiceId);

    public UserChoices getStoredChoice(Activity activity, String username);

    public List<ActivityChoice> getChoicesWithCostExpressions();

    public int getMaxSessionNumber();
    
}
