package data.dao;

import data.model.GameMode;
import data.model.GameUser;
import data.model.UserChoices;
import data.model.UserIndicatorValues;
import data.model.UserResource;
import java.util.List;
import org.acegisecurity.userdetails.UserDetails;
import org.acegisecurity.userdetails.UserDetailsService;
import org.acegisecurity.userdetails.UsernameNotFoundException;
import org.springframework.dao.DataAccessException;


/**
 * Framework By
 * User: Alan P. Sexton
 * Date: 16-Mar-2008
 * Time: 20:20:48
 *
 * Coded By
 * User: Adrian Ionita
 * Date: 03-Jul-2010
 * Time: 18:15:00
 */
public interface UserDAO extends UserDetailsService
{
    public UserDetails loadUserByUsername(String username)
            throws UsernameNotFoundException, DataAccessException;

    public List<GameUser> getUsers();

    public GameUser getGameUser(String username);

        /**
     * Returns all user names that have behaviour indicators values registered
     * @param mode
     * @return
     */
    public List<String> getAllUserNames(GameMode mode);

    public List<UserIndicatorValues> getUserIndicatorValues(String username,GameMode mode);

    public void save(GameUser bookingUser);

    public UserResource getLatestUserResourceByResourceID(String username,long res_id);

    public void save(UserChoices choice);


    public void remove(UserChoices choice);

    public void save(UserResource userResource);

    public void clearUserBehaviour();

    public void deleteAllUserChoices(String username);

}
