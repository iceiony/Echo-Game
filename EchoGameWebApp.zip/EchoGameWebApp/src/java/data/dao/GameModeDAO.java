/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package data.dao;

import data.model.GameMode;
import java.util.List;

/**
 *
 * @author icerrr
 */
public interface GameModeDAO {

    public List<GameMode> getGameModes();
    public GameMode getGameModeByName(String name);
    public void save(GameMode game);
    public void delete(GameMode game);
}
