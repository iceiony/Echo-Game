/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package data.dao;

import data.model.GameMode;
import data.model.LoggedUserChoice;
import data.model.LoggedUserResource;
import data.model.LoggedUserVariable;
import java.util.List;

/**
 *
 * @author icerrr
 */
public interface LogDAO {

    public void save(LoggedUserChoice loggedChoice);

    public void save(LoggedUserResource loggedResource);

    public void save(LoggedUserVariable loggedVariable);

    public List<LoggedUserChoice> getLogedChoices(long mode_id);

    public List<LoggedUserVariable> getLoggedVariables(long mode_id);

    public List<LoggedUserResource> getLoggedResources(long mode_id);

    public void clearActions();

    public void clearVariables();

    public void clearResources();

}
