/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package data.dao;

import data.model.BehaviourIndicator;
import data.model.GameMode;
import data.model.IndicatorOption;
import java.util.List;

/**
 *
 * @author icerrr
 */
public interface BehaviourDAO {

    public List<BehaviourIndicator> getIndicatorByName(final String name,final GameMode mode);

    public List<BehaviourIndicator> getIndicators(GameMode mode);

    public void save(BehaviourIndicator indicator);
    public void save(IndicatorOption indicator);

    public void remove(BehaviourIndicator indicator);
    public void remove(IndicatorOption indicator);

        public void removeFromSession(IndicatorOption option);
        public void removeFromSession(BehaviourIndicator option);
        
    public BehaviourIndicator getIndicatorById(long id);

    public void removeUserIndicator(BehaviourIndicator existing);
}

    

