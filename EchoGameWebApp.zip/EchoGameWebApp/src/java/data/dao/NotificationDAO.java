/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package data.dao;

import data.model.Notification;

/**
 *
 * @author icerrr
 */
public interface NotificationDAO {

    public long save(Notification note);
    public Notification getNotification(long id);
    public void remove(Notification note);
    public void remove(long idNotification);
    
}
