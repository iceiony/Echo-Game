/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package data.model;

import java.io.Serializable;

/**
 *
 * @author icerrr
 */
public class Variable implements Serializable,Computable {

    private long id;
    private int version;
    private String name;
    private String description;
    
    private boolean discrete;
    private int minValue;
    private int maxValue;
    private double value;

    public Variable()
    {
        
    }

    /**
     * @param id the id to set
     */
    protected void setId(long id) {
        this.id = id;
    }

    /**
     * @param version the version to set
     */
    protected void setVersion(int version) {
        this.version = version;
    }

    /**
     * @return the id
     */
    public long getId() {
        return id;
    }

    /**
     * @return the version
     */
    public int getVersion() {
        return version;
    }

    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * @return the description
     */
    public String getDescription() {
        return description;
    }

    /**
     * @param description the description to set
     */
    public void setDescription(String description) {
        this.description = description;
    }

    /**
     * @return the discrete
     */
    public boolean isDiscrete() {
        return discrete;
    }

        /**
     * @return the discrete
     */
    public boolean getDiscrete() {
        return discrete;
    }


    /**
     * @param discrete the discrete to set
     */
    public void setDiscrete(boolean discrete) {
        this.discrete = discrete;
    }

    /**
     * @return the minValue
     */
    public int getMinValue() {
        return minValue;
    }

    /**
     * @param minValue the minValue to set
     */
    public void setMinValue(int minValue) {
        this.minValue = minValue;
    }

    /**
     * @return the maxValue
     */
    public int getMaxValue() {
        return maxValue;
    }

    /**
     * @param maxValue the maxValue to set
     */
    public void setMaxValue(int maxValue) {
        this.maxValue = maxValue;
    }

    /**
     * @return the value
     */
    public double getValue() {
        return value;
    }

    /**
     * @param value the value to set
     */
    public void setValue(double value) {
        this.value = value;
    }

    /**
     * Logical equality
     * @param o
     * @return
     */
    @Override
    public boolean equals(Object o)
        {
                       if (this == o)
            return true;
        if (!(o instanceof Variable))
            return false;

        final Variable var = (Variable) o;
        return this.name.equals(var.getName());
        }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 67 * hash + (this.name != null ? this.name.hashCode() : 0);
        return hash;
    }

    public String getVariableName() {
        return this.getName();
    }

    public double getComputableValue() {
        return this.getValue();
    }


      
}
