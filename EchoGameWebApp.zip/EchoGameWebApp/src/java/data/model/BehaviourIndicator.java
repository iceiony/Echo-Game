/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package data.model;

import java.io.Serializable;
import java.util.LinkedList;
import java.util.List;

/**
 *
 * @author icerrr
 */
public class BehaviourIndicator implements Serializable,Comparable<BehaviourIndicator>{

        private long id;
        private int version;

        private String displayName;
        private String description;

        private String wicketClassName;
        private Class wicketClass;
        private int displayOrder;

        private String bindingName;

        private List<IndicatorOption> options;
        private GameMode gameMode;

        private List<UserIndicatorValues> userBehaviour;

        

        public BehaviourIndicator()
        {
        }
        
    /**
     * @return the id
     */
    public long getId() {
        return id;
    }

    /**
     * @return the version
     */
    public int getVersion() {
        return version;
    }

     /**
     * @param id the id to set
     */
    protected void setId(long id) {
        this.id = id;
    }

    /**
     * @param version the version to set
     */
    protected void setVersion(int version) {
        this.version = version;
    }

    /**
     * @return the displayName
     */
    public String getDisplayName() {
        return displayName;
    }

    /**
     * @param displayName the displayName to set
     */
    public void setDisplayName(String displayName) {
        this.displayName = displayName;
    }

    /**
     * @return the description
     */
    public String getDescription() {
        return description;
    }

    /**
     * @param description the description to set
     */
    public void setDescription(String description) {
        this.description = description;
    }

    /**
     * @return the wicketClassName
     */
    public String getWicketClassName() {
        return wicketClassName;
    }

    /**
     * @param wicketClassName the wicketClassName to set
     */
    public void setWicketClassName(String wicketClassName) {
        this.wicketClassName = wicketClassName;
    }

    /**
     * @return the wicketClass
     */
    public Class getWicketClass() {
        return wicketClass;
    }

    /**
     * @param wicketClass the wicketClass to set
     */
    public void setWicketClass(Class wicketClass) {
        this.wicketClass = wicketClass;
    }

        /**
     * @return the order
     */
    public int getDisplayOrder() {
        return displayOrder;
    }

    /**
     * @param order the order to set
     */
    public void setDisplayOrder(int order) {
        this.displayOrder = order;
    }

    public int compareTo(BehaviourIndicator o) {
       return (int) (this.id - ((BehaviourIndicator) o).getId());
    }

    @Override
    public boolean equals(Object o)
    {
        if (this == o)
            return true;
        if (!(o instanceof BehaviourIndicator))
            return false;

        if(this.id==((BehaviourIndicator)o).id) return true;
        return false;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 37 * hash + (int) (this.id ^ (this.id >>> 32));
        return hash;
    }

    /**
     * @return the options
     */
    public List<IndicatorOption> getOptions() {
        if (options==null) options=new LinkedList<IndicatorOption>();
        return options;
    }

    /**
     * @param options the options to set
     */
    public void setOptions(List<IndicatorOption> options) {
        this.options = options;
    }

        public GameMode getGameMode() {
        
        return gameMode;
    }

    /**
     * @param gameModes the gameModes to set
     */
    public void setGameMode(GameMode gameMode) {
        this.gameMode = gameMode;
    }

    /**
     * @return the bindingName
     */
    public String getBindingName() {
        return bindingName;
    }

    /**
     * @param bindingName the bindingName to set
     */
    public void setBindingName(String bindingName) {
        this.bindingName = bindingName;
    }

    /**
     * @return the userBehaviour
     */
    public List<UserIndicatorValues> getUserBehaviour() {
        if(userBehaviour==null) userBehaviour=new LinkedList<UserIndicatorValues>();
        return userBehaviour;
    }

    /**
     * @param userBehaviour the userBehaviour to set
     */
    public void setUserBehaviour(List<UserIndicatorValues> userBehaviour) {
        this.userBehaviour = userBehaviour;
    }

}
