/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package data.model;

import java.io.Serializable;

/**
 *
 * @author icerrr
 */
public class Notification implements Comparable<Notification>,Serializable{

    private long id;
    private int version;
    private String message;
    private GameUser sender;

    public Notification()
    {

    }

    public Notification(GameUser sender,String message)
    {
        this.sender=sender;
        this.message=message;
    }

    /**
     * @param id the id to set
     */
    private void setId(long id) {
        this.id = id;
    }

    /**
     * @param version the version to set
     */
    private void setVersion(int version) {
        this.version = version;
    }

    /**
     * @return the id
     */
    public long getId() {
        return id;
    }

    /**
     * @return the version
     */
    public int getVersion() {
        return version;
    }

    /**
     * @return the message
     */
    public String getMessage() {
        return message;
    }

    /**
     * @param message the message to set
     */
    public void setMessage(String message) {
        this.message = message;
    }

    /**
     * @return the sender
     */
    public GameUser getSender() {
        return sender;
    }

    /**
     * @param sender the sender to set
     */
    public void setSender(GameUser sender) {
        this.sender = sender;
    }

    public int compareTo(Notification o) {
           return (int) (this.id - ((Notification) o).getId());
    }

    @Override
    public int hashCode() {
        int hash = 3;
        hash = 43 * hash + (this.message != null ? this.message.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object o)
    {
                if (this == o)
            return true;
        if (!(o instanceof Notification))
            return false;

        final Notification notification = (Notification) o;

        if (this.message!=null)
            return this.message.equals(notification.getMessage());
        else if (notification.getMessage()==null) return true;
        else return false;
    }
}
