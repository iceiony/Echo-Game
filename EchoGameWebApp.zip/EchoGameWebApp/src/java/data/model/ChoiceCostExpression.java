/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package data.model;

import java.io.Serializable;

/**
 *
 * @author icerrr
 */
public class ChoiceCostExpression implements Serializable{

        private long id;
    private int version;
    private ActivityChoice activityChoice;
    private Resource resource;
    private String capex;
    private String opex;

    public ChoiceCostExpression()
    {
        
    }

    /**
     * @param id the id to set
     */
    protected void setId(long id) {
        this.id = id;
    }

    /**
     * @param version the version to set
     */
    protected void setVersion(int version) {
        this.version = version;
    }

    /**
     * @return the id
     */
    public long getId() {
        return id;
    }

    /**
     * @return the version
     */
    public int getVersion() {
        return version;
    }

    /**
     * @return the activityChoice
     */
    public ActivityChoice getActivityChoice() {
        return activityChoice;
    }

    /**
     * @param activityChoice the activityChoice to set
     */
    public void setActivityChoice(ActivityChoice activityChoice) {
        this.activityChoice = activityChoice;
    }

    /**
     * @return the resource
     */
    public Resource getResource() {
        return resource;
    }

    /**
     * @param resource the resource to set
     */
    public void setResource(Resource resource) {
        this.resource = resource;
    }


    @Override
    public int hashCode() {
        int hash = 7;
        hash = 23 * hash + (int) (this.id ^ (this.id >>> 32));
        return hash;
    }

    @Override
    public boolean equals(Object o)
    {
                               if (this == o)
            return true;
        if (!(o instanceof ChoiceCostExpression))
            return false;

        final ChoiceCostExpression exp = (ChoiceCostExpression) o;
        return this.id==exp.getId();
    }

    /**
     * @return the capex
     */
    public String getCapex() {
        return capex;
    }

    /**
     * @param capex the capex to set
     */
    public void setCapex(String capex) {
        this.capex = capex;
    }

    /**
     * @return the opex
     */
    public String getOpex() {
        return opex;
    }

    /**
     * @param opex the opex to set
     */
    public void setOpex(String opex) {
        this.opex = opex;
    }
}
