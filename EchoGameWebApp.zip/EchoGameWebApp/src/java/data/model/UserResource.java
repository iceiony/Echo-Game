/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package data.model;

import java.io.Serializable;

/**
 * Object stores the recorded resource details for a specific user;
 * @author icerrr
 */
public class UserResource implements Serializable {

    private long id;
    private int version;
    private GameUser gameuser;
    private Resource resource;
    private double accumulatedValue;//if the resource accumulates from one turn to the next
    private double lastTotal;
    private double lastAvailable;
    private double embededCost;
    private int sessionNumber;

    public UserResource() {
    }

    /**
     * @param id the id to set
     */
    protected void setId(long id) {
        this.id = id;
    }

    /**
     * @param version the version to set
     */
    protected void setVersion(int version) {
        this.version = version;
    }

    /**
     * @return the id
     */
    public long getId() {
        return id;
    }

    /**
     * @return the version
     */
    public int getVersion() {
        return version;
    }

    /**
     * @return the gameuser
     */
    public GameUser getGameuser() {
        return gameuser;
    }

    /**
     * @param gameuser the gameuser to set
     */
    public void setGameuser(GameUser gameuser) {
        this.gameuser = gameuser;
    }

    /**
     * @return the resource
     */
    public Resource getResource() {
        return resource;
    }

    /**
     * @param resource the resource to set
     */
    public void setResource(Resource resource) {
        this.resource = resource;
    }



    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof UserResource)) {
            return false;
        }
        UserResource user_res = (UserResource) o;
        return id == user_res.getId();
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 73 * hash + (int) (this.id ^ (this.id >>> 32));
        return hash;
    }

    /**
     * @return the accumulatedValue
     */
    public double getAccumulatedValue() {
        return accumulatedValue;
    }

    /**
     * @param accumulatedValue the accumulatedValue to set
     */
    public void setAccumulatedValue(double accumulatedValue) {
        this.accumulatedValue = accumulatedValue;
    }

    /**
     * @return the sessionNumber
     */
    public int getSessionNumber() {
        return sessionNumber;
    }

    /**
     * @param sessionNumber the sessionNumber to set
     */
    public void setSessionNumber(int sessionNumber) {
        this.sessionNumber = sessionNumber;
    }

    /**
     * @return the lastTotal
     */
    public double getLastTotal() {
        return lastTotal;
    }

    /**
     * @param lastTotal the lastTotal to set
     */
    public void setLastTotal(double lastTotal) {
        this.lastTotal = lastTotal;
    }

    /**
     * @return the lastAvailable
     */
    public double getLastAvailable() {
        return lastAvailable;
    }

    /**
     * @param lastAvailable the lastAvailable to set
     */
    public void setLastAvailable(double lastAvailable) {
        this.lastAvailable = lastAvailable;
    }

    /**
     * @return the emededCost
     */
    public double getEmbededCost() {
        return embededCost;
    }

    /**
     * @param emededCost the emededCost to set
     */
    public void setEmbededCost(double emededCost) {
        this.embededCost = emededCost;
    }

   
}
