/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package data.model;

import java.io.Serializable;
import java.util.LinkedList;
import java.util.List;

/**
 *
 * @author icerrr
 */
public class Activity implements Serializable,Comparable<Activity>{

    private long id;
    private int version;

    private String name;
    private String description;
    private int displayOrder;
    private String category;
    private String choiceFormula;

    private List<ActivityChoice> choices;

    private GameMode gameMode;

    private List<Variable> variables;
//    private List<UserChoices> userChoices;

    public Activity()
    {
        
    }
    /**
     * @param id the id to set
     */
    protected void setId(long id) {
        this.id = id;
    }

    /**
     * @param version the version to set
     */
    protected void setVersion(int version) {
        this.version = version;
    }

    /**
     * @return the id
     */
    public long getId() {
        return id;
    }

    /**
     * @return the version
     */
    public int getVersion() {
        return version;
    }

    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * @return the description
     */
    public String getDescription() {
        return description;
    }

    /**
     * @param description the description to set
     */
    public void setDescription(String description) {
        this.description = description;
    }

    /**
     * @return the order
     */
    public int getDisplayOrder() {
        return displayOrder;
    }

    /**
     * @param order the order to set
     */
    public void setDisplayOrder(int order) {
        this.displayOrder = order;
    }

        public int compareTo(Activity o) {
        return (int) (this.getId() - ((Activity) o).getId());
    }

    @Override
        public boolean equals(Object o)
        {
                       if (this == o)
            return true;
        if (!(o instanceof Activity))
            return false;

        final Activity activity = (Activity) o;
        return this.id==activity.getId();
        }

    @Override
    public int hashCode() {
        int hash = 3;
        hash = 67 * hash + (int) (this.id ^ (this.id >>> 32));
        return hash;
    }

    /**
     * @return the choices
     */
    public List<ActivityChoice> getChoices() {
        if(choices==null) setChoices(new LinkedList<ActivityChoice>());
        return choices;
    }

    /**
     * @param choices the choices to set
     */
    public void setChoices(List<ActivityChoice> choices) {
       this.choices=choices;
    }

    /**
     * @return the category
     */
    public String getCategory() {
        return category;
    }

    /**
     * @param category the category to set
     */
    public void setCategory(String category) {
        this.category = category;
    }

    /**
     * @return the gameModes
     */
    public GameMode getGameMode() {
//        if(gameModes==null) setGameModes(new LinkedList<GameMode>());
        return gameMode;
    }

    /**
     * @param gameModes the gameModes to set
     */
    public void setGameMode(GameMode gameModes) {
        this.gameMode = gameModes;
    }

    /**
     * @return the variables
     */
    public List<Variable> getVariables() {
        if(variables==null) variables=new LinkedList<Variable>();
        return variables;
    }

    /**
     * @param variables the variables to set
     */
    public void setVariables(List<Variable> variables) {
        this.variables = variables;
    }

    /**
     * @return the choiceFormula
     */
    public String getChoiceFormula() {
        return choiceFormula;
    }

    /**
     * @param choiceFormula the choiceFormula to set
     */
    public void setChoiceFormula(String choiceFormula) {
        this.choiceFormula = choiceFormula;
    }

//    /**
//     * @return the userChoices
//     */
//    public List<UserChoices> getUserChoices() {
//        if(userChoices==null) userChoices=new LinkedList<UserChoices>();
//        return userChoices;
//    }
//
//    /**
//     * @param userChoices the userChoices to set
//     */
//    public void setUserChoices(List<UserChoices> userChoices) {
//        this.userChoices = userChoices;
//    }





}
