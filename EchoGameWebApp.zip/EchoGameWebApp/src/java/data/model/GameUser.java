package data.model;

import org.acegisecurity.GrantedAuthority;
import org.acegisecurity.userdetails.UserDetails;

import java.util.*;

public class GameUser implements UserDetails,Comparable<GameUser>
{
    private String username;
    //hibernate stuff
    private int version;

    private Integer salt;

    //acegi stuff
    private boolean enabled;
    private boolean accountNonExpired;
    private boolean credentialsNonExpired;
    private boolean accountNonLocked;

    //more particular stuff here
    private Role role;//user can only have one role
    private String password;

    //log related stuff
    private List<UserIndicatorValues> indicatorValues;
    private List<UserChoices> userChoices;
    private List<UserResource> userResource;
    private List<LoggedUserVariable> userVariable;

    public GameUser()
    {
    }

    public GameUser(String name)
    {
        this.username=name;
        this.enabled=true;
        this.accountNonExpired=true;
        this.credentialsNonExpired=true;
        this.accountNonLocked=true;
    }

    public String getUsername()
    {
        return username;
    }

    public void setUsername(String username)
    {
        this.username = username;
    }


    public int getVersion()
    {
        return version;
    }

    public void setVersion(int version)
    {
        this.version = version;
    }

    public GrantedAuthority[] getAuthorities() {
       Role[] roleArray=new Role[1];
       roleArray[0]=role;
       return roleArray;//only one role pe user not more
    }

    public String getPassword() {
        return password;
    }

    public boolean isAccountNonExpired() {
        return accountNonExpired;
    }

    public boolean isAccountNonLocked() {
       return accountNonLocked;
    }

    public boolean isCredentialsNonExpired() {
        return credentialsNonExpired;
    }

    public boolean isEnabled() {
        return enabled;
    }

    public int compareTo(GameUser o) {
        return username.compareTo(o.getUsername());
    }

    /**
     * @param enabled the enabled to set
     */
    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }

    /**
     * @param accountNonExpired the accountNonExpired to set
     */
    public void setAccountNonExpired(boolean accountNonExpired) {
        this.accountNonExpired = accountNonExpired;
    }

    /**
     * @param credentialsNonExpired the credentialsNonExpired to set
     */
    public void setCredentialsNonExpired(boolean credentialsNonExpired) {
        this.credentialsNonExpired = credentialsNonExpired;
    }

    /**
     * @param accountNonLocked the accountNonLocked to set
     */
    public void setAccountNonLocked(boolean accountNonLocked) {
        this.accountNonLocked = accountNonLocked;
    }

    /**
     * @return the role
     */
    public Role getRole() {
        return role;
    }

    /**
     * @param role the role to set
     */
    public void setRole(Role role) {
        this.role = role;
    }

    /**
     * @param password the password to set
     */
    public void setPassword(String password) {
        this.password = password;
    }

    /**
     * @return the indicatorValues
     */
    public List<UserIndicatorValues> getIndicatorValues() {
        if(indicatorValues==null) indicatorValues=new LinkedList<UserIndicatorValues>();
        return indicatorValues;
    }

    /**
     * @param indicatorValues the indicatorValues to set
     */
    public void setIndicatorValues(List<UserIndicatorValues> indicatorValues) {
        this.indicatorValues = indicatorValues;
    }

    /**
     * @return the userChoices
     */
    public List<UserChoices> getUserChoices() {
        return userChoices;
    }

    /**
     * @param userChoices the userChoices to set
     */
    public void setUserChoices(List<UserChoices> userChoices) {
        this.userChoices = userChoices;
    }

    /**
     * @return the userResource
     */
    public List<UserResource> getUserResource() {
        if(userResource==null) userResource=new LinkedList<UserResource>();
        return userResource;
    }

    /**
     * @param userResource the userResource to set
     */
    public void setUserResource(List<UserResource> userResource) {
        this.userResource = userResource;
    }

    /**
     * @return the userVariable
     */
    public List<LoggedUserVariable> getUserVariable() {
        if(userVariable==null) userVariable=new LinkedList<LoggedUserVariable>();
        return userVariable;
    }

    /**
     * @param userVariable the userVariable to set
     */
    public void setUserVariable(List<LoggedUserVariable> userVariable) {
        this.userVariable = userVariable;
    }

    /**
     * @return the salt
     */
    public Integer getSalt() {
        return salt;
    }

    /**
     * @param salt the salt to set
     */
    public void setSalt(Integer salt) {
        this.salt = salt;
    }

}
