/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package data.model;

import java.io.Serializable;

/**
 *
 * @author icerrr
 */
public class UserChoices implements Serializable {

    private long id;
    private int version;
    private GameUser gameUser;
    private ActivityChoice choice;
    private int sessionNumber;
    /**
     * @return the id
     */
    public long getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(long id) {
        this.id = id;
    }

    /**
     * @return the version
     */
    public int getVersion() {
        return version;
    }

    /**
     * @param version the version to set
     */
    public void setVersion(int version) {
        this.version = version;
    }

    /**
     * @return the gameUser
     */
    public GameUser getGameUser() {
        return gameUser;
    }

    /**
     * @param gameUser the gameUser to set
     */
    public void setGameUser(GameUser gameUser) {
        this.gameUser = gameUser;
    }

    /**
     * @return the choice
     */
    public ActivityChoice getChoice() {
        return choice;
    }

    /**
     * @param choice the choice to set
     */
    public void setChoice(ActivityChoice choice) {
        this.choice = choice;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof UserChoices)) {
            return false;
        }
        UserChoices comparedChoice = (UserChoices) o;
        return id == comparedChoice.getId();
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 41 * hash + (int) (this.id ^ (this.id >>> 32));
        return hash;
    }

    /**
     * @return the sessionNumber
     */
    public int getSessionNumber() {
        return sessionNumber;
    }

    /**
     * @param sessionNumber the sessionNumber to set
     */
    public void setSessionNumber(int sessionNumber) {
        this.sessionNumber = sessionNumber;
    }



}
