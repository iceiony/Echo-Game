/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package data.model;

import java.io.Serializable;

/**
 *
 * @author icerrr
 */
public class LoggedUserResource implements Serializable {
    private long id;
    private int version;
    private String gameuser;
    private String resource;
    private int gameTurn;
    private int sessionNumber;
    private double user_cap;
    private double cost;
    private long gameMode_id;

    public LoggedUserResource()
    {
        
    }

    /**
     * @return the id
     */
    public long getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(long id) {
        this.id = id;
    }

    /**
     * @return the version
     */
    public int getVersion() {
        return version;
    }

    /**
     * @param version the version to set
     */
    public void setVersion(int version) {
        this.version = version;
    }

    /**
     * @return the gameuser
     */
    public String getGameuser() {
        return gameuser;
    }

    /**
     * @param gameuser the gameuser to set
     */
    public void setGameuser(String gameuser) {
        this.gameuser = gameuser;
    }

    /**
     * @return the resource
     */
    public String getResource() {
        return resource;
    }

    /**
     * @param resource the resource to set
     */
    public void setResource(String resource) {
        this.resource = resource;
    }

    /**
     * @return the gameTurn
     */
    public int getGameTurn() {
        return gameTurn;
    }

    /**
     * @param gameTurn the gameTurn to set
     */
    public void setGameTurn(int gameTurn) {
        this.gameTurn = gameTurn;
    }

    /**
     * @return the sessionNumber
     */
    public int getSessionNumber() {
        return sessionNumber;
    }

    /**
     * @param sessionNumber the sessionNumber to set
     */
    public void setSessionNumber(int sessionNumber) {
        this.sessionNumber = sessionNumber;
    }

    /**
     * @return the user_cap
     */
    public double getUser_cap() {
        return user_cap;
    }

    /**
     * @param user_cap the user_cap to set
     */
    public void setUser_cap(double user_cap) {
        this.user_cap = user_cap;
    }

    /**
     * @return the accumulated
     */
    public double getCost() {
        return cost;
    }

    /**
     * @param accumulated the accumulated to set
     */
    public void setCost(double accumulated) {
        this.cost = accumulated;
    }

    /**
     * @return the gameMode_id
     */
    public long getGameMode_id() {
        return gameMode_id;
    }

    /**
     * @param gameMode_id the gameMode_id to set
     */
    public void setGameMode_id(long gameMode_id) {
        this.gameMode_id = gameMode_id;
    }
}
