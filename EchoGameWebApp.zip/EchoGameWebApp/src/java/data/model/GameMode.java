/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package data.model;

import java.io.Serializable;
import java.util.LinkedList;
import java.util.List;

/**
 *
 * @author icerrr
 */
public class GameMode implements Serializable{

    private long id;
    private int version;

    private String name;
    private String description;

    private int turnInterval;
    private int maxTurns;


    public GameMode()
    {
        
    }

    /**
     * @param id the id to set
     */
    protected void setId(long id) {
        this.id = id;
    }

    /**
     * @param version the version to set
     */
    protected void setVersion(int version) {
        this.version = version;
    }

    /**
     * @return the id
     */
    public long getId() {
        return id;
    }

    /**
     * @return the version
     */
    public int getVersion() {
        return version;
    }

    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * @return the description
     */
    public String getDescription() {
        return description;
    }

    /**
     * @param description the description to set
     */
    public void setDescription(String description) {
        this.description = description;
    }

    /**
     * @return the turnInterval
     */
    public int getTurnInterval() {
        return turnInterval;
    }

    /**
     * @param turnInterval the turnInterval to set
     */
    public void setTurnInterval(int turnInterval) {
        this.turnInterval = turnInterval;
    }

    /**
     * @return the maxTurns
     */
    public int getMaxTurns() {
        return maxTurns;
    }

    /**
     * @param maxTurns the maxTurns to set
     */
    public void setMaxTurns(int maxTurns) {
        this.maxTurns = maxTurns;
    }

//    /**
//     * @return the activities
//     */
//    public List<Activity> getActivities() {
//       if(activities==null) activities=new LinkedList<Activity>();
//        return activities;
//    }
//
//    /**
//     * @param activities the activities to set
//     */
//    public void setActivities(List<Activity> activities) {
//        this.activities = activities;
//    }
//
//    /**
//     * @return the behaviourIndicators
//     */
//    public List<BehaviourIndicator> getBehaviourIndicators() {
//        if(behaviourIndicators==null) behaviourIndicators=new LinkedList<BehaviourIndicator>();
//        return behaviourIndicators;
//    }
//
//    /**
//     * @param behaviourIndicators the behaviourIndicators to set
//     */
//    public void setBehaviourIndicators(List<BehaviourIndicator> behaviourIndicators) {
//        this.behaviourIndicators = behaviourIndicators;
//    }
//
//    /**
//     * @return the resources
//     */
//    public List<Resource> getResources() {
//        if(resources==null) resources=new LinkedList<Resource>();
//        return resources;
//    }
//
//    /**
//     * @param resources the resources to set
//     */
//    public void setResources(List<Resource> resources) {
//        this.resources = resources;
//    }


}
