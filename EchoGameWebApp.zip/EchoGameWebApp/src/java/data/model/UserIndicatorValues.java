/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package data.model;

import java.io.Serializable;

/**
 *
 * @author icerrr
 */
public class UserIndicatorValues implements Serializable,Computable{

    private long id;
    private int version;

    private int value;
    private String stringValue;
    private String indicatorName;

    private BehaviourIndicator behaviour;
    private GameUser gameUser;

    private boolean hidden;

    public UserIndicatorValues(){

    };

    /**
     * @return the id
     */
    public long getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(long id) {
        this.id = id;
    }

    /**
     * @return the version
     */
    public int getVersion() {
        return version;
    }

    /**
     * @param version the version to set
     */
    public void setVersion(int version) {
        this.version = version;
    }

    /**
     * @return the value
     */
    public int getValue() {
        return value;
    }

    /**
     * @param value the value to set
     */
    public void setValue(int value) {
        this.value = value;
    }

    /**
     * @return the stringValue
     */
    public String getStringValue() {
        return stringValue;
    }

    /**
     * @param stringValue the stringValue to set
     */
    public void setStringValue(String stringValue) {
        this.stringValue = stringValue;
    }

  
    /**
     * @return the gameUser
     */
    public GameUser getGameUser() {
        return gameUser;
    }

    /**
     * @param gameUser the gameUser to set
     */
    public void setGameUser(GameUser gameUser) {
        this.gameUser = gameUser;
    }

    @Override
    public boolean equals(Object o)
    {
         if (this == o)
            return true;
        if (!(o instanceof UserIndicatorValues))
            return false;

         UserIndicatorValues user_indicator=(UserIndicatorValues)o;
         return this.id==user_indicator.getId();
     }

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 37 * hash + (int) (this.id ^ (this.id >>> 32));
        return hash;
    }

    public String getVariableName() {
        return this.getBehaviour().getBindingName();
    }

    

    public double getComputableValue() {
        return (double) this.getValue();
    }

    /**
     * @return the indicatorName
     */
    public String getIndicatorName() {
        return indicatorName;
    }

    /**
     * @param indicatorName the indicatorName to set
     */
    public void setIndicatorName(String indicatorName) {
        this.indicatorName = indicatorName;
    }

    /**
     * @return the behaviour
     */
    public BehaviourIndicator getBehaviour() {
        return behaviour;
    }

    /**
     * @param behaviour the behaviour to set
     */
    public void setBehaviour(BehaviourIndicator behaviour) {
        this.behaviour = behaviour;
    }

    /**
     * @return the hidden
     */
    public boolean isHidden() {
        return hidden;
    }

    /**
     * @param hidden the hidden to set
     */
    public void setHidden(boolean hidden) {
        this.hidden = hidden;
    }

        /**
     * @return the hidden
     */
    public boolean getHidden() {
        return hidden;
    }
}
