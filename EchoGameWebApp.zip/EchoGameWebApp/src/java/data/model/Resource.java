/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package data.model;

import java.io.Serializable;
import java.util.Comparator;
import java.util.LinkedList;
import java.util.List;

/**
 *
 * @author icerrr
 */
public class Resource implements Serializable, Comparable<Resource> {

    private long id;
    private int version;
    private String name;
    private String logoURL;//relative path URL
    private String globalCap;
    private String defaultUserCap;
    private List<ChoiceCostExpression> costExpressions;
    private GameMode gameMode;
    private boolean accumulates;//determines the extra of the resource accumulates from one turn the next

    private List<UserResource> userResource;

    public Resource()
    {
        
    }
    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * @return the version
     */
    public int getVersion() {
        return version;
    }

    /**
     * @param version the version to set
     */
    protected void setVersion(int version) {
        this.version = version;
    }

    /**
     * @return the logoURL
     */
    public String getLogoURL() {
        return logoURL;
    }

    /**
     * @param logoURL the logoURL to set
     */
    public void setLogoURL(String logoURL) {
        this.logoURL = logoURL;
    }

    /**
     * @return the globalCap
     */
    public String getGlobalCap() {
        return globalCap;
    }

    /**
     * @param globalCap the globalCap to set
     */
    public void setGlobalCap(String globalCap) {
        this.globalCap = globalCap;
    }



    public int compareTo(Resource o) {
        
        return (int)(this.id-o.getId());
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof Resource)) {
            return false;
        }

        Resource resource = (Resource) o;
        return this.id==resource.getId();
    }

    @Override
    public int hashCode() {
        int hash = 3;
        hash = 83 * hash + (int) (this.id ^ (this.id >>> 32));
        return hash;
    }


    /**
     * Not really used , ever.
     * @return the costExpressions
     */
    public List<ChoiceCostExpression> getCostExpressions() {
        if(costExpressions==null) costExpressions=new LinkedList<ChoiceCostExpression>();
        return costExpressions;
    }

    /**
     * Not really used, ever.
     * @param costExpressions the costExpressions to set
     */
    public void setCostExpressions(List<ChoiceCostExpression> costExpressions) {
        this.costExpressions = costExpressions;
    }

    /**
     * @return the id
     */
    public long getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    protected void setId(long id) {
        this.id = id;
    }

    /**
     * @return the gameMode
     */
    public GameMode getGameMode() {
        return gameMode;
    }

    /**
     * @param gameMode the gameMode to set
     */
    public void setGameMode(GameMode gameMode) {
        this.gameMode = gameMode;
    }

    /**
     * @return the defaultUserCap
     */
    public String getDefaultUserCap() {
        return defaultUserCap;
    }

    /**
     * @param defaultUserCap the defaultUserCap to set
     */
    public void setDefaultUserCap(String defaultUserCap) {
        this.defaultUserCap = defaultUserCap;
    }

    /**
     * @return the accumulates
     */
    public boolean getAccumulates() {
        return accumulates;
    }

    /**
     * @param accumulates the accumulates to set
     */
    public void setAccumulates(boolean accumulates) {
        this.accumulates = accumulates;
    }

    /**
     * @return the userResource
     */
    public List<UserResource> getUserResource() {
        if(userResource==null) userResource=new LinkedList<UserResource>();
        return userResource;
    }

    /**
     * @param userResource the userResource to set
     */
    public void setUserResource(List<UserResource> userResource) {
        this.userResource = userResource;
    }
}
