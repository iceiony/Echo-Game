/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package data.model;

import java.io.Serializable;

/**
 *
 * @author icerrr
 */
public class LoggedUserVariable implements Serializable{
        private long id;
        private int version;

        private String gameUser;
        private String variable;
        private String activity;
        private String category;
        private double value;
        private int gameTurn;
        private int sessionNumber;
        private long gameMode_id;

        public LoggedUserVariable()
        {
            
        }

    /**
     * @return the id
     */
    public long getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(long id) {
        this.id = id;
    }

    /**
     * @return the version
     */
    public int getVersion() {
        return version;
    }

    /**
     * @param version the version to set
     */
    public void setVersion(int version) {
        this.version = version;
    }

    /**
     * @return the gameUser
     */
    public String getGameUser() {
        return gameUser;
    }

    /**
     * @param gameUser the gameUser to set
     */
    public void setGameUser(String gameUser) {
        this.gameUser = gameUser;
    }

    /**
     * @return the variable
     */
    public String getVariable() {
        return variable;
    }

    /**
     * @param variable the variable to set
     */
    public void setVariable(String variable) {
        this.variable = variable;
    }

    /**
     * @return the activity
     */
    public String getActivity() {
        return activity;
    }

    /**
     * @param activity the activity to set
     */
    public void setActivity(String activity) {
        this.activity = activity;
    }

    /**
     * @return the value
     */
    public double getValue() {
        return value;
    }

    /**
     * @param value the value to set
     */
    public void setValue(double value) {
        this.value = value;
    }

    /**
     * @return the gameTurn
     */
    public int getGameTurn() {
        return gameTurn;
    }

    /**
     * @param gameTurn the gameTurn to set
     */
    public void setGameTurn(int gameTurn) {
        this.gameTurn = gameTurn;
    }

    /**
     * @return the sessionNumber
     */
    public int getSessionNumber() {
        return sessionNumber;
    }

    /**
     * @param sessionNumber the sessionNumber to set
     */
    public void setSessionNumber(int sessionNumber) {
        this.sessionNumber = sessionNumber;
    }

    /**
     * @return the gameMod_id
     */
    public long getGameMode_id() {
        return gameMode_id;
    }

    /**
     * @param gameMod_id the gameMod_id to set
     */
    public void setGameMode_id(long gameMode_id) {
        this.gameMode_id = gameMode_id;
    }

    /**
     * @return the category
     */
    public String getCategory() {
        return category;
    }

    /**
     * @param category the category to set
     */
    public void setCategory(String category) {
        this.category = category;
    }
}
