/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package data.model;

import java.io.Serializable;
import java.util.LinkedList;
import java.util.List;

/**
 *
 * @author icerrr
 */
public class ActivityChoice implements Serializable,Comparable<ActivityChoice>{

    private long id;
    private int version;


    private Activity activity;
    private String name;
    private String description;
    private List<ChoiceCostExpression> costExpressions;
    private List<UserChoices> userChoices;


    //the folowing filed is not persisted
    private boolean wasChanged=true;

    public ActivityChoice()
    {
       
    }
    /**
     * @param id the id to set
     */
    protected void setId(long id) {
        this.id = id;
    }

    /**
     * @param version the version to set
     */
    protected void setVersion(int version) {
        this.version = version;
    }

    /**
     * @return the id
     */
    public long getId() {
        return id;
    }

    /**
     * @return the version
     */
    public int getVersion() {
        return version;
    }

    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * @return the description
     */
    public String getDescription() {
        return description;
    }

    /**
     * @param description the description to set
     */
    public void setDescription(String description) {
        this.description = description;
    }

        public int compareTo(ActivityChoice o) {
        return (int) (this.id - ((ActivityChoice) o).getId());
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 79 * hash + (int) (this.id ^ (this.id >>> 32));
        return hash;
    }
    @Override
        public boolean equals(Object o)
        {
           if (this == o)
            return true;
        if (!(o instanceof ActivityChoice))
            return false;

        final ActivityChoice activity = (ActivityChoice) o;

        return this.id==activity.getId();
        }

    /**
     * @return the activity
     */
    public Activity getActivity() {
        return activity;
    }

    /**
     * @param activity the activity to set
     */
    public void setActivity(Activity activity) {
        this.activity = activity;
    }

    /**
     * @return the costExpressions
     */
    public List<ChoiceCostExpression> getCostExpressions() {
        if(costExpressions==null) costExpressions=new LinkedList<ChoiceCostExpression>();
        return costExpressions;
    }

    /**
     * @param costExpressions the costExpressions to set
     */
    public void setCostExpressions(List<ChoiceCostExpression> costExpressions) {
        this.costExpressions = costExpressions;
    }

    /**
     * @return the userChoices
     */
    public List<UserChoices> getUserChoices() {
        if(userChoices==null) userChoices=new LinkedList<UserChoices>();
        return userChoices;
    }

    /**
     * @param userChoices the userChoices to set
     */
    public void setUserChoices(List<UserChoices> userChoices) {
        this.userChoices = userChoices;
    }

    /**
     * @return the wasChanged
     */
    public boolean isWasChanged() {
        return wasChanged;
    }

    /**
     * @param wasChanged the wasChanged to set
     */
    public void setWasChanged(boolean wasChanged) {
        this.wasChanged = wasChanged;
    }

}
