package services;

import org.acegisecurity.AccessDeniedException;
import org.acegisecurity.Authentication;
import org.acegisecurity.context.SecurityContextHolder;
import org.acegisecurity.userdetails.UserDetails;


/**
 * Code from ICW 2
 */

public class SecurityAspect
{
    //Users can and only can access their own profile or bookings
    public void doAccessCheck(String admin)
            throws Throwable
    {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String currentUser = ((UserDetails) authentication.getPrincipal()).getUsername();

        if (!currentUser.equals(admin))
        {
            throw new AccessDeniedException("Access Denied!");
        }
    }

}
