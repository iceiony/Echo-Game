/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package services;

import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author icerrr
 */
public class TurnController extends Thread{

    private UserServices userService;
    private Date startTime;

    @Override
    public void run() {

            synchronized(this){
            startTime=new Date();
            }
            
            try {
                sleep(userService.getTurnInterval()*60000);
            } catch (InterruptedException ex) {
                Logger.getLogger(UserServicesImpl.class.getName()).log(Level.INFO,"Game Turn Has ended");
            }
            userService.endTurn();
    }

    public void setUserServices(UserServices services)
    {
        this.userService=services;
    }
    
    public void closeIntervalManagement()
    {
        this.interrupt();
    }

    //returns the time elapsed in seconds
    public long getElapsedTime()
    {
        long auxTime=0;
        synchronized(this){
            if(startTime!=null)
            auxTime=startTime.getTime();
            }
        return ((new Date()).getTime()-auxTime)/1000;
    }

}
