/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package services;

import data.model.Activity;
import data.model.ActivityChoice;
import data.model.GameMode;
import data.model.Resource;
import data.model.BehaviourIndicator;
import java.io.OutputStream;
import java.util.List;
import org.springframework.context.ApplicationContext;

/**
 *
 * @author icerrr
 */
public interface AdminService {


    //These 3 methods are not protected by acegi.
    //They need to run localy before the application has an available DB
    public void createDB(ApplicationContext context);
    public void dropDB();
    public void resetAdminPassword(ApplicationContext context);
    
    /**
     * Creates a notification object and sends an event to all clients
     * @param role of the user that sends the message
     * @param message the actual message
     */
    public long createNotification(String sender,String message);

    public Resource createResource(String name,String logoUrl,String globalCap,String defaultUserCap);
    public boolean updateOrCreateResource(Resource resource);//may be dangerous
    public void deleteResource(String name,GameMode mode);
    public void deleteResource(Resource resource);

    public boolean updateOrCreateActivity(Activity activity);
    public void deleteActivity(Activity activity);
    public void deleteActivityChoice(ActivityChoice choice);

    public void renameCategory(String oldName,String newName);

    public boolean createOrUpdateActivityChoice(ActivityChoice choice);


    public void deleteBehaviourIndicator(BehaviourIndicator indicator);
    public boolean updateOrCreateBehaviourIndicator(BehaviourIndicator indicator);

    public GameMode createNewGameModeAfter(String currentMode,String newMode);
    public GameMode updateExistingGameMode(String currentName,String newName,int turnInterval,int maxTurn,String newDescription);
    public List<GameMode> getGameModeList();

    public void writeDinamicFileContents(String fileName,OutputStream stream);

    public void clearLogs();

    public void clearBehaviour();
    // private void getBehaviourIndicatorsFile(OutputStream stream);


}
