/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package services;
import data.model.Computable;
import java.util.List;
import org.nfunk.jep.JEP;
import java.util.logging.Level;
import java.util.logging.Logger;
/**
 * Class provides parser objcets that can evaluate a given expression.
 * ( Extend this class to pool the parser objects to avoid reparsing existing expressions )
 * @author icerrr
 */
public class ExpressionParserFactory {

    public static JEP getParser(String exp,List<Object> variables)
    {
        JEP parser=new JEP();
        parser.initFunTab(); // clear the contents of the function table
        parser.addStandardFunctions();
        //parser.setTraverse(true);//usefull for debuging
        parser.initSymTab();
        parser.setAllowUndeclared(true);

        if(variables!=null)
        for(Object varObj:variables)
        {
         try{
        Computable var=(Computable)varObj;
        if(var.getVariableName()!=null && !var.getVariableName().isEmpty())
            parser.addVariable(var.getVariableName(),var.getComputableValue());
         }
         catch(Exception e){
             //log the error
             Logger.getLogger(UserServicesImpl.class.getName())
                     .log(Level.WARNING,"Variable list contains item that is not Computable");
            };
        }

        parser.parseExpression(exp);
        return parser;
    }
}
