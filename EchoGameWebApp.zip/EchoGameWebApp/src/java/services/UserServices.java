/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package services;

import data.model.Activity;
import data.model.ActivityChoice;
import data.model.BehaviourIndicator;
import data.model.ChoiceCostExpression;
import data.model.GameMode;
import data.model.IndicatorOption;
import data.model.Notification;
import data.model.Resource;
import data.model.Variable;
import java.util.List;
import org.apache.wicket.model.Model;
import webpages.WebGameApplication;

/**
 *
 * @author icerrr
 */
public interface UserServices {

    public boolean authenticate(String username, String password);

    public boolean registerUser(String userName, String password);

    public List<BehaviourIndicator> getBehaviourIndicators();

    public List<List<Activity>> getActivityList();

    public List<String> getActivityCategories();

    public Notification getNotification(long id);

    public List<Resource> getResources();

    public List<List<Activity>> getActivityListEgarly();

    public ActivityChoice getActivityChoiceEagerly(long id);

    public GameMode currentGameMode();

    public void setGameMode(String mode);

    /**
     *
     * @param opex
     * @param variables list of objects that implement Computable
     * @return
     */
    public double evaluateExpression(String opex, List variables);

    public ChoiceCostExpression getCostByResourceAndChoice(long id, long id0);

    /**
     * @param choice = the choice
     * @param resIndex = the index of the Resource used in order to retrieve the ChoiceCostExpression
     * @param variableList
     * @return arrray returned ( 0-> OPEX ) and ( 1-> CAPEX)
     */
    public double[] calculateChoiceResourceCost(ActivityChoice choice, int resIndex, List<Variable> variableList);

    /**
     * Calculates the OPEX and CAPEX for the given resource and selection list
     * @param changed a boolean determening if the choice is a new one or if it was the choice from the previous turn
     * @param selectedChoices
     * @return double[2] ( 0-> opex , 1-> capex)
     */
    public double[] calcualteTotalResourceCost(long resId, List<List<Model<ActivityChoice>>> selectedChoices);

    /**
     * returns the allowed global cap for the giver resource
     */
    public double getResourceGlobalCap(Resource res);

    /**
     * returns the allowed local cap for the giver resource and username
     */
    public double getResourgeUserCap(Resource res, String username);

    //turn management
    public void startGameSession();

    public void endGameSession();

    public void startTurn();

    public void endTurn();

    public void notifyEndTurn();

    /**
     * returns the remaining turn time in seconds
     * @return the remaining turn time in seconds
     */
    public long getTimeRemaining();

    public long getTurnInterval();

    public int getTurnNumber();

    //game management
    public boolean hasGameStarted();

    public void recordUserBehaviour(String name, List<IndicatorOption> behaviourListPanel);

    public ActivityChoice returnDefaultActivityChoice(Activity activity, String username);

    public boolean saveUserChoices(String username, List<List<Model<ActivityChoice>>> selectedChoices);

    public double getAccumualtedCapDifference(String username, Long resourceId);

    public boolean wasEliminated(String username);

    public int getEliminatedNumber();

    public void sendNotificationToUser(String userName, String message);

    public void broadcastNotification(String message);

    public List<BehaviourIndicator> getUncompleatedIndicators(String userName);

    public void setApplication(WebGameApplication application);
}
