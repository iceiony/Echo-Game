/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package services;

import data.dao.ActivityDAO;
import data.dao.BehaviourDAO;
import data.dao.DatabaseDAO;
import data.dao.GameModeDAO;
import data.dao.NotificationDAO;
import data.dao.ResourceDAO;
import data.dao.UserDAO;
import data.dao.RoleDAO;

import data.model.*;
import java.io.IOException;
import java.util.LinkedList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import jxl.write.WriteException;


import org.acegisecurity.providers.ProviderManager;
import org.springframework.context.ApplicationContext;
import webpages.pagePanels.BehaviourDropList;
import webpages.pagePanels.BehaviourSlider;

import java.io.OutputStream;
import webpages.WebGameApplication;

//import com.extentech.ExtenXLS.*;
//import com.extentech.formats.XLS.*;
import jxl.*;

import data.dao.LogDAO;
import jxl.format.Colour;
import jxl.write.Label;
import jxl.write.Number;
import jxl.write.WritableCell;
import jxl.write.WritableCellFormat;
import jxl.write.WritableFont;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;
import org.acegisecurity.providers.encoding.PasswordEncoder;

/**
 *
 * @author icerrr
 */
public class AdimnServiceImpl implements AdminService {

    private DatabaseDAO databaseDAO;
    private UserDAO userDAO;
    private RoleDAO roleDAO;
    private BehaviourDAO behaviourDAO;
    private ActivityDAO activityDAO;
    private ResourceDAO resourceDAO;
    private NotificationDAO notificationDAO;
    private GameModeDAO gameModeDAO;
    private LogDAO logDAO;
    // private IChannelService cometdService;
    private UserServices userService;

    public AdimnServiceImpl(
            DatabaseDAO databaseDAO,
            UserDAO userDAO,
            RoleDAO roleDAO,
            BehaviourDAO behaviourDAO,
            ActivityDAO activityDAO,
            ResourceDAO resourceDAO,
            NotificationDAO notificationDAO,
            GameModeDAO gameModeDAO,
            UserServices userService,
            LogDAO logDAO) {
        this.databaseDAO = databaseDAO;
        this.userDAO = userDAO;
        this.roleDAO = roleDAO;
        this.behaviourDAO = behaviourDAO;
        this.activityDAO = activityDAO;
        this.resourceDAO = resourceDAO;
        this.notificationDAO = notificationDAO;
        this.gameModeDAO = gameModeDAO;
        this.userService = userService;
        this.logDAO = logDAO;
    }

    public void resetAdminPassword(ApplicationContext context) {
        GameUser adminUser = userDAO.getGameUser("admin");
        String password = (String) context.getBean("adminPassword");
        PasswordEncoder encoder = (PasswordEncoder) context.getBean("passwordEncoder");
        adminUser.setPassword(encoder.encodePassword(password, adminUser.getSalt()));
        userDAO.save(adminUser);
    }

    /**
     * Populates DB with dummy data for testing
     * (eg.: user roles)
     */
    private void populateDB(ApplicationContext context) {
        Role roleAdmin = new Role("ROLE_admin", "The absolute user of the application. Defines application configuration and retrieves statistics");
        Role roleUser = new Role("ROLE_user", "The gamer");
        Role roleAnonim = new Role("ROLE_anonymous", "Anonymous gamer. May be used for achieving privacy");//may not be used


        roleDAO.save(roleAdmin);
        roleDAO.save(roleUser);
        roleDAO.save(roleAnonim);


        //create the admin
        UserServices otherServices = userService;
        String password = (String) context.getBean("adminPassword");
        otherServices.registerUser("admin", password);
        GameUser admin = userDAO.getGameUser("admin");
        admin.setRole(roleAdmin);
        userDAO.save(admin);

        //create the default gameMode
        GameMode mode = new GameMode();
        mode.setName("default");
        mode.setDescription("Game Mode default description is displayed on main page");
        mode.setMaxTurns(50);
        mode.setTurnInterval(2);
        gameModeDAO.save(mode);


        //test data (will be changed/removed)

//------------------------------------------------------------------------------
        //behaviour indicators
        BehaviourIndicator indicator = new BehaviourIndicator();
        indicator.setDescription("Indicator 1 Description");
        indicator.setDisplayName("Indicator 1");
        indicator.setWicketClassName("BehaviourDropList");
        indicator.setWicketClass(BehaviourDropList.class);
        indicator.setDisplayOrder(1);
        indicator.setGameMode(mode);

        for (int i = 1; i <= 3; i++) {
            IndicatorOption option = new IndicatorOption();
            option.setBehaviour(indicator);
            option.setDescription("Option " + i + " description");
            option.setDisplayText("Option " + i);
            option.setOptionValue(i * 10);
            indicator.getOptions().add(option);
        }
        behaviourDAO.save(indicator);

        indicator = new BehaviourIndicator();
        //indicator.setDescription("Indicator 1 Description");
        indicator.setDisplayName("Indicator 2");
        indicator.setWicketClassName("BehaviourDropList");
        indicator.setWicketClass(BehaviourDropList.class);
        indicator.setDisplayOrder(2);
        indicator.setGameMode(mode);

        for (int i = 1; i <= 3; i++) {
            IndicatorOption option = new IndicatorOption();
            option.setBehaviour(indicator);
            //     option.setDescription("Option "+i+" description");
            option.setDisplayText("Option " + i);
            option.setOptionValue(i * 10);
            indicator.getOptions().add(option);
        }
        behaviourDAO.save(indicator);

        indicator = new BehaviourIndicator();
        indicator.setDisplayName("Opional name here");
        indicator.setDescription("Drag the slider to your hart's content");
        indicator.setWicketClassName("BehaviourSlider");
        indicator.setWicketClass(BehaviourSlider.class);
        indicator.setDisplayOrder(3);
        indicator.setGameMode(mode);
        IndicatorOption option = new IndicatorOption();
        option.setOptionValue(10);
        option.setMaxValue(20);
        option.setMinValue(0);
        option.setBehaviour(indicator);
        indicator.getOptions().add(option);
        behaviourDAO.save(indicator);

//------------------------------------------------------------------------------
        //activities and choices
        Activity activity = new Activity();
        activity.setDescription("Activity 1 Description");
        activity.setName("Activity 1");
        activity.setDisplayOrder(1);
        activity.setCategory("Cat1");
        activity.setGameMode(mode);

        for (int i = 1; i <= 3; i++) {
            ActivityChoice choice = new ActivityChoice();
            choice.setActivity(activity);
            choice.setDescription("Choice " + i + " description");
            choice.setName("Choice " + i);
            // choice.setValue(i*10);
            activity.getChoices().add(choice);
        }
        activityDAO.save(activity);

        activity = new Activity();
        activity.setDescription("Activity 2 Description");
        activity.setName("Activity 2");
        activity.setDisplayOrder(2);
        activity.setCategory("Cat1");
        activity.setGameMode(mode);

        for (int i = 1; i <= 3; i++) {
            ActivityChoice choice = new ActivityChoice();
            choice.setActivity(activity);
            choice.setDescription("Choice " + i + " description");
            choice.setName("Choice " + i);
            // choice.setValue(i*10);
            activity.getChoices().add(choice);
        }
        activityDAO.save(activity);

        activity = new Activity();
        activity.setDescription("Activity 2 Description");
        activity.setName("Activity 2");
        activity.setDisplayOrder(2);
        activity.setCategory("Cat2");
        activity.setGameMode(mode);

        for (int i = 1; i <= 3; i++) {
            ActivityChoice choice = new ActivityChoice();
            choice.setActivity(activity);
            choice.setDescription("Choice " + i + " description");
            choice.setName("Choice " + i);
            // choice.setValue(i*10);
            activity.getChoices().add(choice);
        }
        activityDAO.save(activity);
    }

    /**
     * Creates the DB based on the current hibernate mapping
     */
    public void createDB(ApplicationContext context) {
        databaseDAO.createDB();
        populateDB(context);
    }

    /**
     * Destroy the DB based on current hibernate mapping
     * (The mapping has corespond directly to the current DB in order to destroy it )
     */
    public void dropDB() {
        databaseDAO.destroyDB();
    }

    /**
     * Creates a notification object and sends an event to all clients
     * @param role of the user that sends the message
     * @param message the actual message
     */
    public long createNotification(String sender, String message) {
        Notification note = new Notification(userDAO.getGameUser(sender), message);
        return notificationDAO.save(note);

    }

    public Resource createResource(String name, String logoUrl, String globalCap, String defaultUserCap) {
        Resource res = new Resource();
        res.setName(name);
        res.setLogoURL(logoUrl);
        res.setGlobalCap(globalCap);
        res.setDefaultUserCap(defaultUserCap);
        res.setGameMode(gameModeDAO.getGameModeByName(userService.currentGameMode().getName()));
        resourceDAO.save(res);
        return res;
    }

    /**
     * Safe function.
     * The passed argument is not saved directly to avoid hibernate exceptions
     * of simultanuos updates.
     * @param resource
     * @return
     * -true if a new resource has been created or
     * -false if an existing resource has been updated
     */
    public boolean updateOrCreateResource(Resource resource) {
        Resource res = resourceDAO.getResourceById(resource.getId());
        boolean found = (res != null);
        if (found) {
            res.setName(resource.getName());
            res.setLogoURL(resource.getLogoURL());
            res.setGlobalCap(resource.getGlobalCap());
            res.setDefaultUserCap(resource.getDefaultUserCap());
            res.setAccumulates(resource.getAccumulates());
        } else {
            res = resource;
            res.setGameMode(gameModeDAO.getGameModeByName(userService.currentGameMode().getName()));
        }
       

        //to keep consistancy we have to add resource cost expressions for this resource under each choice
        if (!found)
        for(ActivityChoice choice:activityDAO.getChoicesWithCostExpressions())
        {
            ChoiceCostExpression exp=new ChoiceCostExpression();
            exp.setActivityChoice(choice);
            exp.setResource(resource);
            exp.setCapex("0");
            exp.setOpex("0");
         choice.getCostExpressions().add(exp);
        //    activityDAO.save(choice);
        }
        resourceDAO.save(res);

        return !found;
    }

    public void deleteResource(String name, GameMode mode) {
        resourceDAO.delete(resourceDAO.getResourceByName(name, mode));
    }

    public void deleteResource(Resource resource) {
        resourceDAO.delete(resourceDAO.getResourceById(resource.getId()));
    }

    public void renameCategory(String oldName, String newName) {
        activityDAO.renameCategory(oldName, newName);
    }

    /**
     * Safe method that saves changes made to an activity or creates an activity
     * with the specified configuration
     * @param activity
     * @return
     */
    public boolean updateOrCreateActivity(Activity activ) {
        Activity activity = activityDAO.getActivityById(activ.getId());
        boolean found = (activity != null);

        if (found) {
            activity.setName(activ.getName());
            activity.setDescription(activ.getDescription());
            activity.setDisplayOrder(activ.getDisplayOrder());
            activity.setCategory(activ.getCategory());
            activity.setChoiceFormula(activ.getChoiceFormula());
            //activity.setChoices(activ.getChoices());
            //delete orphan variables
            for (Variable var : activity.getVariables()) {
                if (!activ.getVariables().contains(var)) {
                    activityDAO.remove(var);
                }
            }

            activity.setVariables(activ.getVariables());
        } else {
            activity = activ;
            activity.setGameMode(gameModeDAO.getGameModeByName(userService.currentGameMode().getName()));
        }

//       activity.setGameMode(gameModeDAO.getGameModeByName(userService.currentGameMode().getName()));

        activityDAO.save(activity);
        return !found;
    }

    public void deleteActivity(Activity activity) {
        activityDAO.remove(activityDAO.getActivityById(activity.getId()));
    }

    public boolean createOrUpdateActivityChoice(ActivityChoice choice) {
        ActivityChoice cho = activityDAO.getActivityChoiceByIdEagerly(choice.getId());
        boolean found = (cho != null);

        if (found) {
            cho.setActivity(choice.getActivity());
            cho.setCostExpressions(choice.getCostExpressions());
            cho.setDescription(choice.getDescription());
            cho.setName(choice.getName());

        } else {
            cho = choice;
        }

        activityDAO.save(cho);

        return !found;
    }

    /**
     * NOTE: have to test safety
     * @param object
     */
    public void deleteActivityChoice(ActivityChoice choice) {
        ActivityChoice cho=activityDAO.getActivityChoiceById(choice.getId());
        activityDAO.removeFromSession(choice);
        activityDAO.remove(cho);
    }

    public List<GameMode> getGameModeList() {
        return gameModeDAO.getGameModes();
    }

    /**
     * Creates a new game mode and duplicates all the contents associated with the previous game mode
     * @param currentModeName
     * @param newModeName
     * @return
     */
    public GameMode createNewGameModeAfter(String currentModeName, String newModeName) {
        GameMode oldMode = gameModeDAO.getGameModeByName(currentModeName);

        GameMode newMode = new GameMode();
        newMode.setName(newModeName);
        newMode.setDescription(oldMode.getDescription());
        newMode.setMaxTurns(oldMode.getMaxTurns());
        newMode.setTurnInterval(oldMode.getTurnInterval());
        gameModeDAO.save(newMode);

        //copy all resources
        for (Resource res : resourceDAO.getAllResources(oldMode)) {
            Resource newRes = new Resource();
            newRes.setGameMode(newMode);
            newRes.setName(res.getName());
            newRes.setDefaultUserCap(res.getDefaultUserCap());
            newRes.setGlobalCap(res.getGlobalCap());
            newRes.setLogoURL(res.getLogoURL());
            newRes.setAccumulates(res.getAccumulates());
            resourceDAO.save(newRes);
        }
        List<Resource> newResourceList = resourceDAO.getAllResources(newMode);

        //copy all activities, choices and formulas
        for (List<Activity> byCategoryList : activityDAO.getActivities(false, oldMode)) {
            for (Activity activ : byCategoryList) {
                Activity newActiv = new Activity();
                newActiv.setGameMode(newMode);
                newActiv.setCategory(activ.getCategory());
                newActiv.setDescription(activ.getDescription());
                newActiv.setDisplayOrder(activ.getDisplayOrder());
                newActiv.setName(activ.getName());
                newActiv.setChoiceFormula(activ.getChoiceFormula());

                List<Variable> varList = new LinkedList<Variable>();
                for (Variable var : activ.getVariables()) {
                    Variable newVar = new Variable();
                    newVar.setDescription(var.getDescription());
                    newVar.setDiscrete(var.isDiscrete());
                    newVar.setMaxValue(var.getMaxValue());
                    newVar.setMinValue(var.getMinValue());
                    newVar.setName(var.getName());
                    newVar.setValue(var.getValue());

                    varList.add(newVar);
                }
                newActiv.setVariables(varList);

                List<ActivityChoice> choiceList = new LinkedList<ActivityChoice>();
                for (ActivityChoice choice : activ.getChoices()) {
                    ActivityChoice newChoice = new ActivityChoice();
                    newChoice.setActivity(newActiv);
                    newChoice.setDescription(choice.getDescription());
                    newChoice.setName(choice.getName());

                    List<ChoiceCostExpression> expressionList = new LinkedList<ChoiceCostExpression>();
                    for (int i = 0; i < choice.getCostExpressions().size(); i++) {
                        ChoiceCostExpression oldExpression = choice.getCostExpressions().get(i);
                        ChoiceCostExpression newExpression = new ChoiceCostExpression();
                        newExpression.setActivityChoice(newChoice);
                        newExpression.setCapex(oldExpression.getCapex());
                        newExpression.setOpex(oldExpression.getOpex());
                        newExpression.setResource(newResourceList.get(i));

                        expressionList.add(newExpression);
                    }
                    newChoice.setCostExpressions(expressionList);
                    activityDAO.save(newChoice);
                }
                newActiv.setChoices(choiceList);

                activityDAO.save(newActiv);
            }
        }

        //copy all BahaviourIndicators and Indicator objects
        for (BehaviourIndicator behaviour : behaviourDAO.getIndicators(oldMode)) {
            BehaviourIndicator newBehaviour = new BehaviourIndicator();
            newBehaviour.setGameMode(newMode);

            newBehaviour.setDescription(behaviour.getDescription());
            newBehaviour.setDisplayName(behaviour.getDisplayName());
            newBehaviour.setDisplayOrder(behaviour.getDisplayOrder());
            newBehaviour.setWicketClass(behaviour.getWicketClass());
            newBehaviour.setWicketClassName(behaviour.getWicketClassName());

            List<IndicatorOption> optionsList = new LinkedList<IndicatorOption>();
            for (IndicatorOption option : behaviour.getOptions()) {
                IndicatorOption newOption = new IndicatorOption();
                newOption.setBehaviour(newBehaviour);
                newOption.setDescription(option.getDescription());
                newOption.setDisplayText(option.getDisplayText());
                newOption.setMaxValue(option.getMinValue());
                newOption.setMaxValue(option.getMaxValue());
                newOption.setOptionValue(option.getOptionValue());
                newOption.setOptionStringValue(option.getOptionStringValue());

                optionsList.add(newOption);
            }
            newBehaviour.setOptions(optionsList);

            behaviourDAO.save(newBehaviour);
        }

        return newMode;
    }

    public GameMode updateExistingGameMode(String currentName, String newName, int turnInterval, int maxTurn, String newDescription) {
        GameMode mode = gameModeDAO.getGameModeByName(currentName);
        if (mode != null) {
            mode.setName(newName);
            mode.setDescription(newDescription);
            mode.setMaxTurns(maxTurn);
            mode.setTurnInterval(turnInterval);
            gameModeDAO.save(mode);
        }
        return mode;
    }

    public void deleteBehaviourIndicator(BehaviourIndicator indicator) {
        behaviourDAO.remove(indicator);
    }

    public boolean updateOrCreateBehaviourIndicator(BehaviourIndicator indicator) {
        BehaviourIndicator existing = behaviourDAO.getIndicatorById(indicator.getId());
        boolean found = (existing != null);
        if (found) {
            existing.setBindingName(indicator.getBindingName());
            existing.setDescription(indicator.getDescription());
            existing.setDisplayName(indicator.getDisplayName());
            existing.setDisplayOrder(indicator.getDisplayOrder());
            existing.setWicketClassName(indicator.getWicketClassName());
            behaviourDAO.removeUserIndicator(existing);
            try {
                existing.setWicketClass(Class.forName("webpages.pagePanels." + indicator.getWicketClassName()));
            } catch (Exception e) {
                existing.setWicketClassName("BehaviourDropList");
                existing.setWicketClass(BehaviourDropList.class);
            }
            for (IndicatorOption option : indicator.getOptions())
                if (!existing.getOptions().contains(option)) {
                        option.setBehaviour(existing);
                        behaviourDAO.save(option);
                        //existing.getOptions().add(option);
            }

            List<IndicatorOption> removedList=new LinkedList<IndicatorOption>();
            for (IndicatorOption option : existing.getOptions())
               if(!indicator.getOptions().contains(option))
                   removedList.add(option);

            for(IndicatorOption option: removedList)
            {
                existing.getOptions().remove(option);
                behaviourDAO.remove(option);
            }
            
         
        } else {
            existing = indicator;
            try {
                existing.setWicketClass(Class.forName("webpages.pagePanels." + indicator.getWicketClassName()));
            } catch (Exception e) {
                existing.setWicketClassName("BehaviourDropList");
                existing.setWicketClass(BehaviourDropList.class);
            }
            existing.setGameMode(gameModeDAO.getGameModeByName(userService.currentGameMode().getName()));
        }
        existing.setGameMode(gameModeDAO.getGameModeByName(userService.currentGameMode().getName()));
        behaviourDAO.save(existing);
        return !found;
    }
//
//    private void getBehaviourIndicatorsFile(OutputStream stream) {
//        GameMode mode = ((WebGameApplication) WebGameApplication.get()).getUserServices().currentGameMode();
//
//        WorkBookHandle excelBook = new WorkBookHandle();
//
//        FormatHandle fmx = new FormatHandle(excelBook);
//
//        fmx.setBackgroundColor(FormatHandle.COLOR_GOLD);
//        fmx.setBackgroundPattern(FormatHandle.PATTERN_FILLED);
//        fmx.setBold(true);
//
//
//        excelBook.setDupeStringMode(WorkBookHandle.SHAREDUPES);
//        excelBook.setStringEncodingMode(WorkBookHandle.STRING_ENCODING_COMPRESSED);
//
//        WorkSheetHandle excelSheet = null;
//
//        try {
//            excelSheet = excelBook.getWorkSheet("Sheet1");
//        } catch (WorkSheetNotFoundException ex) {
//            Logger.getLogger(AdimnServiceImpl.class.getName()).log(Level.SEVERE, null, ex);
//        }
//
//        if (excelSheet != null) {
//            excelSheet.setZoom((float) 1.25);
//            //retrieve a list of users that have participated in this currently selected gamemode
//            List<String> userNames = userDAO.getAllUserNames(mode);
//            if (userNames.size() <= 0) {
//                return;
//            }
//
//            int row = 0;
//            int col = 0;
//            //add a header listing the behavioru indicator names
//            CellHandle nameCell = excelSheet.add("User Name", row, col);
//
//            nameCell.setFormatHandle(fmx);
//            nameCell.getCol().setWidthInChars("User Name".length() * 2);
//
//            int formatId = nameCell.getFormatId();
//            //the folowing method assures that there is no
//            for (UserIndicatorValues value : userDAO.getUserIndicatorValues(userNames.get(0), mode)) {
//                BehaviourIndicator behaviour = value.getIndicatorOption().getBehaviour();
//                col++;
//                nameCell = excelSheet.add(behaviour.getDisplayName(), row, col, formatId);
//                nameCell.getCol().setWidthInChars(behaviour.getDisplayName().length() * 2);
//            }
//
//            //add the actual cells now
//            row = 1;
//            for (String userName : userNames) {
//                //add the username at the begging of the column
//                col = 0;
//                nameCell = excelSheet.add(userName, row, col, 1);
//
//                formatId = nameCell.getFormatId();
//                //add for each indicator option that he selected the numeric value and the string value
//                for (UserIndicatorValues value : userDAO.getUserIndicatorValues(userName, mode)) {
//                    col++;
//                    if (value.getStringValue() == null || value.getStringValue().length() <= 0) {
//                        excelSheet.fastAdd(value.getValue(), row, col, formatId);
//                    } else {
//                        excelSheet.fastAdd(value.getStringValue(), row, col, formatId);
//                    }
//                }
//
//            }
//
//            excelBook.writeBytes(stream);
//        }
//    }
//
//    private void getLogFile(OutputStream stream) {
//        GameMode mode = ((WebGameApplication) WebGameApplication.get()).getUserServices().currentGameMode();
//
//        WorkBookHandle excelBook = new WorkBookHandle();
//
//        FormatHandle fmx = new FormatHandle(excelBook);
//
//        fmx.setBackgroundColor(FormatHandle.COLOR_GOLD);
//        fmx.setBackgroundPattern(FormatHandle.PATTERN_FILLED);
//        fmx.setBold(true);
//
//        int row = 0;
//        int col = 0;
//        CellHandle auxCell;
//
//        excelBook.setDupeStringMode(WorkBookHandle.SHAREDUPES);
//        excelBook.setStringEncodingMode(WorkBookHandle.STRING_ENCODING_COMPRESSED);
//
//        WorkSheetHandle excelSheet = null;
//        try {
//            excelSheet = excelBook.getWorkSheet("Sheet1");
//        } catch (WorkSheetNotFoundException ex) {
//            Logger.getLogger(UserServicesImpl.class.getName()).log(Level.SEVERE, null, ex);
//        }
//        //retrieve activity logs
//        if (excelSheet != null) {
//            //retrieve a list of users that have participated in this currently selected gamemode
//            fmx.addCell(auxCell = excelSheet.add("User Name", row, col));
//            auxCell.getCol().setWidthInChars("User Name".length() * 2);
//            col++;
//            fmx.addCell(auxCell = excelSheet.add("Choice", row, col));
//            auxCell.getCol().setWidthInChars("Choice".length() * 2);
//            col++;
//            fmx.addCell(auxCell = excelSheet.add("Activity", row, col));
//            auxCell.getCol().setWidthInChars("Activity".length() * 2);
//            col++;
//            fmx.addCell(auxCell = excelSheet.add("Category", row, col));
//            auxCell.getCol().setWidthInChars("Category".length() * 2);
//            col++;
//            fmx.addCell(auxCell = excelSheet.add("Turn Nr.", row, col));
//            auxCell.getCol().setWidthInChars("Turn Nr.".length() * 2);
//            col++;
//            fmx.addCell(auxCell = excelSheet.add("Session Nr.", row, col));
//            auxCell.getCol().setWidthInChars("Session Nr.".length() * 2);
//            col++;
//
//            //retrieve activity data now
//            for (LoggedUserChoice loggedChoice : logDAO.getLogedChoices(mode.getId())) {
//                row++;
//                col = 0;
//                excelSheet.fastAdd(loggedChoice.getGameUser(), row, col, 1);
//                col++;
//                excelSheet.fastAdd(loggedChoice.getChoice(), row, col, 1);
//                col++;
//                excelSheet.fastAdd(loggedChoice.getActivity(), row, col, 1);
//                col++;
//                excelSheet.fastAdd(loggedChoice.getCategory(), row, col, 1);
//                col++;
//                excelSheet.fastAdd(loggedChoice.getGameTurn(), row, col, 1);
//                col++;
//                excelSheet.fastAdd(loggedChoice.getSessionNumber(), row, col, 1);
//                col++;
//            }
//        }
//        //retrive variable logs now
//        try {
//            excelSheet = excelBook.getWorkSheet("Sheet2");
//        } catch (WorkSheetNotFoundException ex) {
//            Logger.getLogger(UserServicesImpl.class.getName()).log(Level.SEVERE, null, ex);
//        }
//        if (excelSheet != null) {
//            row = 0;
//            col = 0;
//            fmx.addCell(auxCell = excelSheet.add("User Name", row, col));
//            auxCell.getCol().setWidthInChars("User Name".length() * 2);
//            col++;
//            fmx.addCell(auxCell = excelSheet.add("Variable", row, col));
//            auxCell.getCol().setWidthInChars("Variable".length() * 2);
//            col++;
//            fmx.addCell(auxCell = excelSheet.add("Activity", row, col));
//            auxCell.getCol().setWidthInChars("Activity".length() * 2);
//            col++;
//            fmx.addCell(auxCell = excelSheet.add("Category", row, col));
//            auxCell.getCol().setWidthInChars("Category".length() * 2);
//            col++;
//            fmx.addCell(auxCell = excelSheet.add("Value", row, col));
//            auxCell.getCol().setWidthInChars("Value".length());
//            col++;
//            fmx.addCell(auxCell = excelSheet.add("Game Turn", row, col));
//            auxCell.getCol().setWidthInChars("Game Turn".length());
//            col++;
//            fmx.addCell(auxCell = excelSheet.add("Session Nr.", row, col));
//            auxCell.getCol().setWidthInChars("Session Nr.".length() * 2);
//            col++;
//
//            for (LoggedUserVariable loggedVar : logDAO.getLoggedVariables(mode.getId())) {
//                row++;
//                col = 0;
//                excelSheet.fastAdd(loggedVar.getGameUser(), row, col, 1);
//                col++;
//                excelSheet.fastAdd(loggedVar.getVariable(), row, col, 1);
//                col++;
//                excelSheet.fastAdd(loggedVar.getActivity(), row, col, 1);
//                col++;
//                excelSheet.fastAdd(loggedVar.getCategory(), row, col, 1);
//                col++;
//                excelSheet.fastAdd(loggedVar.getValue(), row, col, 1);
//                col++;
//                excelSheet.fastAdd(loggedVar.getGameTurn(), row, col, 1);
//                col++;
//                excelSheet.fastAdd(loggedVar.getSessionNumber(), row, col, 1);
//                col++;
//            }
//        }
//
//        try {
//            excelSheet = excelBook.getWorkSheet("Sheet3");
//        } catch (WorkSheetNotFoundException ex) {
//            Logger.getLogger(AdimnServiceImpl.class.getName()).log(Level.SEVERE, null, ex);
//        }
//        if (excelSheet != null) {
//            row = 0;
//            col = 0;
//            fmx.addCell(auxCell = excelSheet.add("User Name", row, col));
//            auxCell.getCol().setWidthInChars("User Name".length() * 2);
//            col++;
//            fmx.addCell(auxCell = excelSheet.add("Resource", row, col));
//            auxCell.getCol().setWidthInChars("Resource".length() * 2);
//            col++;
//            fmx.addCell(auxCell = excelSheet.add("User Cap", row, col));
//            auxCell.getCol().setWidthInChars("Cost".length());
//            col++;
//            fmx.addCell(auxCell = excelSheet.add("Cost", row, col));
//            auxCell.getCol().setWidthInChars("Cost".length()*2);
//            col++;
//            fmx.addCell(auxCell = excelSheet.add("Game Turn", row, col));
//            auxCell.getCol().setWidthInChars("Game Turn".length());
//            col++;
//            fmx.addCell(auxCell = excelSheet.add("Session Nr.", row, col));
//            auxCell.getCol().setWidthInChars("Session Nr.".length() * 2);
//            col++;
//
//            for (LoggedUserResource loggedRes : logDAO.getLoggedResources(mode.getId())) {
//                row++;
//                col = 0;
//                excelSheet.fastAdd(loggedRes.getGameuser(), row, col, 1);
//                col++;
//                excelSheet.fastAdd(loggedRes.getResource(), row, col, 1);
//                col++;
//                excelSheet.fastAdd(loggedRes.getUser_cap(), row, col, 1);
//                col++;
//                excelSheet.fastAdd(loggedRes.getCost(), row, col, 1);
//                col++;
//                excelSheet.fastAdd(loggedRes.getGameTurn(), row, col, 1);
//                col++;
//                excelSheet.fastAdd(loggedRes.getSessionNumber(), row, col, 1);
//                col++;
//            }
//
//        }
//        excelBook.writeBytes(stream);
//
//    }

    private void getBehaviourIndicatorsFile(OutputStream stream) throws IOException, WriteException {
        GameMode mode = ((WebGameApplication) WebGameApplication.get()).getUserServices().currentGameMode();
        WritableWorkbook workBook = Workbook.createWorkbook(stream);
        WritableSheet workSheet = workBook.createSheet("Sheet1", 10);


        WritableFont headerFont = new WritableFont(WritableFont.ARIAL, 12, WritableFont.BOLD);
        WritableCellFormat headerBackground = new WritableCellFormat(headerFont);

        headerBackground.setWrap(true);
        headerBackground.setBackground(Colour.GOLD);

        int row = 0;
        int col = 0;

        List<String> userNames = userDAO.getAllUserNames(mode);
        if (userNames.size() <= 0) {
            workBook.close();
            return;
        }

        Label label = new Label(col, row, "User Name", headerBackground);
        workSheet.addCell(label);
        workSheet.setColumnView(col, "User Name".length() * 2);

        for (UserIndicatorValues value : userDAO.getUserIndicatorValues(userNames.get(0), mode)) {
            BehaviourIndicator behaviour = value.getBehaviour();
            col++;
            label = new Label(col, row, behaviour.getDisplayName(), headerBackground);
            workSheet.addCell(label);
            workSheet.setColumnView(col, behaviour.getDisplayName().length() * 2);
        }

        for (String userName : userNames) {
            //add the username at the begging of the column
            row++;
            col = 0;
            label = new Label(col, row, userName);
            workSheet.addCell(label);
            //add for each indicator option that he selected the numeric value and the string value
            for (UserIndicatorValues value : userDAO.getUserIndicatorValues(userName, mode)) {
                col++;
                if (!value.isHidden()) {
                    if (value.getStringValue() == null || value.getStringValue().length() <= 0) {
                        if (value.getBehaviour().getOptions().size() > 1) {
                            workSheet.addCell(new Label(col, row, value.getIndicatorName()));
                        } else {
                            workSheet.addCell(new Number(col, row, value.getValue()));
                        }

                    } else {
                        workSheet.addCell(new Label(col, row, value.getStringValue()));
                    }
                }
            }
        }


        workBook.write();
        workBook.close();
    }

    private void getLogFile(OutputStream stream) throws IOException, WriteException {
        GameMode mode = ((WebGameApplication) WebGameApplication.get()).getUserServices().currentGameMode();
        WritableWorkbook workBook = Workbook.createWorkbook(stream);

        WritableFont headerFont = new WritableFont(WritableFont.ARIAL, 12, WritableFont.BOLD);
        WritableCellFormat headerBackground = new WritableCellFormat(headerFont);

        headerBackground.setWrap(true);
        headerBackground.setBackground(Colour.GOLD);

        //retrive activity choice logs
        WritableSheet workSheet = workBook.createSheet("Sheet1", 1);



        int row = 0;
        int col = 0;
        Label label = new Label(col, row, "User Name", headerBackground);
        workSheet.addCell(label);
        workSheet.setColumnView(col, "User Name".length() * 2);
        col++;
        label = new Label(col, row, "Choice", headerBackground);
        workSheet.addCell(label);
        workSheet.setColumnView(col, "Choice".length() * 2);
        col++;
        label = new Label(col, row, "Activity", headerBackground);
        workSheet.addCell(label);
        workSheet.setColumnView(col, "Activity".length() * 2);
        col++;
        label = new Label(col, row, "Category", headerBackground);
        workSheet.addCell(label);
        workSheet.setColumnView(col, "Category".length() * 2);
        col++;
        label = new Label(col, row, "Game Turn", headerBackground);
        workSheet.addCell(label);
        workSheet.setColumnView(col, "Game Turn".length() + 3);
        col++;
        label = new Label(col, row, "Session Nr.", headerBackground);
        workSheet.addCell(label);
        workSheet.setColumnView(col, "Session Nr.".length() + 3);
        col++;
        for (LoggedUserChoice loggedChoice : logDAO.getLogedChoices(mode.getId())) {
            row++;
            col = 0;

            workSheet.addCell(new Label(col, row, loggedChoice.getGameUser()));
            col++;
            workSheet.addCell(new Label(col, row, loggedChoice.getChoice()));
            col++;
            workSheet.addCell(new Label(col, row, loggedChoice.getActivity()));
            col++;
            workSheet.addCell(new Label(col, row, loggedChoice.getCategory()));
            col++;
            workSheet.addCell(new Number(col, row, loggedChoice.getGameTurn()));
            col++;
            workSheet.addCell(new Number(col, row, loggedChoice.getSessionNumber()));
            col++;
        }


        //retrieve resources logs
        workSheet = workBook.createSheet("Sheet2",2);


        row = 0;
        col = 0;
        label = new Label(col, row, "User Name", headerBackground);
        workSheet.addCell(label);
        workSheet.setColumnView(col, "User Name".length() * 2);
        col++;
        label = new Label(col, row, "Resource", headerBackground);
        workSheet.addCell(label);
        workSheet.setColumnView(col, "Resource".length() * 2);
        col++;
        label = new Label(col, row, "User Cap", headerBackground);
        workSheet.addCell(label);
        workSheet.setColumnView(col, "User Cap".length() * 2);
        col++;
        label = new Label(col, row, "Cost", headerBackground);
        workSheet.addCell(label);
        workSheet.setColumnView(col, "Cost".length() * 2);
        col++;
        label = new Label(col, row, "Game Turn", headerBackground);
        workSheet.addCell(label);
        workSheet.setColumnView(col, "Game Turn".length() + 3);
        col++;
        label = new Label(col, row, "Session Nr.", headerBackground);
        workSheet.addCell(label);
        workSheet.setColumnView(col, "Session Nr.".length() + 3);
        col++;


        for (LoggedUserResource loggedRes : logDAO.getLoggedResources(mode.getId())) {
            row++;
            col = 0;

            workSheet.addCell(new Label(col, row, loggedRes.getGameuser()));
            col++;
            workSheet.addCell(new Label(col, row, loggedRes.getResource()));
            col++;
            workSheet.addCell(new Number(col, row, loggedRes.getUser_cap()));
            col++;
            workSheet.addCell(new Number(col, row, loggedRes.getCost()));
            col++;
            workSheet.addCell(new Number(col, row, loggedRes.getGameTurn()));
            col++;
            workSheet.addCell(new Number(col, row, loggedRes.getSessionNumber()));
            col++;
        }

        //retrieve variable logs
        workSheet = workBook.createSheet("Sheet3", 3);

        row = 0;
        col = 0;
        label = new Label(col, row, "User Name", headerBackground);
        workSheet.addCell(label);
        workSheet.setColumnView(col, "User Name".length() * 2);
        col++;
        label = new Label(col, row, "Variable", headerBackground);
        workSheet.addCell(label);
        workSheet.setColumnView(col, "Variable".length() * 2);
        col++;
        label = new Label(col, row, "Activity", headerBackground);
        workSheet.addCell(label);
        workSheet.setColumnView(col, "Activity".length() * 2);
        col++;
        label = new Label(col, row, "Category", headerBackground);
        workSheet.addCell(label);
        workSheet.setColumnView(col, "Category".length() * 2);
        col++;
        label = new Label(col, row, "Value", headerBackground);
        workSheet.addCell(label);
        workSheet.setColumnView(col, "Value".length() * 2);
        col++;
        label = new Label(col, row, "Game Turn", headerBackground);
        workSheet.addCell(label);
        workSheet.setColumnView(col, "Game Turn".length() + 3);
        col++;
        label = new Label(col, row, "Session Nr.", headerBackground);
        workSheet.addCell(label);
        workSheet.setColumnView(col, "Session Nr.".length() + 3);
        col++;

        for (LoggedUserVariable loggedVar : logDAO.getLoggedVariables(mode.getId())) {
            row++;
            col = 0;

            workSheet.addCell(new Label(col, row, loggedVar.getGameUser()));
            col++;
            workSheet.addCell(new Label(col, row, loggedVar.getVariable()));
            col++;
            workSheet.addCell(new Label(col, row, loggedVar.getActivity()));
            col++;
            workSheet.addCell(new Label(col, row, loggedVar.getCategory()));
            col++;
            workSheet.addCell(new Number(col, row, loggedVar.getValue()));
            col++;
            workSheet.addCell(new Number(col, row, loggedVar.getGameTurn()));
            col++;
            workSheet.addCell(new Number(col, row, loggedVar.getSessionNumber()));
            col++;
        }



        workBook.write();
        workBook.close();
    }

    public void writeDinamicFileContents(String fileName, OutputStream stream) {
        if (fileName.equals("behaviour.xls")) {
            try {
                getBehaviourIndicatorsFile(stream);
            } catch (Exception ex) {
                Logger.getLogger(UserServicesImpl.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        if (fileName.equals("logs.xls")) {
            try {
                getLogFile(stream);
            } catch (Exception ex) {
                Logger.getLogger(UserServicesImpl.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    public void clearLogs() {
        logDAO.clearActions();
        logDAO.clearVariables();
        logDAO.clearResources();
    }

    public void clearBehaviour() {
        userDAO.clearUserBehaviour();
    }
}
