/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package services;

import data.dao.ActivityDAO;
import data.dao.BehaviourDAO;
import data.dao.GameModeDAO;
import data.dao.LogDAO;
import data.dao.NotificationDAO;
import data.dao.ResourceDAO;
import data.dao.RoleDAO;
import data.dao.UserDAO;
import data.model.Activity;
import data.model.ActivityChoice;
import data.model.BehaviourIndicator;
import data.model.ChoiceCostExpression;
import data.model.Computable;
import data.model.GameMode;
import data.model.GameUser;
import data.model.IndicatorOption;
import data.model.LoggedUserChoice;
import data.model.LoggedUserResource;
import data.model.LoggedUserVariable;
import data.model.Notification;
import data.model.Resource;
import data.model.UserChoices;
import data.model.UserIndicatorValues;
import data.model.UserResource;
import data.model.Variable;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;
import org.acegisecurity.Authentication;
import org.acegisecurity.AuthenticationException;
import org.acegisecurity.BadCredentialsException;
import org.acegisecurity.context.SecurityContextHolder;
import org.acegisecurity.providers.ProviderManager;
import org.acegisecurity.providers.UsernamePasswordAuthenticationToken;
import org.acegisecurity.providers.encoding.PasswordEncoder;



import java.util.logging.Level;
import java.util.logging.Logger;
import org.apache.jk.core.Msg;
import org.apache.wicket.model.Model;
import org.joda.time.field.RemainderDateTimeField;
import org.nfunk.jep.JEP;
import org.wicketstuff.push.ChannelEvent;
import webpages.WebGameApplication;


/**
 *
 * @author icerrr
 */
public class UserServicesImpl implements UserServices {

    private UserDAO userDAO;
    private RoleDAO roleDAO;
    private BehaviourDAO behaviourDAO;
    private ActivityDAO activityDAO;
    private ResourceDAO resourceDAO;
    private NotificationDAO notificationDAO;
    private GameModeDAO gameModeDAO;
    private LogDAO logDAO;
    private PasswordEncoder encoder;
    private static final Logger logger = Logger.getLogger(UserServicesImpl.class.getCanonicalName());
    private ProviderManager authenticationManager;
    private GameMode mode;
    private TurnController turnIntervalManager;
    private int gameTurn;
    private int sessionNumber;
    private boolean gameStarted;
    private final Map userTurnMap;//manages the restriction of users not beeing able to submit twice for the same gameturn
    //the map is also used to determine users who were not able to submit their chioces
    private Set<String> eliminatedUsers;
    private final Object eliminationLock = new Object();
    private double[] globalCost;
    private WebGameApplication application ;

    public UserServicesImpl(
            UserDAO userDAO,
            RoleDAO roleDAO,
            BehaviourDAO behaviourDAO,
            ActivityDAO activityDAO,
            ResourceDAO resourceDAO,
            NotificationDAO notificationDAO,
            GameModeDAO gameModeDAO,
            ProviderManager authenticationManager,
            PasswordEncoder encoder,
            LogDAO logDAO) {
        this.userDAO = userDAO;
        this.roleDAO = roleDAO;
        this.behaviourDAO = behaviourDAO;
        this.activityDAO = activityDAO;
        this.resourceDAO = resourceDAO;
        this.notificationDAO = notificationDAO;
        this.gameModeDAO = gameModeDAO;
        this.authenticationManager = authenticationManager;
        this.encoder = encoder;
        this.logDAO = logDAO;
        //set the default selected game-mode


        List<GameMode> list = null;
        try {
            list = gameModeDAO.getGameModes();
        } catch (Exception e) {
            logger.info("Application may be deploying.");
        }


        if (list != null && list.size() > 0) {
            mode = list.get(0);
        } else {
            mode = new GameMode();
            mode.setName("warning");
            mode.setDescription("Warning, no existing game mode!!! This is a sign that the application was not "
                    + "properly deployed or database information has been deleted. Run main.class to create the application database"
                    + "and initial configuration");
        }

        //the game turn starts at 1
        gameTurn = 1;

        gameStarted = false;

        userTurnMap = new TreeMap();
    }

    //method from ICW-2 courswork
    public boolean authenticate(String username, String password) {
        String u = username == null ? "" : username.trim();
        String p = password == null ? "" : password.trim();
        // Create an Acegi authentication request.
        UsernamePasswordAuthenticationToken authRequest = new UsernamePasswordAuthenticationToken(u, p);

        Object principal = authRequest.getPrincipal();
        logger.info("Attempting to authenticate: " + principal);
        try {
            Authentication auth = authenticationManager.doAuthentication(authRequest);
            SecurityContextHolder.getContext().setAuthentication(auth);

            logger.info("Login by user '" + principal + "'.");
            return true;
        } catch (BadCredentialsException e) {
            logger.info("Failed login by user '" + principal + "'.");
            SecurityContextHolder.getContext().setAuthentication(null);
            return false;
        } catch (AuthenticationException e) {
            logger.log(Level.WARNING, "Could not authenticate a user", e);
            SecurityContextHolder.getContext().setAuthentication(null);
            return false;
        } catch (RuntimeException e) {
            logger.log(Level.SEVERE, "Unexpected exception while authenticating a user", e);
            SecurityContextHolder.getContext().setAuthentication(null);
            throw e;
        }
    }

    public boolean registerUser(String userName, String password) {
        userName = userName.trim();
        password = password.trim();
        if (userDAO.getGameUser(userName) != null) {
            return false;
        } else {
            GameUser newUser = new GameUser(userName);
            Random rand = new Random(new Date().getTime());
            newUser.setSalt(new Integer(rand.nextInt()));
            newUser.setPassword(encoder.encodePassword(password, newUser.getSalt()));
            newUser.setRole(roleDAO.get("ROLE_user"));
            userDAO.save(newUser);
            return true;
        }
    }

    public List<BehaviourIndicator> getBehaviourIndicators() {
        return behaviourDAO.getIndicators(mode);
    }

    public List<List<Activity>> getActivityList() {
        return activityDAO.getActivities(false, mode);
    }

    public List<List<Activity>> getActivityListEgarly() {
        return activityDAO.getActivities(true, mode);
    }

    public List<String> getActivityCategories() {
        return activityDAO.getCategories(mode);
    }

    /**
     * Returns the notification coresponding to the passed id
     * @return
     */
    public Notification getNotification(long id) {
        return notificationDAO.getNotification(id);
    }

    public List<Resource> getResources() {
        return resourceDAO.getAllResources(mode);
    }

    public GameMode currentGameMode() {
        return mode;
    }

    public void setGameMode(String newModeName) {
        this.mode = gameModeDAO.getGameModeByName(newModeName);
    }

    public double evaluateExpression(String exp, List variables) {

        if (exp == null || exp.isEmpty()) {
            exp = "0";//safety if
        }
        JEP parser = ExpressionParserFactory.getParser(exp, variables);

        parser.addVariable("t", gameTurn);//add  the turn variable

        int nrOfUsers = 0;
        //for the first turn the number of users playing is the number of users logged into the game
        //after that , only users that have pressed the submit button are playing the others are ignored
        if (gameTurn == 1) {
            nrOfUsers = ((WebGameApplication) WebGameApplication.get()).getNumberOfLoggedUsers();

        } else {
            synchronized (userTurnMap) {
                nrOfUsers = userTurnMap.size();
            }
        }
        int eliminated = 0;
        if (eliminatedUsers != null) {
            synchronized (eliminationLock) {
                eliminated = eliminatedUsers.size();
            }
            //add the number of users is the game as the total number of users ever in the game - the number of elminated users
        }
        parser.addVariable("n", nrOfUsers - eliminated);

        return parser.getValue();
    }

    public ActivityChoice getActivityChoiceEagerly(long id) {
        return activityDAO.getActivityChoiceByIdEagerly(id);
    }

    /**
     *
     * @param id resource id
     * @param id0 choice id
     * @return
     */
    public ChoiceCostExpression getCostByResourceAndChoice(long id, long id0) {
        ChoiceCostExpression exp = activityDAO.getCostbyResourceAndChoice(id, id0);
        return exp;
    }

    /*
     * Returns the turn interval in minutes
     */
    public long getTurnInterval() {
        return (long) (mode.getTurnInterval());
    }

    public void startGameSession() {
        //get a distinct session number for the new session
        sessionNumber = activityDAO.getMaxSessionNumber() + 1;
        globalCost = new double[resourceDAO.getAllResources(mode).size()];
        eliminatedUsers = new TreeSet<String>();
        gameTurn = 1;
        startTurn();
        gameStarted = true;
    }

    public void startTurn() {

        //cleared the old summed globel caps
        for (int i = 0; i < globalCost.length; i++) {
            globalCost[i] = 0;
        }
        turnIntervalManager = new TurnController();
        turnIntervalManager.setUserServices(this);
        //start the thread that ends the turn when time elapes
        turnIntervalManager.start();

        //send a push notification to all connected clients.
        //this will inform them the turn has started
       if(application!=null){
        ChannelEvent event = new ChannelEvent(application.getFeedbackChannel());

        //to send particular messages to particular users , add the messages to the event
        //using the username as key
        for (Object userObj : userTurnMap.keySet()) {
            String username = (String) userObj;
            event.addData(username, "Congratulations on passing <br/> last turn <br/> &nbsp;");
            //note the message can be HTML
        }
         application.getCometd().publish(event);
       }
    }

    public void endTurn() {
        //do stuff related to end of game turn
        //eliminate the users that did not manage to make any choice
        synchronized (userTurnMap) {
            for (Object userObject : userTurnMap.keySet()) {
                Integer lastTurn = (Integer) userTurnMap.get(userObject);
                if (lastTurn.intValue() < gameTurn) {
                    String username = (String) userObject;
                    synchronized (eliminationLock) {
                        eliminatedUsers.add(username);
                    }
                    userTurnMap.remove(userObject);
                    //send a notification letting the user know of the elimination
                   
                    ChannelEvent event = new ChannelEvent(application.getNotificationChannel());
                    event.addData("message_receiver", username);
                    event.addData("message_text",
                            "<h1 style='color:red'>Eliminated</h1>"
                            + "You were not able to satisfy the resource cost requirements and have been eliminated."
                            + "Thank you for playing.");
                    application.getCometd().publish(event);
                }
            }
        }
        //test if global consumption is within limits

        gameTurn++;
        if (gameTurn > mode.getMaxTurns() || !gameStarted) {
            endGameSession();
        } else {
            startTurn();
        }
    }

    public void notifyEndTurn() {
        turnIntervalManager.closeIntervalManagement();
    }

    public void endGameSession() {
        gameStarted = false;
        turnIntervalManager.closeIntervalManagement();
    }

    public boolean hasGameStarted() {
        return gameStarted;
    }

    public int getTurnNumber() {
        return gameTurn;
    }

    /** 
     * returns the remaining turn time in seconds
     * @return the remaining turn time in seconds
     */
    public long getTimeRemaining() {
        if (gameStarted) {
            return getTurnInterval() * 60 - turnIntervalManager.getElapsedTime();
        } else {
            return 0;
        }
    }

    /**
     * Records the user's behaviour indicators and also sets his initial choices
     * @param name
     * @param behaviourList
     */
    public void recordUserBehaviour(String name, List<IndicatorOption> behaviourList) {
        GameUser user = userDAO.getGameUser(name);

        for (IndicatorOption option : behaviourList) {
            UserIndicatorValues user_indicator = new UserIndicatorValues();
            user_indicator.setIndicatorName(option.getDisplayText());
            user_indicator.setBehaviour(option.getBehaviour());
            user_indicator.setGameUser(user);
            user_indicator.setValue(option.getOptionValue());
            user_indicator.setStringValue(option.getOptionStringValue());
            user_indicator.setHidden(option.isHidden());
            user.getIndicatorValues().add(user_indicator);

        }

        for (List<Activity> activityList : activityDAO.getActivities(false, mode)) {
            for (Activity activity : activityList) {
                if (activity.getChoiceFormula() != null && !activity.getChoiceFormula().isEmpty()) {
                    JEP parse = ExpressionParserFactory.getParser(activity.getChoiceFormula(), null);
                    //add the current game turn as a variable
                    parse.addVariable("t", gameTurn);
                    //add as variables all user indicators with a binded variable name
                    for (UserIndicatorValues value : user.getIndicatorValues()) {
                        BehaviourIndicator behaviour = value.getBehaviour();
                        if (behaviour.getBindingName() != null
                                && !behaviour.getBindingName().isEmpty()) {
                            parse.addVariable(behaviour.getBindingName(), value.getValue());
                        }
                    }

                    //evaluate expression
                    //parse must output an number representing the index of the desired ActivityChoice
                    int index = (int) parse.getValue();
                    //if the returned value is outside the existing index range
                    //the activity will have no default choice
                    if (index >= 0 && index < activity.getChoices().size()) {
                        UserChoices choice = new UserChoices();
                        choice.setChoice(activity.getChoices().get(index));
                        choice.setGameUser(user);
                        if (gameStarted) {
                            choice.setSessionNumber(sessionNumber);
                        }
                        user.getUserChoices().add(choice);
                    }
                }
            }
        }

        //by saving the user , all the information about him will be persisted
        userDAO.save(user);
    }

    /**
     * Tests if there is any UserChioce for that activity. In case of succes it returns the corresponding
     * ActivityChoice object attached to the activity argument.
     * ( IT DOES NOT RETURN THE OBJECT STORED IN THE DATABASE )
     * @param activity
     * @param username
     * @return null if there is no existing UserChoice
     */
    public ActivityChoice returnDefaultActivityChoice(Activity activity, String username) {

        UserChoices choice = activityDAO.getStoredChoice(activity, username);
        if (choice != null && choice.getSessionNumber() == sessionNumber) {
            int index = activity.getChoices().indexOf(choice.getChoice());
            if (index >= 0) {
                return activity.getChoices().get(index);
            } else {
                return null;
            }
        } else {
            if (choice!=null)
            {
                //the session number is wrong and we have to delete all choices
                userDAO.deleteAllUserChoices(username);
                choice=null;
            }
            if (activity.getChoiceFormula() != null && !activity.getChoiceFormula().isEmpty()) {
                //retrieve the user's behaviour list and calculate the choice for the new session
                //this is to prevent errors that may occur as a result of changes made to the game mode's configuration
                GameUser user = userDAO.getGameUser(username);

                //calculate the index
                int index = (int) evaluateExpression(activity.getChoiceFormula(), user.getIndicatorValues());
                if (index >= 0 && index < activity.getChoices().size()) {
                    if (choice == null) {
                        choice = new UserChoices();
                    }
                    choice.setChoice(activity.getChoices().get(index));choice.setGameUser(user);
                    choice.setSessionNumber(sessionNumber);
                    userDAO.save(choice);
                    return activity.getChoices().get(index);
                } else {
                    if (choice != null) {
                        userDAO.remove(choice);
                    }
                    return null;
                }
            } else {
                return null;
            }
        }
    }

    /**
     * Calculates the OPEX and CAPEX for the given resource and selection list
     * @param changed a boolean determening if the choice is a new one or if it was the choice from the previous turn
     * @param selectedChoices
     * @return double[2] ( 0-> opex , 1-> capex)
     */
    public double[] calcualteTotalResourceCost(long resId, List<List<Model<ActivityChoice>>> selectedChoices) {
        double[] expValues = {0, 0};
        //activityPanel does not eagerly retrieve the activity list
        //this panel has to retrieve CostExpressions on its own
        for (List<Model<ActivityChoice>> choiceByCategory : selectedChoices) {
            for (Model<ActivityChoice> choiceModel : choiceByCategory) {
                ActivityChoice choice = choiceModel.getObject();
                if (choice != null) {
                    ChoiceCostExpression expression =
                            getCostByResourceAndChoice(resId, choice.getId());
                    if (expression != null) {
                        expValues[0] += evaluateExpression(expression.getOpex(), choice.getActivity().getVariables());
                        if (choice.isWasChanged()) {
                            expValues[1] += evaluateExpression(expression.getCapex(), choice.getActivity().getVariables());
                        }
                    }
                }
            }
        }
        return expValues;
    }

    public boolean saveUserChoices(String username, List<List<Model<ActivityChoice>>> selectedChoices) {

        //test if game started or not
        if (!gameStarted) {
            return false;
        }
        if (wasEliminated(username)) {
            return false;
        }
        //test if the user had submited the info once before
        Integer lastSave = null;
        synchronized (userTurnMap) {
            lastSave = (Integer) userTurnMap.get(username);
        }
        if (lastSave != null && lastSave.intValue() == gameTurn) {
            return false;
        }

        boolean wereAllSafe = true;
        List<Resource> resourceList = resourceDAO.getAllResources(mode);

        //   double[] resourceDifferences = new double[resourceList.size()];
        double[] resourceCaps = new double[resourceList.size()];
        double[] resourceCost = new double[resourceList.size()];

        for (Resource resource : resourceList) {
            double cost[] = calcualteTotalResourceCost(resource.getId(), selectedChoices);
            double resCost = cost[0] + cost[1];
            //double userCap = evaluateExpression(resource.getDefaultUserCap(), null);
            double userCap= getResourgeUserCap(resource, username);

            //if the resource accumulates from one turn the other the user cap should be extended by the accumulated value
            if (resource.getAccumulates()) {
                UserResource userResource = userDAO.getLatestUserResourceByResourceID(username, resource.getId());
                if (userResource != null && userResource.getSessionNumber() == sessionNumber) {
                    userCap += userResource.getAccumulatedValue();
                }
            }

            if (resCost > userCap) {
                //warn the user that he exceedes the resource cap and he cannot submit his choices
                sendNotificationToUser(username, "<h1 style='color:red'>Warning !</h1> The resource cost for your current choices exceed the allowed amount. "
                        + "If you cannot find a way to satisfy this requirement by the end of the turn, you will "
                        + "fail the game and be eliminated. "
                        + "Click the Preview button underneath the GlobalProjections panel,the cost for the resources you exceed are marked in "
                        + "<span style='color:red'>red</span>");

                return false;//we don't accept users that exceed the user cap
            } else {
                //warn the user when he was close to exceeding the resource caps ( if hes costs were over 70% of the allowed amount)
                if (resCost > userCap*0.7 ) {
                    wereAllSafe = false;
                }
                resourceCost[resourceList.indexOf(resource)] = resCost;
                resourceCaps[resourceList.indexOf(resource)] = userCap;
            }
        }
        if (!wereAllSafe) {
            sendNotificationToUser(username, "<h1 style='color:blue'>Reminder</h1> The resource cost for your choices need to be below the allowed amount."
                    + "Click the Preview button underneath the GlobalProjections panel,the resources you are getting close to exceeding are marked in "
                    + "<span style='color:blue'>blue</span>");
        }

        //after calculating all resource costs we update the database with new UserChoices
        //wherever it is needed
        //(this is done for users that may accidentally logg off or close the browser )
        //the section also loggs the current choices
        GameUser user = userDAO.getGameUser(username);
        for (List<Model<ActivityChoice>> subList : selectedChoices) {
            for (Model<ActivityChoice> choiceModel : subList) {
                ActivityChoice choice = choiceModel.getObject();
                if (choice.isWasChanged()) {
                    UserChoices user_choice = activityDAO.getStoredChoice(choice.getActivity(), username);
                    if (user_choice == null) {
                        user_choice = new UserChoices();
                        user_choice.setChoice(choice);
                        user_choice.setGameUser(user);
                        user_choice.setSessionNumber(sessionNumber);
                    } else {
                        user_choice.setChoice(choice);
                    }
                    userDAO.save(user_choice);
                }
                LoggedUserChoice loggedChoice = new LoggedUserChoice();
                loggedChoice.setActivity(choice.getActivity().getName());
                loggedChoice.setChoice(choice.getName());
                loggedChoice.setCategory(choice.getActivity().getCategory());
                loggedChoice.setGameTurn(gameTurn);
                loggedChoice.setGameUser(username);
                loggedChoice.setSessionNumber(sessionNumber);
                loggedChoice.setGamemode_id(mode.getId());
                logDAO.save(loggedChoice);
            }
        }
        //update the UserResource and log Resources
        for (int index = 0; index < resourceCost.length; index++) {
            Resource res = resourceList.get(index);
            LoggedUserResource loggedResource = new LoggedUserResource();

            if (res.getAccumulates()) {
                UserResource userResource = userDAO.getLatestUserResourceByResourceID(username, res.getId());
                if (userResource == null) {
                    userResource = new UserResource();
                    userResource.setGameuser(user);
                    userResource.setResource(res);
                    loggedResource.setUser_cap(index);
                }
                userResource.setAccumulatedValue(resourceCaps[index] - resourceCost[index]);
                userResource.setSessionNumber(sessionNumber);

                userDAO.save(userResource);
            }
            //set the rest of the log entry
            loggedResource.setGameTurn(gameTurn);
            loggedResource.setGameuser(username);
            loggedResource.setResource(res.getName());
            loggedResource.setSessionNumber(sessionNumber);
            loggedResource.setUser_cap(resourceCaps[index]);
            loggedResource.setCost(resourceCost[index]);
            loggedResource.setGameMode_id(mode.getId());
            logDAO.save(loggedResource);

            globalCost[index] += resourceCost[index];
        }
        //log the activity variables
        for (List<Model<ActivityChoice>> subList : selectedChoices) {
            for (Model<ActivityChoice> choiceModel : subList) {
                Activity activity = choiceModel.getObject().getActivity();
                for (Variable variable : activity.getVariables()) {
                    LoggedUserVariable loggedVariable = new LoggedUserVariable();
                    loggedVariable.setGameTurn(gameTurn);
                    loggedVariable.setGameUser(username);
                    loggedVariable.setActivity(activity.getName());
                    loggedVariable.setCategory(activity.getCategory());
                    loggedVariable.setSessionNumber(sessionNumber);
                    loggedVariable.setValue(variable.getValue());
                    loggedVariable.setVariable(variable.getName());
                    loggedVariable.setGameMode_id(mode.getId());
                    logDAO.save(loggedVariable);
                }
            }
        }
        synchronized (userTurnMap) {
            if (lastSave != null) {
                userTurnMap.remove(username);
            }
            userTurnMap.put(username, new Integer(gameTurn));
        }
        return true;
    }

    public double getAccumualtedCapDifference(String username, Long resourceId) {
        UserResource userResource = userDAO.getLatestUserResourceByResourceID(username, resourceId);
        if (userResource != null && userResource.getSessionNumber() == sessionNumber) {
            return userResource.getAccumulatedValue();
        }
        return 0;
    }

    public boolean wasEliminated(String username) {
        boolean result = false;
        if (eliminatedUsers != null) {
            synchronized (eliminationLock) {
                if (eliminatedUsers.contains(username)) {
                    result = true;
                }
            }

        }
        return result;
    }

    public int getEliminatedNumber() {
        int result = 0;
        if (eliminatedUsers != null) {
            synchronized (eliminationLock) {
                result = eliminatedUsers.size();
            }

        }
        return result;
    }

    public void sendNotificationToUser(String username, String message) {
        //WebGameApplication application = (WebGameApplication) WebGameApplication.get();
        ChannelEvent event = new ChannelEvent(application.getNotificationChannel());
        event.addData("message_receiver", username);
        event.addData("message_text", message);
        application.getCometd().publish(event);
    }

    public void broadcastNotification(String message) {
        WebGameApplication application = (WebGameApplication) WebGameApplication.get();
        ChannelEvent event = new ChannelEvent(application.getNotificationChannel());

        event.addData("notification_id", String.valueOf(application.getAdminService().createNotification("admin", message)));
        application.getCometd().publish(event);
    }

    public List<BehaviourIndicator> getUncompleatedIndicators(String userName) {

        List<BehaviourIndicator> indicatorList = behaviourDAO.getIndicators(mode);
        List<UserIndicatorValues> valueList = userDAO.getUserIndicatorValues(userName, mode);

        for (UserIndicatorValues value : valueList) {
            indicatorList.remove(value.getBehaviour());


        }
        return indicatorList;
    }

    /**
     *
     * @param choice
     * @param resIndex - de index of the resource in a resourceList for current game mode ( here it is only used to get the coresponding choice cost expression)
     * @param variableList
     * @param res
     * @return double[2] ( OPEX-> 0 and CAPEX->1)
     */
    public double[] calculateChoiceResourceCost(ActivityChoice choice, int resIndex, List<Variable> variableList) {
        double rez[] = new double[2];
        if (choice != null && choice.getCostExpressions().size() > 0) {
            if (choice.getCostExpressions().size() <= resIndex) {
                logger.warning("ActivityChoice(" + choice.getName() + ")requested index=" + resIndex + "wich is higher than the number of associated costexpressions. "
                        + "\n Setting Default cost to OPEX=0 and CAPEX=0.");
                return rez;
            }
            ChoiceCostExpression expression = choice.getCostExpressions().get(resIndex);


            if (expression != null) {
                rez[0] = evaluateExpression(expression.getOpex(), variableList);
                if (choice.isWasChanged() && expression != null) {
                    rez[1] = evaluateExpression(expression.getCapex(), variableList);

                }
            }

        }
        return rez;
    }

    /**
     * returns the allowed global cap for the giver resource
     */
    public double getResourceGlobalCap(Resource res) {
        return evaluateExpression(res.getGlobalCap(), null);
    }

    /**
     * returns the allowed local cap for the giver resource and username
     */
    public double getResourgeUserCap(Resource res, String username) {
        List<UserIndicatorValues> indicatorValues = userDAO.getUserIndicatorValues(username, mode);

        double capValue = evaluateExpression(res.getDefaultUserCap(), indicatorValues);
        if (res.getAccumulates()) {
            capValue += getAccumualtedCapDifference(username, res.getId());
        }
        return capValue;
    }

    public void setApplication(WebGameApplication application)
    {
        this.application=application;
    }
}
