/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author icerrr
 */
public class CustomDataSource extends org.apache.commons.dbcp.BasicDataSource {
     public boolean getSSLtraffic()
     {
         return Boolean.valueOf(connectionProperties.getProperty("ssl"));
     }

     public void setSSLtraffic(boolean value)
     {
         addConnectionProperty("ssl", String.valueOf(value));
     }
}
