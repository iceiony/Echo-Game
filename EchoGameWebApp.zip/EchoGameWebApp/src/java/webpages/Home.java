package webpages;


import org.apache.wicket.markup.html.basic.Label;
import org.apache.wicket.markup.html.border.Border;
import webpages.pagePanels.InputSlider;



public class Home extends GenericWebPage
{


    public Home()
    {
        Border pageBorder=new IndexBorder("border");
        add(pageBorder);
        String descriptionText=((WebGameApplication)WebGameApplication.get()).getUserServices().currentGameMode().getDescription();

        Label descriptionLabel=new Label("gameModeDescription",descriptionText);
        descriptionLabel.setEscapeModelStrings(false);

        pageBorder.add(descriptionLabel);
    }

}
