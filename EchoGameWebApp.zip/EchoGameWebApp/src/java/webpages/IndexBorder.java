package webpages;

import org.apache.wicket.authorization.strategies.role.metadata.MetaDataRoleAuthorizationStrategy;
import org.apache.wicket.markup.html.basic.Label;
import org.apache.wicket.markup.html.border.Border;
import org.apache.wicket.markup.html.link.BookmarkablePageLink;
import org.apache.wicket.markup.html.link.Link;


public class IndexBorder extends Border
{
    Link loginLink;
    Link signupLink;
    Link homeLink;

    public IndexBorder(String id)
    {
        super(id);
        add(homeLink = new BookmarkablePageLink("homeLink", Home.class));
        add(loginLink = new BookmarkablePageLink("loginLink", LogIn.class));
        add(signupLink = new BookmarkablePageLink("signupLink",SignUp.class));

    }
}