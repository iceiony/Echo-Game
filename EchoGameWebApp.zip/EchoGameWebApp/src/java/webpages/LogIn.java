package webpages;

import data.model.BehaviourIndicator;
import java.util.List;
import javax.servlet.http.Cookie;
import org.apache.wicket.authentication.panel.SignInPanel;
import org.apache.wicket.markup.html.border.Border;
import org.apache.wicket.protocol.http.WebRequest;
import org.apache.wicket.protocol.http.WebResponse;
import org.apache.wicket.protocol.https.RequireHttps;

/**
 *
 * @author icerrr
 */
@RequireHttps
public class LogIn extends GenericWebPage{

    public LogIn()
    {
        Border pageBorder=new IndexBorder("border");//menu and container for page content
        SignInPanel signInPanel;
        pageBorder.add(signInPanel=new SignInPanel("signInPanel", false)
        {

            @Override
            protected void onSignInSucceeded() {
                
                //log in the user
                super.onSignInSucceeded();
                
                
                //if he's an admin , send him to the admin page else send him to the gamepage
                if (getCustomSession().getRoles().hasRole("ROLE_admin"))
                    setResponsePage(AdminPage.class);
                    else
                    {
                    // set the username cookie age to be 30 minutes to keep user privacy
//                    Cookie[] cookies = ((WebRequest)getRequestCycle().getRequest()).getCookies();
//                    for(Cookie cookie:cookies)   cookie.setMaxAge(60*30);
                     Cookie cookie=((WebRequest)getRequestCycle().getRequest()).getCookie("border.signInPanel.signInForm.username");
                     cookie.setMaxAge(30*60);
                      ((WebResponse)getRequestCycle().getResponse()).addCookie(cookie);

                     //test if he has all the behaviour indicators for this game mode
                      String username=super.getUsername();
                     List<BehaviourIndicator> behaviourList=((WebGameApplication)WebGameApplication.get()).getUserServices().getUncompleatedIndicators(username);
                      if(behaviourList.size()==0) setResponsePage(Game.class);
                      else
                      {
                         SignUp page=new SignUp(behaviourList);
                         setResponsePage(page);
                      }
                    }
            }

        }
        );
        add(pageBorder);
        
    }

}
