/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package webpages.adminPanels;

import java.io.OutputStream;
import org.apache.wicket.util.resource.AbstractResourceStreamWriter;
import webpages.WebGameApplication;

/**
 *
 * @author icerrr
 */
public class ExcelResourceStream extends AbstractResourceStreamWriter{

    private String fileName;
    public ExcelResourceStream(String fileName)
    {
        this.fileName=fileName;
    }
    
    public void write(OutputStream output) {
       ((WebGameApplication)WebGameApplication.get()).getAdminService().writeDinamicFileContents(fileName, output);
    }

    public String getContentType() {
       return "application/ms-excel";
    }

}
