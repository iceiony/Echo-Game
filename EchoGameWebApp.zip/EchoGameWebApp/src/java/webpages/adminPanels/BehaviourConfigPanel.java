/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package webpages.adminPanels;

import data.model.BehaviourIndicator;
import data.model.IndicatorOption;
import java.util.List;
import org.apache.wicket.AttributeModifier;
import org.apache.wicket.ajax.AjaxRequestTarget;
import org.apache.wicket.ajax.form.AjaxFormComponentUpdatingBehavior;
import org.apache.wicket.ajax.markup.html.AjaxLink;
import org.apache.wicket.ajax.markup.html.form.AjaxButton;
import org.apache.wicket.markup.html.WebMarkupContainer;
import org.apache.wicket.markup.html.basic.Label;
import org.apache.wicket.markup.html.form.ChoiceRenderer;
import org.apache.wicket.markup.html.form.DropDownChoice;
import org.apache.wicket.markup.html.form.Form;
import org.apache.wicket.markup.html.form.TextArea;
import org.apache.wicket.markup.html.form.TextField;
import org.apache.wicket.markup.html.list.ListItem;
import org.apache.wicket.markup.html.list.ListView;
import org.apache.wicket.markup.html.panel.Panel;
import org.apache.wicket.model.Model;
import webpages.WebGameApplication;

/**
 *
 * @author icerrr
 */
public class BehaviourConfigPanel extends Panel {

    private List<BehaviourIndicator> behaviourList;

    //behaviour indicator models
    private Model<BehaviourIndicator> selectedBehaviourModel=new Model<BehaviourIndicator>();
    private Model<String> indicatorNameModel=new Model<String>();
    private Model<String> indicatorClassModel=new Model<String>();
    private Model<String> indicatorBindModel=new Model<String>();
    private Model<Integer> indicatorOrderModel=new Model<Integer>();
    private Model<String> indicatorDescriptionModel=new Model<String>();

    //indicator option models
    private Model<String> newOptionDistplayTextModel=new Model<String>();
    private Model<String> newOptionDescriptionModel=new Model<String>();
    private Model<Integer> newOptionMinModel=new Model<Integer>();
    private Model<Integer> newOptionMaxModel=new Model<Integer>();
    private Model<Integer> newOptionValueModel=new Model<Integer>();

    //feedback label models
    private Model<String> feedbackLabelModel=new Model<String>("found");
    private Model<String> labelStyleModel=new Model<String>("color:green;visibility:hidden");
    
    private WebMarkupContainer detailsContainer;
    private WebMarkupContainer optionsContainer;
    private ListView optionsListView;

    private static final String newVarStr="<< New >>";

    public BehaviourConfigPanel(String id)
    {
        super(id);
        setOutputMarkupId(true);
        
        //retrieve the behaviour indicator list
        behaviourList=((WebGameApplication)WebGameApplication.get()).getUserServices().getBehaviourIndicators();
        //add one extra indicator to the lsit
        BehaviourIndicator indicator=new BehaviourIndicator();
        indicator.setDisplayName(newVarStr);
        indicator.setDisplayOrder(behaviourList.size());
        behaviourList.add(indicator);
        
        if(behaviourList.size()>0) setSelectedBehaviour(behaviourList.get(0));



//add the necessary components
//------------------------------------------------------------------------------
        //add the form
        Form behaviourForm=new Form("behaviourForm");
        add(behaviourForm);

        //add the drop down choice 
        ChoiceRenderer aucr = new ChoiceRenderer("displayName", "id");
        final DropDownChoice indicatorDropDown=new DropDownChoice("currentIndicators",selectedBehaviourModel,behaviourList,aucr);
        behaviourForm.add(indicatorDropDown);
        indicatorDropDown.add(new AjaxFormComponentUpdatingBehavior("onchange") {
            @Override
            protected void onUpdate(AjaxRequestTarget target) {
               setSelectedBehaviour(selectedBehaviourModel.getObject());
               target.addComponent(detailsContainer);
            }
        });

        //add the details Container
        detailsContainer=new WebMarkupContainer("indicatorDetails");
        detailsContainer.setOutputMarkupId(true);
        behaviourForm.add(detailsContainer);

        //add the input fields for the indicator
        //----------------------------------------------------------------------
        //the name field
        detailsContainer.add(new TextField("indicatorName",indicatorNameModel));

        //the class field ( it also needs an ajax update behaviour to aknowledge 
        //if the class exists or not
        final Label fieldFeedbackLabel=new Label("classFeedback",feedbackLabelModel);
        fieldFeedbackLabel.setOutputMarkupId(true);
        fieldFeedbackLabel.add(new AttributeModifier("style",labelStyleModel));

        TextField classField=new TextField("indicatorClassName",indicatorClassModel);
        classField.add(new AjaxFormComponentUpdatingBehavior("onchange") {
            @Override
            protected void onUpdate(AjaxRequestTarget target) {
                String classString="webpages.pagePanels."+indicatorClassModel.getObject();
                boolean found=true;

                try{
                    Class.forName(classString);
                }
                catch(Exception e){
                    found=false;
                }
                
                if(found) {
                    feedbackLabelModel.setObject("found");
                    labelStyleModel.setObject("color:lime;visibility:visible");
                }
                else{
                    feedbackLabelModel.setObject("not found");
                    labelStyleModel.setObject("color:red;visibility:visible");
                }
                target.addComponent(fieldFeedbackLabel);
            }
        });
        detailsContainer.add(classField);
        detailsContainer.add(fieldFeedbackLabel);

        //the binding field
        detailsContainer.add(new TextField("bindingName",indicatorBindModel));
        //the order field
        detailsContainer.add(new TextField("indicatorOrder",indicatorOrderModel,Integer.class));
        //the description TextArea
        detailsContainer.add(new TextArea("indicatorDescription",indicatorDescriptionModel));

        //add the components for defining new indicator options
        //----------------------------------------------------------------------
        optionsContainer=new WebMarkupContainer("optionsDetails");
        optionsContainer.setOutputMarkupId(true);
        detailsContainer.add(optionsContainer);

        //add the input fields for new options
        optionsContainer.add(new TextField("newOptionDisplayText",newOptionDistplayTextModel));
        optionsContainer.add(new TextField("newOptionDescription",newOptionDescriptionModel));
        optionsContainer.add(new TextField("newOptionMin",newOptionMinModel,Integer.class));
        optionsContainer.add(new TextField("newOptionMax",newOptionMaxModel,Integer.class));
        optionsContainer.add(new TextField("newOptionValue",newOptionValueModel,Integer.class));

        //add the submit button
        optionsContainer.add(new AjaxButton("newOptionAdd",behaviourForm) {
            @Override
            protected void onSubmit(AjaxRequestTarget target, Form<?> form) {
                    IndicatorOption newOption=new IndicatorOption();
                    newOption.setBehaviour(selectedBehaviourModel.getObject());
                    newOption.setDescription(newOptionDescriptionModel.getObject());
                    newOption.setDisplayText(newOptionDistplayTextModel.getObject());
                    newOption.setMaxValue(newOptionMaxModel.getObject());
                    newOption.setMinValue(newOptionMinModel.getObject());
                    newOption.setOptionValue(newOptionValueModel.getObject());
                    selectedBehaviourModel.getObject().getOptions().add(newOption);

                    optionsListView.setList(selectedBehaviourModel.getObject().getOptions());

                    target.addComponent(optionsContainer);
            }
        });

        //add a list view for the options of the currently selected indicator
        optionsListView=new ListView("optionsList",selectedBehaviourModel.getObject().getOptions()) {
            @Override
            protected void populateItem(ListItem item) {
               final IndicatorOption option=(IndicatorOption) item.getModelObject();
               item.add(new Label("optionDisplayText",option.getDisplayText()));
               item.add(new Label("optionDescription",option.getDescription()));
               item.add(new Label("optionMin",String.valueOf(option.getMinValue())));
               item.add(new Label("optionMax",String.valueOf(option.getMaxValue())));
               item.add(new Label("optionValue",String.valueOf(option.getOptionValue())));
               //add the delete link
                AjaxLink deleteLink=new AjaxLink("optionDelete") {
                    @Override
                    public void onClick(AjaxRequestTarget target) {
                        selectedBehaviourModel.getObject().getOptions().remove(option);
                        optionsListView.setList(selectedBehaviourModel.getObject().getOptions());
                        target.addComponent(optionsContainer);
                    }
                };
               item.add(deleteLink);
            }
        };
        if(selectedBehaviourModel.getObject()!=null) optionsListView.setList(selectedBehaviourModel.getObject().getOptions());

        optionsContainer.add(optionsListView);

        //add the form's submit and delete buttons
        //----------------------------------------------------------------------
        behaviourForm.add(new AjaxButton("formSubmitButton",behaviourForm) {

            @Override
            protected void onSubmit(AjaxRequestTarget target, Form<?> form) {

                BehaviourIndicator indicator=selectedBehaviourModel.getObject();
                if(!indicatorNameModel.getObject().equals(newVarStr))
                {
                //update the object with current data
                boolean isRename=(indicator.getDisplayName().equals(indicatorNameModel.getObject()));
                indicator.setBindingName(indicatorBindModel.getObject());
                indicator.setDescription(indicatorDescriptionModel.getObject());
                indicator.setDisplayName(indicatorNameModel.getObject());
                indicator.setDisplayOrder(indicatorOrderModel.getObject());
                indicator.setWicketClassName(indicatorClassModel.getObject());

                boolean wasNewIndicator=((WebGameApplication)WebGameApplication.get()).getAdminService().updateOrCreateBehaviourIndicator(indicator);
                if(wasNewIndicator)
                {
                    indicator=new BehaviourIndicator();
                    indicator.setDisplayName(newVarStr);
                    indicator.setDisplayOrder(behaviourList.size());
                    behaviourList.add(indicator);
                }
                               
                target.addComponent(indicatorDropDown);//redraw the component
                }

            }
        });
        behaviourForm.add(new AjaxButton("formDeleteButton",behaviourForm) {

            @Override
            protected void onSubmit(AjaxRequestTarget target, Form<?> form) {
               if(!selectedBehaviourModel.getObject().getDisplayName().equals(newVarStr))
               {
                   behaviourList.remove(selectedBehaviourModel.getObject());
                   ((WebGameApplication)WebGameApplication.get()).getAdminService().deleteBehaviourIndicator(selectedBehaviourModel.getObject());
                   setSelectedBehaviour(behaviourList.get(0));
                   target.addComponent(getCurrentPanel());
               }
            }
        });
    }

    private void setSelectedBehaviour(BehaviourIndicator indicator)
    {
        selectedBehaviourModel.setObject(indicator);
        //exclusive indicator details
        indicatorNameModel.setObject(indicator.getDisplayName());
        indicatorClassModel.setObject(indicator.getWicketClassName());
        indicatorBindModel.setObject(indicator.getBindingName());
        indicatorOrderModel.setObject(indicator.getDisplayOrder());
        indicatorDescriptionModel.setObject(indicator.getDescription());
        //indicator options models
        if(optionsListView!=null) optionsListView.setList(indicator.getOptions());
    }

    private Panel getCurrentPanel()
    {
        return this;
    }
}
