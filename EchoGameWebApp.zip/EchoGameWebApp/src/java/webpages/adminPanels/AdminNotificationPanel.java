/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package webpages.adminPanels;

import data.model.Notification;
import java.util.Date;
import java.text.DateFormat;
import org.apache.wicket.Application;
import org.apache.wicket.AttributeModifier;
import org.apache.wicket.ajax.AjaxRequestTarget;
import org.apache.wicket.ajax.AjaxEventBehavior;
import org.apache.wicket.ajax.markup.html.form.AjaxButton;
import org.apache.wicket.behavior.HeaderContributor;
import org.apache.wicket.behavior.StringHeaderContributor;
import org.apache.wicket.markup.html.CSSPackageResource;
import org.apache.wicket.markup.html.JavascriptPackageResource;
import org.apache.wicket.markup.html.basic.Label;
import org.apache.wicket.markup.html.form.Button;
import org.apache.wicket.markup.html.form.Form;
import org.apache.wicket.markup.html.form.HiddenField;
import org.apache.wicket.markup.html.panel.Panel;
import org.apache.wicket.markup.html.form.TextArea;
import org.apache.wicket.markup.html.resources.CompressedResourceReference;
import org.apache.wicket.model.Model;
import org.wicketstuff.push.ChannelEvent;
import webpages.CustomSession;
import webpages.WebGameApplication;
import webpages.pagePanels.NotificationMessagePanel;
import webpages.pagePanels.PushModalWindow;

/**
 * Panel for sending notifications accross the application
 * @author icerrr
 */
public class AdminNotificationPanel extends Panel{

    Model<String> messageModel;
    Model<String> feedbackModel;
    Label feedbackLabel;
    PushModalWindow window1;
    HiddenField messageField;
    Label richTextEditor;

     private static final DateFormat df = DateFormat.getTimeInstance(DateFormat.SHORT);

     public static final StringHeaderContributor DOJO_EDITOR_CONTIRBUTOR=
     new StringHeaderContributor("  <script type='text/javascript'>"+
                                       "dojo.require('dijit.Editor');"+
                                       "dojo.require('dijit._editor.plugins.LinkDialog');"+
                                       "dojo.require('dijit._editor.plugins.ViewSource');"+
                                       "dojo.require('dijit._editor.plugins.FullScreen');"+
                                       "dojo.require('dijit._editor.plugins.TextColor');"+
                                       "dojo.require('dijit._editor.plugins.FontChoice');"+
                                    "</script>");



    public AdminNotificationPanel(String id)
    {
        super(id);

        add(WebGameApplication.DOJO_CONFIG_HEADER_CONTRIBUTOR);
        add(JavascriptPackageResource.getHeaderContribution(Application.get().getMetaData(WebGameApplication.DOJO_DIST_LOCATION)));
        add(DOJO_EDITOR_CONTIRBUTOR);
        add(CSSPackageResource.getHeaderContribution(WebGameApplication.STYLE_THUNDRA_CONTRIBUTOR));

        Form notificationForm=new Form("notificationForm");
        add(notificationForm);

        notificationForm.add(messageField=new HiddenField("messageField", messageModel=new Model<String>(""), String.class));
        
      //  notificationForm.add(new TextArea("message", messageModel=new Model<String>("Message can be HTML")));
        notificationForm.add(richTextEditor=new Label("richTextEditor"));
        richTextEditor.add(new AttributeModifier("onchange",new Model<String>("dojo.byId('"+messageField.getMarkupId()+"').value = this.getValue();")));

         notificationForm.add(new AjaxButton("sendButton",notificationForm) {
            @Override
            protected void onSubmit(AjaxRequestTarget target, Form<?> form) {
             
                ((WebGameApplication)WebGameApplication.get()).getUserServices().broadcastNotification(messageModel.getObject());
               
                feedbackModel.setObject("Notification sent at "+df.format(new Date())+" System Time");
                target.addComponent(feedbackLabel);
            }
        });

        add(feedbackLabel=new Label("confirmationLabel",feedbackModel=new Model<String>("")));
        feedbackLabel.setOutputMarkupId(true);

       notificationForm.add(new AjaxButton("previewButton",notificationForm) {

             @Override
            protected void onSubmit(AjaxRequestTarget target, Form<?> form) {
                NotificationMessagePanel messagePanel=new NotificationMessagePanel("content");
                messagePanel.setNotificationMessage(new Notification(){
                    {
                        setMessage(messageModel.getObject());
                    }
                });
                window1.setContent(messagePanel);
                //window1.setWidthUnit("44%");
                window1.show(target);

            }
        });

        add(window1=new PushModalWindow("modalWindow1"));
        window1.setCssClassName(PushModalWindow.CSS_CLASS_BLUE);
        window1.setTitle("Notification");
    }
}
