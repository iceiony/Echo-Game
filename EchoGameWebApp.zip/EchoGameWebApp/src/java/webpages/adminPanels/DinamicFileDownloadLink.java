package webpages.adminPanels;

import org.apache.wicket.markup.html.link.Link;
import org.apache.wicket.request.target.resource.ResourceStreamRequestTarget;
import org.apache.wicket.util.resource.IResourceStreamWriter;

/**
 * Code inspired from : http://markmail.org/message/66le4n6vmpcfv3tq#query:wicket%20downloadlink%20from%20dynamicwebresource+page:1+mid:yv5hunvthfqrb5bv+state:results
 * Original author name : Jan Kriesten (jan.kriesten@renitence.de)
 * @author icerrr
 */
public class DinamicFileDownloadLink extends Link {

    private String fileName;

    public DinamicFileDownloadLink(String id,String fileName) {
        super(id);
        this.fileName=fileName;
    }

    @Override
    public void onClick() {
        IResourceStreamWriter resourceStream =new ExcelResourceStream(fileName);
        getRequestCycle().setRequestTarget(new ResourceStreamRequestTarget(resourceStream) {

            @Override
            public String getFileName() {
                return (fileName);
            }
        });
    }
}
