/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package webpages.adminPanels;

import data.model.GameMode;
import java.util.List;
import org.apache.wicket.Application;
import org.apache.wicket.AttributeModifier;
import org.apache.wicket.ajax.AjaxRequestTarget;
import org.apache.wicket.ajax.form.AjaxFormComponentUpdatingBehavior;
import org.apache.wicket.ajax.markup.html.form.AjaxButton;
import org.apache.wicket.behavior.StringHeaderContributor;
import org.apache.wicket.markup.html.CSSPackageResource;
import org.apache.wicket.markup.html.JavascriptPackageResource;
import org.apache.wicket.markup.html.basic.Label;
import org.apache.wicket.markup.html.form.Button;
import org.apache.wicket.markup.html.form.ChoiceRenderer;
import org.apache.wicket.markup.html.form.DropDownChoice;
import org.apache.wicket.markup.html.form.Form;
import org.apache.wicket.markup.html.form.HiddenField;
import org.apache.wicket.markup.html.form.TextField;
import org.apache.wicket.markup.html.panel.Panel;
import org.apache.wicket.model.Model;
import webpages.GameConfig;
import webpages.WebGameApplication;


/**
 *
 * @author icerrr
 */
public class ModeConfigurationPanel extends Panel {

    Model<GameMode> selectedMode=new Model<GameMode>();;
    Model<String> modeName=new Model<String>();
    Model<String> modeDescription=new Model<String>();
    Model<Integer> turnInterval=new Model<Integer>();
    Model<Integer> maxTurn=new Model<Integer>();

    Model<String> newModeName=new Model<String>();
    
     public static final StringHeaderContributor DOJO_EDITOR_CONTIRBUTOR=
     new StringHeaderContributor("  <script type='text/javascript'>"+
                                       "dojo.require('dijit.Editor');"+
                                       "dojo.require('dijit._editor.plugins.LinkDialog');"+
                                       "dojo.require('dijit._editor.plugins.ViewSource');"+
                                       "dojo.require('dijit._editor.plugins.FullScreen');"+
                                       "dojo.require('dijit._editor.plugins.TextColor');"+
                                       "dojo.require('dijit._editor.plugins.FontChoice');"+
                                    "</script>");

     DropDownChoice dropDown;

        public ModeConfigurationPanel(String id)
        {
            super(id);
            //add the header files
            add(WebGameApplication.DOJO_CONFIG_HEADER_CONTRIBUTOR);
            add(JavascriptPackageResource.getHeaderContribution(Application.get().getMetaData(WebGameApplication.DOJO_DIST_LOCATION)));
            add(DOJO_EDITOR_CONTIRBUTOR);
            add(CSSPackageResource.getHeaderContribution(WebGameApplication.STYLE_THUNDRA_CONTRIBUTOR));

            Form form=new Form("modeConfigForm");
            add(form);

            //retrieve the list of available game modes
            List<GameMode> modeList=((WebGameApplication)WebGameApplication.get()).getAdminService().getGameModeList();
            
            //retrieve current game mode
            GameMode mode=((WebGameApplication)WebGameApplication.get()).getUserServices().currentGameMode();
            //set game mode model
            selectedMode.setObject(mode);
            //drop down component and action for gameMode list
            ChoiceRenderer aucr = new ChoiceRenderer("name", "name");
            dropDown=new DropDownChoice("dropDown",selectedMode,modeList,aucr);
            dropDown.setOutputMarkupId(true);
            dropDown.add(new AjaxFormComponentUpdatingBehavior("onchange") {
            @Override
            protected void onUpdate(AjaxRequestTarget target) {
                //set the new game mode
                 ((WebGameApplication)WebGameApplication.get()).getUserServices().setGameMode(selectedMode.getObject().getName());
                //reload the page when a new game mode has been selected
                 target.appendJavascript("window.location.reload()");
                }
            });
            form.add(dropDown);

            //add the input fields for creating new game modes
            newModeName.setObject("");
            form.add(new TextField("newModeName",newModeName));
            form.add(new Button("newModeSubmit")
            {
                @Override
                public void onSubmit() {
                    super.onSubmit();
                    //create a new game mode with that name and copy all the contents of the current game mode
                    GameMode newMode= ((WebGameApplication)WebGameApplication.get()).getAdminService().
                                       createNewGameModeAfter(selectedMode.getObject().getName(),newModeName.getObject());
                    //set the current game mode as beeing the new game mode
                    ((WebGameApplication)WebGameApplication.get()).getUserServices().setGameMode(newMode.getName());
                    //refresh the page
                    setResponsePage(GameConfig.class);
                }
            });

            //current game mode details
            modeName.setObject(mode.getName());
            modeDescription.setObject(mode.getDescription());
            turnInterval.setObject(mode.getTurnInterval());
            maxTurn.setObject(mode.getMaxTurns());
            form.add(new TextField("modeName",modeName));
            form.add(new TextField("timeInterval",turnInterval,Integer.class));
            form.add(new TextField("maxTurns",maxTurn,Integer.class));


            HiddenField descriptionField=new HiddenField("descriptionField", modeDescription, String.class);
            Label richTextEditor=new Label("richTextEditor",modeDescription);
            richTextEditor.setEscapeModelStrings(false);
            richTextEditor.add(new AttributeModifier("onchange",new Model<String>("dojo.byId('"+descriptionField.getMarkupId()+"').value = this.getValue();")));
            form.add(descriptionField);
            form.add(richTextEditor);

            //save details
            form.add(new AjaxButton("submitButton",form)
            {
            @Override
            protected void onSubmit(AjaxRequestTarget target, Form<?> form) {
                //on submit just change the values of the existing object
                GameMode changedMode=((WebGameApplication)WebGameApplication.get()).getAdminService().
                        updateExistingGameMode(selectedMode.getObject().getName(),modeName.getObject(),turnInterval.getObject(),maxTurn.getObject(),modeDescription.getObject());
                if(changedMode!=null)
                {
                    ((WebGameApplication)WebGameApplication.get()).getUserServices().setGameMode(changedMode.getName());
                    selectedMode.getObject().setName(changedMode.getName());
                    target.addComponent(dropDown);
                }
            }
            });
            
        }
}
