/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package webpages.adminPanels;

import data.model.Activity;
import data.model.Variable;
import java.util.LinkedList;
import java.util.List;
import org.apache.wicket.MarkupContainer;
import org.apache.wicket.ajax.AjaxRequestTarget;
import org.apache.wicket.ajax.form.AjaxFormComponentUpdatingBehavior;
import org.apache.wicket.ajax.markup.html.AjaxLink;
import org.apache.wicket.ajax.markup.html.form.AjaxButton;
import org.apache.wicket.markup.html.WebMarkupContainer;
import org.apache.wicket.markup.html.basic.Label;
import org.apache.wicket.markup.html.form.CheckBox;
import org.apache.wicket.markup.html.form.ChoiceRenderer;
import org.apache.wicket.markup.html.form.DropDownChoice;
import org.apache.wicket.markup.html.form.Form;
import org.apache.wicket.markup.html.form.TextArea;
import org.apache.wicket.markup.html.form.TextField;
import org.apache.wicket.markup.html.list.ListItem;
import org.apache.wicket.markup.html.panel.Panel;
import org.apache.wicket.model.Model;
import webpages.WebGameApplication;
import org.apache.wicket.markup.html.list.ListView;

/**
 * This class seems like a mess
 * You should not attempt to modify it.
 * @author icerrr
 */
public class ActivityConfigPanel extends Panel {

    private List<List<Activity>> activityList;
    private List<String> categoryList;

    private Model<Activity> activityModel = new Model<Activity>();
    private Model<String> categoryModel = new Model<String>();
    private Model<String> textCategoryModel = new Model<String>();
    private Model<String> activityNameModel = new Model<String>();
    private Model<String> descriptionModel = new Model<String>();
    private Model<Integer> displayOrderModel = new Model<Integer>();
    private Model<String> choiceFormulaModel=new Model<String>();
    private Model<String> categoryOfActivityModel = new Model<String>();

    private Model<String> newVarNameModel=new Model<String>();
    private Model<String> newVarDescriptionModel=new Model<String>();
    private Model<Boolean> newVarDiscreteModel=new Model<Boolean>();
    private Model<Integer> newVarMinValueModel=new Model<Integer>();
    private Model<Integer> newVarMaxValueModel=new Model<Integer>();
    private Model<Double> newVarDefaultValueModel=new Model<Double>();

    private static final String newresStr = "<< New >>";
    private TextField selectedCategoryTextfield;
    private DropDownChoice categoryOfActivityDropDown;
    private ListView variableList;
    private Form activityForm;
    private WebMarkupContainer activityDetailsContainer;
    

    public ActivityConfigPanel(String id) {
        super(id);
        setOutputMarkupId(true);

        activityForm = new Form("activityForm");
        add(activityForm);
        activityForm.setOutputMarkupId(true);


        //initializes the models that are to be displayed
        init();

        //dropdown activity choice and change event handler
        ChoiceRenderer aucr = new ChoiceRenderer("name", "name");
        final DropDownChoice activityDropDown = new DropDownChoice("currentActivity", activityModel, activityList.get(0), aucr);
        activityDropDown.add(new AjaxFormComponentUpdatingBehavior("onchange") {

            @Override
            protected void onUpdate(AjaxRequestTarget target) {
                Activity activity = activityModel.getObject();
                setActivitydetails(activity);
                variableList.setList(activityModel.getObject().getVariables());
                target.addComponent(activityDetailsContainer);
            }
        });
        activityDropDown.setOutputMarkupId(true);
        activityForm.add(activityDropDown);

        //dropdown category choice and change event handler
        final DropDownChoice categoryDropDown = new DropDownChoice("currentCategories", categoryModel, categoryList);
        categoryDropDown.add(new AjaxFormComponentUpdatingBehavior("onchange") {

            @Override
            protected void onUpdate(AjaxRequestTarget target) {

                if (!newresStr.equals(categoryModel.getObject())) {
                    int categoryIndex = categoryList.indexOf(categoryModel.getObject());

                    //update activity dropdown
                    activityDropDown.setChoices(activityList.get(categoryIndex));

                    //set the current activity as being the first
                    Activity activity = activityList.get(categoryIndex).get(0);
                    activityModel.setObject(activity);
                    setActivitydetails(activity);

                    //redraw the entire panel
                    textCategoryModel.setObject(categoryModel.getObject());
                    variableList.setList(activityModel.getObject().getVariables());
                    target.addComponent(getCurrentPanel());
                } else //the user just wants to add a new category , no point in rewriting everything
                {
                    textCategoryModel.setObject(categoryModel.getObject());
                    target.addComponent(selectedCategoryTextfield);
                }
            }
        });
        categoryDropDown.setOutputMarkupId(true);
        activityForm.add(categoryDropDown);
        //category text input and save button
        activityForm.add(selectedCategoryTextfield = new TextField("selectedCategory", textCategoryModel));
        selectedCategoryTextfield.setOutputMarkupId(true);
        activityForm.add(new AjaxButton("saveNewCategory", activityForm) {

            @Override
            protected void onSubmit(AjaxRequestTarget target, Form<?> form) {
                //will not save categories with name newresStr
                String newName = textCategoryModel.getObject();
                String oldName = categoryModel.getObject();
                if (!newresStr.equals(newName)) {
                    //if it's an exsiting category rename it and update changes including to the DB
                    //and redraw everything
                    if (!newresStr.equals(oldName)) {
                        ((WebGameApplication) WebGameApplication.get()).getAdminService().renameCategory(oldName, newName);
                        //retrieve all data again and redraw the entire panel, since a rename can merge two sublists
                        init();
                        categoryDropDown.setChoices(categoryList);
                        categoryOfActivityDropDown.setChoices(categoryList);
                        activityDropDown.setChoices(activityList.get(categoryList.indexOf(newName)));
                                            variableList.setList(activityModel.getObject().getVariables());
                        target.addComponent(getCurrentPanel());
                    } //if it's a new category add it to the list of categories and prepare
                    else {
                        categoryList.set(categoryList.size() - 1, newName);
                        categoryList.add(newresStr);
                        List<Activity> newSubList = new LinkedList<Activity>();
                        activityList.add(newSubList);

                        //add a blank activity to the list
                        Activity newActivity = new Activity();
                        newActivity.setName(newresStr);
                        newActivity.setDescription("");

                        int categoryIndex = activityList.indexOf(newSubList);
                        if (categoryIndex < categoryList.size()) {
                            newActivity.setCategory(categoryList.get(categoryIndex));
                        } else {
                            newActivity.setCategory("");
                        }
                        newActivity.setDisplayOrder(newSubList.size());
                        newSubList.add(newActivity);

                        //redraw the dropDowns
                        target.addComponent(categoryOfActivityDropDown);
                        target.addComponent(categoryDropDown);
                    }
                }
            }
        });


        //details of currently selected activity
        activityDetailsContainer = new WebMarkupContainer("activityDetails");
        activityDetailsContainer.setOutputMarkupId(true);
        activityForm.add(activityDetailsContainer);

        activityDetailsContainer.add(new TextField("activityName", activityNameModel));
        activityDetailsContainer.add(new TextArea("description", descriptionModel));
        activityDetailsContainer.add(new TextField("displayOrder", displayOrderModel, Integer.class));
        activityDetailsContainer.add(new TextField("choiceFormula",choiceFormulaModel));

        categoryOfActivityDropDown = new DropDownChoice("categoryOfActivity", categoryOfActivityModel, categoryList);
        categoryOfActivityDropDown.setOutputMarkupId(true);
        categoryOfActivityDropDown.setRequired(true);
        activityDetailsContainer.add(categoryOfActivityDropDown);

        //activity save button
        activityDetailsContainer.add(new AjaxButton("activitySubmitButton", activityForm) {

            @Override
            protected void onSubmit(AjaxRequestTarget target, Form<?> form) {
                //save the changes made to this activity
                Activity activity = activityModel.getObject();

                activity.setName(activityNameModel.getObject());
                activity.setDescription(descriptionModel.getObject());
                activity.setCategory(categoryOfActivityModel.getObject());
                activity.setDisplayOrder(displayOrderModel.getObject());
                activity.setChoiceFormula(choiceFormulaModel.getObject());
                if (!activity.getName().equals(newresStr) && !activity.getCategory().equals(newresStr)) {
                    boolean newActivityCreated = ((WebGameApplication) WebGameApplication.get()).getAdminService().updateOrCreateActivity(activity);
                    if (newActivityCreated) {
                        activity = new Activity();
                        activity.setName(newresStr);
                        activity.setDescription("");
                        activity.setCategory(categoryModel.getObject());
                        activity.setDisplayOrder(activityDropDown.getChoices().size());
                        activityDropDown.getChoices().add(activity);
                        target.addComponent(activityDropDown);
                    } else {
                        //redraw everything that may have changed
                        init();
                        activityModel.setObject(activity);
                        int categoryIndex = categoryList.indexOf(activity.getCategory());
                        categoryModel.setObject(categoryList.get(categoryIndex));
                        textCategoryModel.setObject(categoryList.get(categoryIndex));
                        setActivitydetails(activity);
                        variableList.setList(activityModel.getObject().getVariables());
                        target.addComponent(getCurrentPanel());
                    }
                }
            }
        });

        //activity delete button
        activityDetailsContainer.add(new AjaxButton("activityDeleteButton", activityForm) {

            @Override
            protected void onSubmit(AjaxRequestTarget target, Form<?> form) {
                Activity activity = activityModel.getObject();
                if (!newresStr.equals(activity.getName())) {
                    ((WebGameApplication) WebGameApplication.get()).getAdminService().deleteActivity(activity);
                    activityDropDown.getChoices().remove(activity);
                    activity = (Activity) activityDropDown.getChoices().get(0);
                    setActivitydetails(activity);
                    variableList.setList(activityModel.getObject().getVariables());
                    target.addComponent(getCurrentPanel());
                }
            }
        });


        //add the variable list assigned to currently selected activity
        final WebMarkupContainer variableListContainer=new WebMarkupContainer("variableListContainer");
        variableListContainer.setOutputMarkupId(true);
        activityDetailsContainer.add(variableListContainer);

        variableList = new ListView("variableList", activityModel.getObject().getVariables()) {

            @Override
            protected void populateItem(ListItem item) {
                final Variable variable=(Variable)item.getModelObject();
                item.add(new Label("varName",variable.getName()));
                item.add(new Label("varDescription",variable.getDescription()));
                item.add(new Label("varDiscrete",String.valueOf(variable.isDiscrete())));
                item.add(new Label("varMinValue",String.valueOf(variable.getMinValue())));
                item.add(new Label("varMaxValue",String.valueOf(variable.getMaxValue())));
                item.add(new Label("varDefaultValue",String.valueOf(variable.getValue())));
                AjaxLink deleteLink=new AjaxLink("varDelete") {

                    @Override
                    public void onClick(AjaxRequestTarget target) {
                        activityModel.getObject().getVariables().remove(variable);
                        variableList.setList(activityModel.getObject().getVariables());
                        target.addComponent(variableListContainer);
                    }
                };
               item.add(deleteLink);
            }
        };

        variableListContainer.add(variableList);

        //add input fields to allow adding new variables

        variableListContainer.add(new TextField<String>("newVarName",newVarNameModel));
        variableListContainer.add(new TextField<String>("newVarDescription",newVarDescriptionModel));
        variableListContainer.add(new CheckBox("newVarDiscrete",newVarDiscreteModel));
        variableListContainer.add(new TextField<Integer>("newVarMinValue",newVarMinValueModel,Integer.class));
        variableListContainer.add(new TextField<Integer>("newVarMaxValue",newVarMaxValueModel,Integer.class));
        variableListContainer.add(new TextField<Double>("newVarDefaultValue",newVarDefaultValueModel,Double.class));
        variableListContainer.add(new AjaxButton("newVarAdd",activityForm) {

            @Override
            protected void onSubmit(AjaxRequestTarget target, Form<?> form) {
                    Variable newVar=new Variable();
                    newVar.setName(newVarNameModel.getObject());
                    newVar.setDescription(newVarDescriptionModel.getObject());
                    newVar.setDiscrete(newVarDiscreteModel.getObject());
                    double defaultVal=0;
                    if(newVarDefaultValueModel.getObject()!=null) defaultVal=newVarDefaultValueModel.getObject();
                    int minVal=0;
                    if(newVarMinValueModel.getObject()!=null) minVal=newVarMinValueModel.getObject();
                    int maxVal=0;
                    if(newVarMaxValueModel.getObject()!=null) maxVal=newVarMaxValueModel.getObject();
                    if(minVal>maxVal)
                    {
                        int aux=minVal;
                        minVal=maxVal;
                        maxVal=aux;
                    }
                    if(defaultVal<minVal) defaultVal=minVal;
                    if(defaultVal>maxVal) defaultVal=maxVal;
                    newVar.setMaxValue(maxVal);
                    newVar.setMinValue(minVal);
                    newVar.setValue(defaultVal);

                    if(!activityModel.getObject().getVariables().contains(newVar))
                    activityModel.getObject().getVariables().add(newVar);

                     variableList.setList(activityModel.getObject().getVariables());
                    target.addComponent(variableListContainer);
            }
        }

    );


    }

    /**
     * initialize the models for the currently selected activity ( the default activity selected )
     * @param activity
     */
    private void setActivitydetails(Activity activity) {
        activityNameModel.setObject(activity.getName());
        descriptionModel.setObject(activity.getDescription());
        displayOrderModel.setObject(activity.getDisplayOrder());
        choiceFormulaModel.setObject(activity.getChoiceFormula());
        if(activity.getCategory()!=null)
            categoryOfActivityModel.setObject(activity.getCategory());
        else categoryOfActivityModel.setObject(categoryModel.getObject());
    }

    /**
     * Returns a reference to the current panel. It's only used in auto redrawing the current panel
     * @return
     */
    private Panel getCurrentPanel() {
        return this;
    }

    private void init() {
        //retrieve the list of activities and list of categories
        activityList = ((WebGameApplication) WebGameApplication.get()).getUserServices().getActivityList();
        categoryList = ((WebGameApplication) WebGameApplication.get()).getUserServices().getActivityCategories();

        //add an extra activity named << New >> for activity sublist ( sublists are partisioned by categories )
        for (List<Activity> subList : activityList) {
            Activity newActivity = new Activity();
            newActivity.setName(newresStr);
            newActivity.setDescription("");
            int categoryIndex = activityList.indexOf(subList);
            if (categoryIndex < categoryList.size()) {
                newActivity.setCategory(categoryList.get(categoryIndex));
            } else {
                newActivity.setCategory("");
            }
            newActivity.setDisplayOrder(subList.size());
            subList.add(newActivity);
        }

        //add an extra category for new categories
        categoryList.add(newresStr);

        if (activityList.size() == 0) {
            List<Activity> newSubList = new LinkedList<Activity>();
            activityList.add(newSubList);

            //add a blank activity to the list
            Activity newActivity = new Activity();
            newActivity.setName(newresStr);
            newActivity.setDescription("");
            newSubList.add(newActivity);
        }
        //initialize the model for current activity list and category list

        Activity initialActivity = activityList.get(0).get(0);
        activityModel.setObject(initialActivity);
        categoryModel.setObject(categoryList.get(0));
        textCategoryModel.setObject(categoryList.get(0));

        setActivitydetails(initialActivity);



    }
}
