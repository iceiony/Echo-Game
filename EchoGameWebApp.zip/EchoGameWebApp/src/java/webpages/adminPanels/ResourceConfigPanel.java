/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package webpages.adminPanels;

import data.model.Resource;
import java.util.List;
import org.apache.wicket.ajax.AjaxRequestTarget;
import org.apache.wicket.ajax.form.AjaxFormComponentUpdatingBehavior;
import org.apache.wicket.ajax.markup.html.form.AjaxButton;
import org.apache.wicket.markup.html.form.CheckBox;
import org.apache.wicket.markup.html.form.ChoiceRenderer;
import org.apache.wicket.markup.html.form.DropDownChoice;
import org.apache.wicket.markup.html.form.Form;
import org.apache.wicket.markup.html.form.TextField;
import org.apache.wicket.markup.html.panel.Panel;
import org.apache.wicket.model.Model;
import webpages.WebGameApplication;

/**
 *
 * @author icerrr
 */
public class ResourceConfigPanel extends Panel{

        Model<Resource> resourceModel=new Model<Resource>();
        Form resourceForm=new Form("resourceForm");;
        Model<String> resNameModel=new Model<String>();
        Model<String> resLogoModel=new Model<String>();
        Model<String> globalCapModel=new Model<String>();
        Model<String> defaultUserCapModel=new Model<String>();
        Model<Boolean> accumulatesModel=new Model<Boolean>();

        List<Resource> resourceList;

        private static final String newresStr="<<New Res>>";

        public ResourceConfigPanel(String id)
        {
            super(id);

            resourceList=((WebGameApplication)WebGameApplication.get()).getUserServices().getResources();

            Resource initialResource=new Resource();
                    initialResource.setName(newresStr);
                    initialResource.setLogoURL("");
                    initialResource.setGlobalCap("0");
                    initialResource.setDefaultUserCap("0");
            resourceList.add(initialResource);

            initialResource=resourceList.get(0);
            resourceModel.setObject(initialResource);
            resNameModel.setObject(initialResource.getName());
            resLogoModel.setObject(initialResource.getLogoURL());
            globalCapModel.setObject(initialResource.getGlobalCap());
            defaultUserCapModel.setObject(initialResource.getDefaultUserCap());
            accumulatesModel.setObject(initialResource.getAccumulates());


            ChoiceRenderer aucr = new ChoiceRenderer("name", "name");
            final DropDownChoice resourceDropDown = new DropDownChoice("currentResources", resourceModel,resourceList,aucr);
            resourceDropDown.add(new AjaxFormComponentUpdatingBehavior("onchange")
            {
                @Override
                protected void onUpdate(AjaxRequestTarget target) {
                    Resource selected=resourceModel.getObject();
                    resourceModel.setObject(selected);
                    resNameModel.setObject(selected.getName());
                    resLogoModel.setObject(selected.getLogoURL());
                    globalCapModel.setObject(selected.getGlobalCap());
                    defaultUserCapModel.setObject(selected.getDefaultUserCap());
                    accumulatesModel.setObject(selected.getAccumulates());
                    target.addComponent(resourceForm);//redraw from since the model has changed
                }
            });
            resourceDropDown.setOutputMarkupId(true);
            resourceForm.add(resourceDropDown);

            resourceForm.setOutputMarkupId(true);
            resourceForm.add(new TextField<String>("resourceName",resNameModel));
            resourceForm.add(new TextField<String>("logoURL",resLogoModel));
            resourceForm.add(new TextField<String>("globalCap",globalCapModel,String.class));
            resourceForm.add(new TextField<String>("localCap",defaultUserCapModel,String.class));
            resourceForm.add(new CheckBox("accumulates",accumulatesModel));

            resourceForm.add(new AjaxButton("resourceSubmitButton", resourceForm) {
            @Override
            protected void onSubmit(AjaxRequestTarget target, Form<?> form) {
                //save the resource to the DB

                 Resource resource=resourceModel.getObject();
                 boolean redrawDropdown=(!resource.getName().equals(resNameModel.getObject()));

                 resource.setName(resNameModel.getObject());
                 resource.setLogoURL(resLogoModel.getObject());
                 resource.setGlobalCap(globalCapModel.getObject());
                 resource.setDefaultUserCap(defaultUserCapModel.getObject());
                 resource.setAccumulates(accumulatesModel.getObject());
                 //trial of persisting this object may not work;
                 boolean newResourceCreated=((WebGameApplication)WebGameApplication.get()).getAdminService().updateOrCreateResource(resource);
                //update the local resource list
                 if(newResourceCreated)
                 {
                    resource=new Resource();
                    resource.setName(newresStr);
                    resource.setLogoURL("");
                    resource.setGlobalCap("0");
                    resource.setDefaultUserCap("0");
                    resourceList.add(resource);
                    target.addComponent(resourceDropDown);
                 }
                 if(redrawDropdown) target.addComponent(resourceDropDown);

            }
          });

           resourceForm.add(new AjaxButton("resourceDeleteButton", resourceForm) {
            @Override
            protected void onSubmit(AjaxRequestTarget target, Form<?> form) {
                //save the resource to the DB
                 Resource resource=resourceModel.getObject();
                 //trial of persisting this object may not work;
                if(!newresStr.equals(resource.getName()))
                {
                 ((WebGameApplication)WebGameApplication.get()).getAdminService().deleteResource(resource);
                 resourceList.remove(resource);
                resource=resourceList.get(0);
                resourceModel.setObject(resource);
                resNameModel.setObject(resource.getName());
                resLogoModel.setObject(resource.getLogoURL());
                globalCapModel.setObject(resource.getGlobalCap());
                defaultUserCapModel.setObject(resource.getDefaultUserCap());
                accumulatesModel.setObject(resource.getAccumulates());
                target.addComponent(resourceForm);
                }
            }
          });
        
            add(resourceForm);

        }
}
