/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package webpages.adminPanels;

import data.model.Activity;
import data.model.ActivityChoice;
import data.model.ChoiceCostExpression;
import data.model.Resource;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;

import java.util.Vector;
import org.apache.wicket.AttributeModifier;
import org.apache.wicket.Application;
import org.apache.wicket.ajax.AjaxRequestTarget;
import org.apache.wicket.ajax.form.AjaxFormComponentUpdatingBehavior;
import org.apache.wicket.ajax.markup.html.AjaxLink;
import org.apache.wicket.ajax.markup.html.form.AjaxButton;
import org.apache.wicket.markup.html.WebMarkupContainer;
import org.apache.wicket.markup.html.basic.Label;
import org.apache.wicket.markup.html.form.ChoiceRenderer;
import org.apache.wicket.markup.html.form.DropDownChoice;
import org.apache.wicket.markup.html.form.Form;
import org.apache.wicket.markup.html.form.HiddenField;
import org.apache.wicket.markup.html.form.TextField;
import org.apache.wicket.markup.html.list.ListItem;
import org.apache.wicket.markup.html.list.ListView;
import org.apache.wicket.markup.html.panel.Panel;
import org.apache.wicket.model.Model;
import webpages.WebGameApplication;
import org.apache.wicket.behavior.StringHeaderContributor;
import webpages.pagePanels.NotificationPanel;
import org.apache.wicket.markup.html.CSSPackageResource;
import org.apache.wicket.markup.html.JavascriptPackageResource;

/**
 *
 * @author icerrr
 */
public class ChoiceConfigPanel extends Panel{

    private List<String> categoryList;
    private List<List<Activity>> activityList;
    private List<Resource> resourceList;

    private Model<Activity> activityModel=new Model<Activity>();
    private Model<String> categoryModel=new Model<String>();
    private Model<ActivityChoice> choiceModel=new Model<ActivityChoice>();

    private Model<String> choiceNameModel=new Model<String>();
    private Model<Activity> choiceActivityModel=new Model<Activity>();
    private Model<String> choiceDescriptionModel=new Model<String>();

    private Vector<Model<String>> opexModels;//=new HashSet<Model<String>>();
    private Vector<Model<String>> capexModels;

    DropDownChoice activityDropDown;
    DropDownChoice choiceDropDown;
    DropDownChoice categoryDropDown;
    DropDownChoice selectedActivityDropDown;

    private Form choiceForm;
    private WebMarkupContainer choiceDetails;
    private Label richTextEditor;
    ListView resourceExpressions;
    
    private static final String newresStr = "<< New >>";

     public static final StringHeaderContributor DOJO_EDITOR_CONTIRBUTOR=
     new StringHeaderContributor("  <script type='text/javascript'>"+
                                        "dojo.require(\"dijit.Editor\");"+
                                        "dojo.require(\"dijit._editor.plugins.LinkDialog\");"+
                                        "dojo.require(\"dijit._editor.plugins.ViewSource\");"+
                                        "dojo.require(\"dijit._editor.plugins.FullScreen\");"+
                                        "dojo.require('dijit._editor.plugins.TextColor');"+
                                        "dojo.require('dijit._editor.plugins.FontChoice');"+
                                        "dojo.require(\"dojo.parser\");"+
                                   "</script>");

    public ChoiceConfigPanel(String id)
    {
        super(id);
        setOutputMarkupId(true);
        add(WebGameApplication.DOJO_CONFIG_HEADER_CONTRIBUTOR);
        add(JavascriptPackageResource.getHeaderContribution(Application.get().getMetaData(WebGameApplication.DOJO_DIST_LOCATION)));
        add(CSSPackageResource.getHeaderContribution(WebGameApplication.STYLE_THUNDRA_CONTRIBUTOR));
        add(DOJO_EDITOR_CONTIRBUTOR);




        retrieveData();
//        AjaxLink refreshLink;
        add(new AjaxLink("refreshLink") {

            @Override
            public void onClick(AjaxRequestTarget target) {

                //redraw current panel

                //retrieve data and reset models
                retrieveData();
                setInitialModels();
                //update dropdown choice lists
                activityDropDown.setChoices(activityList.get(0));
                categoryDropDown.setChoices(categoryList);
                if(activityModel.getObject()!=null) choiceDropDown.setChoices(activityModel.getObject().getChoices());
                else choiceDropDown.setChoices(new LinkedList<ActivityChoice>());
                resourceExpressions.setList(resourceList);

                //add the entire form for redraw
                target.addComponent(choiceForm);
                target.appendJavascript("dijit.byId('editor1').destroy();dojo.parser.parse(dojo.byId('editor1').parentNode); ");
            }
        });

        choiceForm=new Form("ChoiceForm");
        choiceForm.setOutputMarkupId(true);
        add(choiceForm);

        setInitialModels();

        categoryDropDown=new DropDownChoice("choiceCategory",categoryModel,categoryList);
        categoryDropDown.add(new AjaxFormComponentUpdatingBehavior("onchange") {

            @Override
            protected void onUpdate(AjaxRequestTarget target) {
                updateAllFromCategory();
                //redraw all
                target.addComponent(choiceForm);
                target.appendJavascript("dijit.byId('editor1').destroy();dojo.parser.parse(dojo.byId('editor1').parentNode); ");
            }
        });
        choiceForm.add(categoryDropDown);

        ChoiceRenderer aucr=new ChoiceRenderer("name","name");
        activityDropDown=new DropDownChoice("choiceActivity",activityModel,activityList.get(0),aucr);
        activityDropDown.add(new AjaxFormComponentUpdatingBehavior("onchange") {

            @Override
            protected void onUpdate(AjaxRequestTarget target) {
                updateAllFromActivity();
                //redraw all
                target.addComponent(choiceForm);
                target.appendJavascript("dijit.byId('editor1').destroy();dojo.parser.parse(dojo.byId('editor1').parentNode); ");
            }
        });
        activityDropDown.setOutputMarkupId(true);
        choiceForm.add(activityDropDown);

        ChoiceRenderer ccr=new ChoiceRenderer("name","name");
        choiceDropDown=new DropDownChoice("selectedChoice",choiceModel,ccr);
        if(activityModel.getObject()!=null) choiceDropDown.setChoices(activityModel.getObject().getChoices());
        else choiceDropDown.setChoices(new LinkedList<ActivityChoice>());
        choiceDropDown.setOutputMarkupId(true);
        choiceDropDown.setModel(choiceModel);
        choiceDropDown.add(new AjaxFormComponentUpdatingBehavior("onchange") {

            @Override
            protected void onUpdate(AjaxRequestTarget target) {
                updateAllFromChoice();
                //redraw all
                target.addComponent(choiceForm);
                target.appendJavascript("dijit.byId('editor1').destroy();dojo.parser.parse(dojo.byId('editor1').parentNode); ");
            }
        });

        choiceForm.add(choiceDropDown);

        choiceDetails=new WebMarkupContainer("choiceDetails");
        choiceDetails.setOutputMarkupId(true);
        choiceForm.add(choiceDetails);

        choiceDetails.add(new TextField("choiceName",choiceNameModel));

        selectedActivityDropDown=new DropDownChoice("selectedChoiceActivity",choiceActivityModel,activityList.get(0),aucr);
        choiceDetails.add(selectedActivityDropDown);
   

        HiddenField descriptionField=new HiddenField("descriptionField",choiceDescriptionModel);
        richTextEditor=new Label("richTextEditor",choiceDescriptionModel);
        richTextEditor.setEscapeModelStrings(false);
        richTextEditor.add(new AttributeModifier("onchange",new Model<String>("dojo.byId('"+descriptionField.getMarkupId()+"').value = this.getValue();")));
        choiceDetails.add(descriptionField);
        choiceDetails.add(richTextEditor);

        
        resourceExpressions=new ListView("resourceExpression",resourceList) {
            @Override
            protected void populateItem(ListItem item) {
                Resource resource=(Resource)item.getModelObject();
                int resIndex=resourceList.indexOf(resource);
                item.add(new Label("resName",resource.getName()));
                item.add(new TextField("resOPEX",opexModels.get(resIndex)));
                item.add(new TextField("resCAPEX",capexModels.get(resIndex)));
            }
        };
        choiceDetails.add(resourceExpressions);

        choiceForm.add(new AjaxButton("saveChoice",choiceForm) {
            @Override
            protected void onSubmit(AjaxRequestTarget target, Form<?> form) {

                   ActivityChoice choice=choiceModel.getObject();
                   boolean isRename=!choiceNameModel.getObject().equals(choiceModel.getObject().getName());

                   if(!newresStr.equals(choiceNameModel.getObject()))
                   {
                       choice.setName(choiceNameModel.getObject());
                       choice.setDescription(choiceDescriptionModel.getObject());
                       choice.setActivity(choiceActivityModel.getObject());
                       List<ChoiceCostExpression> expressionList=choice.getCostExpressions();
                       for(int i=0;i<opexModels.size();i++)
                       {
                           if(expressionList.size()<=i) expressionList.add(new ChoiceCostExpression());
                           expressionList.get(i).setOpex(opexModels.get(i).getObject());
                           expressionList.get(i).setCapex(capexModels.get(i).getObject());
                           expressionList.get(i).setActivityChoice(choice);
                           expressionList.get(i).setResource(resourceList.get(i));
                       }
                       choice.setCostExpressions(expressionList);
                       boolean created=((WebGameApplication) WebGameApplication.get()).getAdminService().createOrUpdateActivityChoice(choice);
                       if(created)
                       {
                         ActivityChoice newChoice=new ActivityChoice();
                         newChoice.setName(newresStr);
                         newChoice.setActivity(activityModel.getObject());
                         newChoice.setDescription("description template");
                         activityModel.getObject().getChoices().add(newChoice);

                         //the folowing 2 lines are bug fix ( coice's details activity is different from selected activity )
                         activityModel.getObject().getChoices().remove(choice);
                         choice.getActivity().getChoices().add(choice.getActivity().getChoices().size()-1, choice);

                         choiceModel.setObject(choice);
                         activityModel.setObject(choice.getActivity());

                         choiceDropDown.setChoices(choice.getActivity().getChoices());

                         int activityIndex=categoryList.indexOf(choice.getActivity().getCategory());
                         activityDropDown.setChoices(activityList.get(activityIndex));
                         target.addComponent(choiceDropDown);
                         target.addComponent(activityDropDown);

                       }
                       else
                       {
                            //reset everything starting from activity
                           boolean activityChanged=false;
                          //verify if the activity was changed
                           if(!activityModel.getObject().equals(choice.getActivity()))
                           {
                               activityModel.getObject().getChoices().remove(choice);
                               Activity newActivity=choice.getActivity();
                               newActivity.getChoices().add(newActivity.getChoices().size()-1,choice);
                               activityModel.setObject(newActivity);
                               activityChanged=true;
                               int categoryIndex=categoryList.indexOf(choice.getActivity().getCategory());
                               activityDropDown.setChoices(activityList.get(categoryIndex));
                               target.addComponent(activityDropDown);
                           }
                          //verify if it's a rename
                           if(isRename || activityChanged)
                           {
                               if(isRename){
                               int indexChanged=activityModel.getObject().getChoices().indexOf(choiceModel.getObject());
                               activityModel.getObject().getChoices().set(indexChanged, choice);
                               }
                               choiceDropDown.setChoices(activityModel.getObject().getChoices());
                               choiceModel.setObject(choice);
                               target.addComponent(choiceDropDown);
                           }

                       }
                   }
            }
        });

        choiceForm.add(new AjaxButton("deleteChoice",choiceForm)
        {
            @Override
            protected void onSubmit(AjaxRequestTarget target, Form<?> form)
            {
                if(!newresStr.equals(choiceModel.getObject().getName()))
                {
                activityModel.getObject().getChoices().remove(choiceModel.getObject());
                ((WebGameApplication)WebGameApplication.get()).getAdminService().deleteActivityChoice(choiceModel.getObject());

                updateAllFromChoice();
                target.addComponent(choiceForm);
                target.appendJavascript("dijit.byId('editor1').destroy();dojo.parser.parse(dojo.byId('editor1').parentNode); ");
                }
            }
        });
    }

    private void retrieveData()
    {
        activityList = ((WebGameApplication) WebGameApplication.get()).getUserServices().getActivityListEgarly();
        categoryList = ((WebGameApplication) WebGameApplication.get()).getUserServices().getActivityCategories();
        resourceList = ((WebGameApplication) WebGameApplication.get()).getUserServices().getResources();

        for(List<Activity> subList:activityList)
        {
            for(Activity activity:subList)
            {
                ActivityChoice newChoice=new ActivityChoice();
                newChoice.setName(newresStr);
                newChoice.setActivity(activity);
                //newChoice.setCostExpressions(new LinkedList<ChoiceCostExpression>());
                newChoice.setDescription("Description Template");
                activity.getChoices().add(newChoice);
            }
        }

        if(activityList.size()==0)
        {
            Activity dummy=new Activity();
            dummy.setName("dummy");
            dummy.setCategory("dummy");
            activityList=new LinkedList<List<Activity>>();
            activityList.add(new LinkedList<Activity>());
            activityList.get(0).add(dummy);
            categoryList=new LinkedList<String>();
            categoryList.add("dummy");
        }

        //expression models need to be crated here
        opexModels=new Vector<Model<String>>(resourceList.size());
        capexModels=new Vector<Model<String>>(resourceList.size());
        for(int i=0;i<resourceList.size();i++)
        {
            opexModels.add(new Model<String>("0"));//default values
            capexModels.add(new Model<String>("0"));//default values
        }
    }

    

    private void setInitialModels()
    {
        if(activityList.size()!=0)
        {
            Activity activ=activityList.get(0).get(0);
            categoryModel.setObject(activ.getCategory());
            activityModel.setObject(activ);
            if(activ.getChoices().size()!=0) 
            {
                ActivityChoice initialChoice=activ.getChoices().get(0);
                choiceModel.setObject(initialChoice);
                choiceNameModel.setObject(initialChoice.getName());
                choiceActivityModel.setObject(activ);
                choiceDescriptionModel.setObject(initialChoice.getDescription());

                if(initialChoice.getCostExpressions().size()>0)
                {
                    List<ChoiceCostExpression> expressionList=initialChoice.getCostExpressions();
                            for(int i=0;(i<opexModels.size() && i< expressionList.size());i++)
                            {
                                opexModels.get(i).setObject(expressionList.get(i).getOpex());
                                capexModels.get(i).setObject(expressionList.get(i).getCapex());
                            }
                }
            }
        }
    }

    private void updateAllFromCategory()
    {
    //set all the models and dop-down lists
                String currentCategory=categoryModel.getObject();
                int categoryIndex=categoryList.indexOf(currentCategory);
                activityDropDown.setChoices(activityList.get(categoryIndex));
                activityModel.setObject(activityList.get(categoryIndex).get(0));
                updateAllFromActivity();
    }

    private void updateAllFromActivity()
    {
                Activity activity= activityModel.getObject();
                choiceDropDown.setChoices(activity.getChoices());
                choiceModel.setObject(activity.getChoices().get(0));
                updateAllFromChoice();
    }

    private void updateAllFromChoice()
    {
                ActivityChoice choice=choiceModel.getObject();

                String currentCategory=categoryModel.getObject();
                int categoryIndex=categoryList.indexOf(currentCategory);
                selectedActivityDropDown.setChoices(activityList.get(categoryIndex));

                choiceNameModel.setObject(choice.getName());
                choiceActivityModel.setObject(choice.getActivity());
                choiceDescriptionModel.setObject(choice.getDescription());
            
                if(choice.getCostExpressions().size()>0)
                {
                    List<ChoiceCostExpression> expressionList=choice.getCostExpressions();
                    for(int i=0;(i<opexModels.size() && i<expressionList.size());i++)
                    {
                        opexModels.get(i).setObject(expressionList.get(i).getOpex());
                        capexModels.get(i).setObject(expressionList.get(i).getCapex());
                    }
                }
                else
                {
                   for(int i=0;i<resourceList.size();i++)
                    {
                         opexModels.get(i).setObject("0");
                        capexModels.get(i).setObject("0");
                    }
                }
    }

}
