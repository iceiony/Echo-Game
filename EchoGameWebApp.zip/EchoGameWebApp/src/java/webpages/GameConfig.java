/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package webpages;

import org.apache.wicket.authorization.strategies.role.annotations.AuthorizeInstantiation;
import org.apache.wicket.markup.html.border.Border;
import org.apache.wicket.protocol.https.RequireHttps;
import webpages.adminPanels.ActivityConfigPanel;
import webpages.adminPanels.BehaviourConfigPanel;
import webpages.adminPanels.ResourceConfigPanel;
import webpages.adminPanels.ChoiceConfigPanel;
import webpages.adminPanels.ModeConfigurationPanel;
/**
 *
 * @author icerrr
 */
@RequireHttps
@AuthorizeInstantiation({"ROLE_admin"})
public class GameConfig extends GenericWebPage{

    public GameConfig()
    {
        Border pageBorder=new GameBorder("border");
        add(pageBorder);

        pageBorder.add(new ModeConfigurationPanel("gameModePanel"));
        pageBorder.add(new BehaviourConfigPanel("behaviourPanel"));
        pageBorder.add(new ResourceConfigPanel("resourcePanel"));
        pageBorder.add(new ActivityConfigPanel("activityPanel"));

        pageBorder.add(new ChoiceConfigPanel("choiceConfigPanel"));
    }
}
