/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package webpages;

import javax.servlet.http.Cookie;
import org.apache.wicket.authorization.strategies.role.metadata.MetaDataRoleAuthorizationStrategy;
import org.apache.wicket.markup.html.border.Border;
import org.apache.wicket.markup.html.link.BookmarkablePageLink;
import org.apache.wicket.markup.html.link.Link;
import org.apache.wicket.protocol.http.WebRequest;
import org.apache.wicket.protocol.http.WebResponse;
/**
 *
 * @author icerrr
 */
public class GameBorder extends Border{

      Link logoutLink;
      Link configLink;//only for admin ( config the game session and lunch the game)
      Link controlLink;//only for admin ( control the game while in play )

    GameBorder(String id) {
        super(id);
        add(logoutLink = new Link("logoutLink")
        {
            public void onClick()
            {
                ((CustomSession) getSession()).signout();
                //delete username cookie if game ended
                if(!((WebGameApplication)WebGameApplication.get()).getUserServices().hasGameStarted())
                {
                    Cookie cookie=((WebRequest)getRequestCycle().getRequest()).getCookie("border.signInPanel.signInForm.username");
                    cookie.setMaxAge(-1);
                    ((WebResponse)getRequestCycle().getResponse()).addCookie(cookie);
                }
                setResponsePage(Home.class);
            }
        });

        add(configLink=new BookmarkablePageLink("configLink",GameConfig.class));
        add(controlLink=new BookmarkablePageLink("controlLink",AdminPage.class));

        MetaDataRoleAuthorizationStrategy.authorize(configLink, RENDER, "ROLE_admin");
        MetaDataRoleAuthorizationStrategy.authorize(controlLink, RENDER, "ROLE_admin");
    }

}
