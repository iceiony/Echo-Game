package webpages;
public class ErrorPage extends GenericWebPage
{
    private String errorInfo = "We are sorry but an error occurred!";

    public ErrorPage()
    {
    }

    public String getErrorInfo()
    {
        return errorInfo;
    }

    public void setErrorInfo(String errorInfo)
    {
        this.errorInfo = errorInfo;
    }

}
