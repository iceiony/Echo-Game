/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package webpages.pagePanels;

import data.model.ActivityChoice;
import data.model.ChoiceCostExpression;
import data.model.Resource;
import data.model.Variable;
import java.text.DecimalFormat;
import java.util.Collections;
import java.util.List;
import org.apache.wicket.AttributeModifier;
import org.apache.wicket.ajax.AjaxRequestTarget;
import org.apache.wicket.markup.html.WebMarkupContainer;
import org.apache.wicket.markup.html.basic.Label;
import org.apache.wicket.markup.html.list.ListItem;
import org.apache.wicket.markup.html.list.ListView;
import org.apache.wicket.markup.html.panel.Panel;
import org.apache.wicket.model.Model;
import webpages.WebGameApplication;
import org.apache.commons.beanutils.BeanComparator;
/**
 *
 * @author icerrr
 */
public class ActivityProjectionsPanel extends Panel{

    private ActivityChoice currentChoice;
    private List<Variable> variableList;//variable list and values ;
    private List<Resource> resourceList;
    private static final DecimalFormat twoDForm = new DecimalFormat("#.##");



    private WebMarkupContainer projectionContainer;
    private ListView resourceCostListView;

    public ActivityProjectionsPanel(String id)
    {
        super(id);

        resourceList=((WebGameApplication)WebGameApplication.get()).getUserServices().getResources();

        projectionContainer=new WebMarkupContainer("projectionContents");
        projectionContainer.setOutputMarkupId(true);
        add(projectionContainer);

        resourceCostListView=new ListView("resourceProjection",resourceList) {
            @Override
            protected void populateItem(ListItem item) {
               Resource res=(Resource) item.getModelObject();
               //add the resource logo or name ( depending if the logo is present or not)
               Label resNameLabel;
               Label resLogoLabel;
               item.add(resNameLabel=new Label("resName",res.getName()));
               item.add(resLogoLabel=new Label("resLogo"));
               if(res.getLogoURL()!=null&& !res.getLogoURL().isEmpty())
               {
                resNameLabel.setVisible(false);//the name will not be rendered at all
                resLogoLabel.add(new AttributeModifier("src",new Model(res.getLogoURL())));
               }
               else resLogoLabel.setVisible(false);//the logo will not be rendered at all

               int index=item.getIndex();

               double values[]=((WebGameApplication)WebGameApplication.get()).getUserServices()
                                .calculateChoiceResourceCost(currentChoice, index, variableList);

               item.add(new Label("resOPEX",twoDForm.format(values[0])));
               item.add(new Label("resCAPEX",twoDForm.format(values[1])));

            }
        };
        projectionContainer.add(resourceCostListView);

    }


    /**
     * Updates the choice projections and list of variables
     * @param choice
     */
    public void setCurrentChoice(ActivityChoice choice)
    {
        //update the panel with the new choice
        this.currentChoice=((WebGameApplication)WebGameApplication.get()).getUserServices().getActivityChoiceEagerly(choice.getId());
        this.currentChoice.setWasChanged(choice.isWasChanged());
        //resourceCostListView.setList(choice.getCostExpressions());
        List<ChoiceCostExpression> costList=this.currentChoice.getCostExpressions();
        BeanComparator comparator=new BeanComparator("resource");
        Collections.sort(costList,comparator);
        this.currentChoice.setCostExpressions(costList);
        
//        //order the expressions according to the resource list
//        for(int index=0;index<currentChoice.getCostExpressions().size();index++)
//        {
//           int resIndex=resourceList.indexOf(currentChoice.getCostExpressions().get(index).getResource());
//           if(resIndex!=index)
//           {
//               ChoiceCostExpression choice1=currentChoice.getCostExpressions().get(index);
//               ChoiceCostExpression choice2=currentChoice.getCostExpressions().get(resIndex);
//               currentChoice.getCostExpressions().set(resIndex, choice1);
//               currentChoice.getCostExpressions().set(index, choice2);
//           }
//        }
    }

    public ActivityChoice getCurrentChoice()
    {
        return currentChoice;
    }

    public void setVariableList(List<Variable> varList)
    {
        this.variableList=varList;
    }

    public List<Variable> getVariableList()
    {
        return this.variableList;
    }

    public void setVariableValue(int varIndex,double varValue)
    {
        variableList.get(varIndex).setValue(varValue);
    }

    public void redraw(AjaxRequestTarget target)
    {
        target.addComponent(projectionContainer);
    }
}
