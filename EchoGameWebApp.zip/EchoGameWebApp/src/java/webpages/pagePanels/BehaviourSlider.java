/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package webpages.pagePanels;

import data.model.BehaviourIndicator;
import data.model.IndicatorOption;
import org.apache.wicket.ajax.AjaxRequestTarget;
import org.apache.wicket.ajax.form.AjaxFormComponentUpdatingBehavior;
import org.apache.wicket.markup.html.WebMarkupContainer;
import org.apache.wicket.markup.html.basic.Label;
import org.apache.wicket.markup.html.form.CheckBox;
import org.apache.wicket.markup.html.panel.Panel;
import org.apache.wicket.model.Model;
import org.apache.wicket.model.PropertyModel;

/**
 *
 * @author icerrr
 */
public class BehaviourSlider extends Panel implements BehaviourPanelInterface{

    Model<Double> optionValueModel;
    Model<Boolean> hiddenModel=new Model<Boolean>();
    IndicatorOption option;

    public BehaviourSlider(String id, BehaviourIndicator indicator) {
        super(id);
        setOutputMarkupId(true);
        if (indicator.getDescription() != null) {
            add(new Label("indicatorDescription", indicator.getDescription()));
        } else {
            Label description = new Label("indicatorDescription", "no description");
            description.setVisible(false);//will not draw actually
            add(description);
        }

        if (indicator.getDisplayName() != null) {
            add(new Label("indicatorName", indicator.getDisplayName()));
        } else {
            Label name = new Label("indicatorName", "no name");
            name.setVisible(false);
            add(name);
        }

        option = indicator.getOptions().get(0);

        optionValueModel = new Model<Double>((double) option.getOptionValue());
        InputSlider slider = new InputSlider("slider", optionValueModel);
        slider.setMinValue(option.getMinValue());
        slider.setMaxValue(option.getMaxValue());
        slider.setSliderValue(optionValueModel);
        slider.setDijitId("slider"+getMarkupId());
        slider.setDiscreteValue(true);

        slider.getSliderValueField().add(new AjaxFormComponentUpdatingBehavior("onchange") {

            @Override
            protected void onUpdate(AjaxRequestTarget target) {
                option.setOptionValue((int) optionValueModel.getObject().doubleValue());
            }
        });
        add(slider);

        CheckBox hiddenCheckBox;
        add(hiddenCheckBox=new CheckBox("hidden",hiddenModel));

        hiddenCheckBox.add(new AjaxFormComponentUpdatingBehavior("onchange") {

            @Override
            protected void onUpdate(AjaxRequestTarget target) {
                 //this is here just to update the checkbox
            }
        });
    }

    public IndicatorOption getOption() {
        option.setHidden(hiddenModel.getObject());
        return option;
    }
}
