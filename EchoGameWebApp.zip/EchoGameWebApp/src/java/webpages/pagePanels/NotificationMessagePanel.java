/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package webpages.pagePanels;

import data.model.Notification;
import org.apache.wicket.markup.html.basic.Label;
import org.apache.wicket.markup.html.panel.Panel;
import org.apache.wicket.model.Model;


/**
 * The panel contained in the modal window
 * @author icerrr
 */
public class NotificationMessagePanel extends Panel{

//    private  Model<String> sender;
    private Model<String> message;


    public NotificationMessagePanel(String id)
    {
        super(id);
//        add(new Label("sender",sender=new Model<String>("dummyData")));
        add(new Label("message",message=new Model<String>("dummyData")).setEscapeModelStrings(false));
    }

    public void setNotificationMessage(Notification note)
    {
       message.setObject(note.getMessage());
    }

}
