/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package webpages.pagePanels;

import data.model.Activity;
import data.model.ActivityChoice;
import data.model.Resource;
import java.text.DecimalFormat;
import java.util.List;
import java.util.concurrent.locks.ReentrantLock;
import org.apache.wicket.Application;
import org.apache.wicket.AttributeModifier;
import org.apache.wicket.ajax.AjaxRequestTarget;
import org.apache.wicket.ajax.AjaxEventBehavior;
import org.apache.wicket.behavior.StringHeaderContributor;
import org.apache.wicket.markup.html.JavascriptPackageResource;
import org.apache.wicket.markup.html.WebMarkupContainer;
import org.apache.wicket.markup.html.basic.Label;
import org.apache.wicket.markup.html.form.Button;
import org.apache.wicket.markup.html.list.ListItem;
import org.apache.wicket.markup.html.list.ListView;
import org.apache.wicket.markup.html.panel.Panel;
import org.apache.wicket.model.Model;
import webpages.CustomSession;
import webpages.WebGameApplication;

/**
 *
 * @author icerrr
 */
public class GlobalProjectionsPanel extends Panel {

    private List<Resource> resourceList;
    private static final DecimalFormat twoDForm = new DecimalFormat("#.##");
    private WebMarkupContainer projectionContainer;
    private ActivityPanel activityPanel;//it's used to retrieve the values used in the computation
    private StatsPanel statsPanel;
    private double[] projectionLimits;

    public static final StringHeaderContributor LABEL_FEEDBACK_SCRIPT =
            new StringHeaderContributor("<script type=\"text/javascript\">\n"
            + "function giveFeedback(isVissible,isWarning,message){\n"
            + "aux=dojo.byId('saveButtonLabel');\n"
            + "aux.innerHTML=message;\n"
            + "if(isWarning) aux.style.color='red';\n"
            + "else aux.style.color='lime';\n"
            + "if(isVissible) aux.style.visibility='visible';\n"
            + "else aux.style.visibility='hidden';}\n"
            + "</script>\n");

    public GlobalProjectionsPanel(String id) {
        super(id);
        add(WebGameApplication.DOJO_CONFIG_HEADER_CONTRIBUTOR);
        add(JavascriptPackageResource.getHeaderContribution(Application.get().getMetaData(WebGameApplication.DOJO_DIST_LOCATION)));
        add(LABEL_FEEDBACK_SCRIPT);

        resourceList = ((WebGameApplication) WebGameApplication.get()).getUserServices().getResources();
        if(statsPanel!=null) projectionLimits=statsPanel.getLocalCaps();

        projectionContainer = new WebMarkupContainer("globalProjectionContents");
        projectionContainer.setOutputMarkupId(true);
        add(projectionContainer);

        projectionContainer.add(new ListView("globalResourceProjection", resourceList) {

            @Override
            protected void populateItem(ListItem item) {
                Resource res = (Resource) item.getModelObject();
                //add the resource logo or name ( depending if the logo is present or not)
                Label resNameLabel;
                Label resLogoLabel;
                item.add(resNameLabel = new Label("globalResName", res.getName()));
                item.add(resLogoLabel = new Label("globalResLogo"));
                if (res.getLogoURL() != null && !res.getLogoURL().isEmpty()) {
                    resNameLabel.setVisible(false);//the name will not be rendered at all
                    resLogoLabel.add(new AttributeModifier("src", new Model(res.getLogoURL())));
                } else {
                    resLogoLabel.setVisible(false);//the logo will not be rendered at all
                }

                if (activityPanel != null) {
                    // position 0 => opex ; position 1=> capex;
                    double expValues[] = ((WebGameApplication)WebGameApplication.get()).getUserServices().calcualteTotalResourceCost(res.getId(), activityPanel.getSelectedChoices());

                    //capex + opex < resCap(AKA PROJECTION LIMITS)
                    Model<String> colorModel=new Model<String>("color:lime");//lime-> ok ; blue->warning; red->over the limits
                    if(projectionLimits!=null && projectionLimits.length>item.getIndex())
                    {
                        if(projectionLimits[item.getIndex()]*0.7< expValues[0]+expValues[1]) colorModel.setObject("color:blue");
                        if(projectionLimits[item.getIndex()]<expValues[0]+expValues[1]) colorModel.setObject("color:red");
                    }

                    Label opex;
                    Label capex;
                    item.add(opex=new Label("globalResOPEX", twoDForm.format(expValues[0])));
                    item.add(capex=new Label("globalResCAPEX", twoDForm.format(expValues[1])));
                    opex.add(new AttributeModifier("style",colorModel));
                    capex.add(new AttributeModifier("style",colorModel));
                } else {
                    item.add(new Label("globalResOPEX", "0"));
                    item.add(new Label("globalResCAPEX", "0"));
                }
            }
        });


        Button previewButton = new Button("previewButton");
        previewButton.add(new AjaxEventBehavior("onclick") {

            @Override
            protected void onEvent(AjaxRequestTarget target) {
                 //synchronization at session level will prevent users from trying to overload the server by pressing the submit button multiple times
                try{
                if (((CustomSession) getSession()).getSessionLock().tryLock()) {
                    projectionLimits=statsPanel.getLocalCaps();
                target.addComponent(projectionContainer);
                }
                }
                finally
                {
                    //unlock the session if it was locked and owned by current thread
                    ReentrantLock sessionLock=((CustomSession) getSession()).getSessionLock();
                   if(sessionLock.isHeldByCurrentThread()) sessionLock.unlock();
                }
            }
        });

        add(previewButton);

        Button submitButton = new Button("saveButton");
        submitButton.add(new AjaxEventBehavior("onclick") {

            @Override
            protected void onEvent(AjaxRequestTarget target) {

                //synchronization at session level will prevent users from trying to overload the server by pressing the submit button multiple times
                try{
                if (((CustomSession) getSession()).getSessionLock().tryLock()) {

                    int currentTurn=((WebGameApplication)WebGameApplication.get()).getUserServices().getTurnNumber();
                    String username = ((CustomSession) getSession()).getUserName();
                    if(((CustomSession)getSession()).madeLastSave(currentTurn))
                    {
                        target.appendJavascript("giveFeedback(true,true,'Your choices has allready been made for this turn("+currentTurn+")');");
                        return;
                    }
                    if(((WebGameApplication)WebGameApplication.get()).getUserServices().wasEliminated(username))
                    {
                        target.appendJavascript("giveFeedback(true,true,\"Your were eliminated from the game. You can't make new choices.\");");
                        return;
                    }

                    //test if the user has completed all choices
                    boolean wasSuccessful = true;
                    
                    for (List<Model<ActivityChoice>> choiceByCategory : activityPanel.getSelectedChoices()) {
                        for (Model<ActivityChoice> choiceModel : choiceByCategory) {
                            if (choiceModel.getObject() == null) {
                                wasSuccessful = false;
                                break;
                            }
                        }
                        if (!wasSuccessful) {
                            break;
                        }
                    }
                    if (!wasSuccessful) {
                        target.appendJavascript("giveFeedback(true,false,'Please make a choice for each activity');");
                    } else {
                        //returns true if the values were succesfully persisted
                        wasSuccessful = ((WebGameApplication) WebGameApplication.get()).getUserServices().saveUserChoices(username, activityPanel.getSelectedChoices());
                        if (wasSuccessful) {
                            //block the user's saves for this session
                            ((CustomSession)getSession()).setLastSave(currentTurn);
                            //update the choice list of each activity and set wasChanged to false;
                            for(List<Model<ActivityChoice>> chioceByCategory:activityPanel.getSelectedChoices())
                            for(Model<ActivityChoice> choiceModel:chioceByCategory)
                            {
                              if(choiceModel.getObject().isWasChanged())
                              {
                               Activity activ=choiceModel.getObject().getActivity();
                               for(ActivityChoice choice:activ.getChoices())
                                   choice.setWasChanged(true);
                               choiceModel.getObject().setWasChanged(false);
                              }
                            }

                            target.appendJavascript("giveFeedback(true,false,\"Save successful.Now you'll have to wait for the end of the turn.\");");
                        } else {
                            target.appendJavascript("giveFeedback(true,true,'Your choices could not be saved for turn "+currentTurn+".');");
                        }
                        target.addComponent(projectionContainer);
                    }
                }
                }
                finally
                {
                    //unlock the session if it was locked and owned by current thread
                    ReentrantLock sessionLock=((CustomSession) getSession()).getSessionLock();
                   if(sessionLock.isHeldByCurrentThread()) sessionLock.unlock();
                }
            }
        });
        add(submitButton);

    }

//    /**
//     * Evaluets the total cost consumtption of a resource
//     * @param resId
//     * @return double[2] where position 0 => opex ; position 1=> capex;
//     */
//    private double[] calcualteResourceCost(long resId) {
//        double expValues[] = {0, 0};
//        //activityPanel does not eagerly retrieve the activity list
//        //this panel has to retrieve CostExpressions on its own
//        for (List<Model<ActivityChoice>> choiceByCategory : activityPanel.getSelectedChoices()) {
//            for (Model<ActivityChoice> choiceModel : choiceByCategory) {
//                ActivityChoice choice = choiceModel.getObject();
//                if (choice != null) {
//                    ChoiceCostExpression expression =
//                            ((WebGameApplication) WebGameApplication.get()).getUserServices().getCostByResourceAndChoice(resId, choice.getId());
//                    if (expression != null) {
//                        expValues[0] += ((WebGameApplication) WebGameApplication.get()).getUserServices().evaluateExpression(expression.getOpex(), choice.getActivity().getVariables());
//                        if(choice.isWasChanged()) expValues[1] += ((WebGameApplication) WebGameApplication.get()).getUserServices().evaluateExpression(expression.getCapex(), choice.getActivity().getVariables());
//                    }
//                }
//            }
//        }
//        return expValues;
//    }

    public void setActivityPanel(ActivityPanel panel) {
        this.activityPanel = panel;
    }

    public void setStatsPanel(StatsPanel panel)
    {
        this.statsPanel=panel;
        projectionLimits=statsPanel.getLocalCaps();
    }
}
