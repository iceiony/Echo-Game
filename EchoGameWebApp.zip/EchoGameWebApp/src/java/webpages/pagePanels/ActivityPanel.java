/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package webpages.pagePanels;

import data.model.Activity;
import data.model.ActivityChoice;
import data.model.Variable;
import java.util.LinkedList;
import java.util.List;
import java.util.Vector;
import org.apache.wicket.Application;
import org.apache.wicket.AttributeModifier;
import org.apache.wicket.markup.html.WebMarkupContainer;

import org.apache.wicket.ajax.AjaxEventBehavior;
import org.apache.wicket.behavior.AttributeAppender;
import org.apache.wicket.ajax.AjaxRequestTarget;
import org.apache.wicket.ajax.form.AjaxFormComponentUpdatingBehavior;
import org.apache.wicket.ajax.markup.html.form.AjaxButton;
import org.apache.wicket.behavior.StringHeaderContributor;
import org.apache.wicket.markup.html.JavascriptPackageResource;
import org.apache.wicket.markup.html.basic.Label;
import org.apache.wicket.markup.html.form.Button;
import org.apache.wicket.markup.html.form.ChoiceRenderer;
import org.apache.wicket.markup.html.form.DropDownChoice;
import org.apache.wicket.markup.html.form.Form;
import org.apache.wicket.markup.html.form.TextField;
import org.apache.wicket.markup.html.list.ListItem;
import org.apache.wicket.markup.html.list.ListView;

import org.apache.wicket.markup.html.panel.Panel;
import org.apache.wicket.model.Model;
import org.apache.wicket.model.PropertyModel;
import services.UserServices;
import webpages.CustomSession;
import webpages.WebGameApplication;

/**
 *
 * @author icerrr
 */
public class ActivityPanel extends Panel {

    public static final StringHeaderContributor DOJO_CONFIG =
            new StringHeaderContributor(" <script type='text/javascript' > " +
                                        "dojo.require(\"dojo._base.query\");" +
                                        "dojo.require(\"dojo.parser\");" +
                                        "</script>");

    List<List<Model<ActivityChoice>>> choices;
    List<List<List<Model<Double>>>> variables;

    Model<String> visibilityModel = new Model<String>("visibility:hidden;");
    Label optionDescriptionLabel = new Label("descriptionContainer", new PropertyModel(this, "optionDescriptionText")) {
        {
            setOutputMarkupId(true);
            add(new AttributeModifier("style", visibilityModel));
            setEscapeModelStrings(false);
        }
    };
    private String optionDescriptionText = "No Option Selected";

    private int tabIndex=0;
    private Vector<Label> tabLabels=new Vector<Label>();
    private AttributeModifier selected=new AttributeModifier("class",new Model("topRounded selected"));

   private WebMarkupContainer activityListContainer;
   private ListView actvitiList;
    private List<List<Activity>> activities;

    private String username;

   private ActivityProjectionsPanel projectionPanel;//reference to the existing projection panel

       public static final StringHeaderContributor SLIDER_CALLBACK_SCRIPT =
    new StringHeaderContributor("<script type=\"text/javascript\">" +
                                "function run(inputId){" +
                                "if(dojo.byId(inputId).timeout) clearTimeout(dojo.byId(inputId).timeout);" +
                                "dojo.byId(inputId).timeout=setTimeout(\"dojo.byId(\"+inputId+\").onchange()\",500);}" +
                        	"</script>");

    public ActivityPanel(String id) {
        super(id);

        add(WebGameApplication.DOJO_CONFIG_HEADER_CONTRIBUTOR);
        add(JavascriptPackageResource.getHeaderContribution(Application.get().getMetaData(WebGameApplication.DOJO_DIST_LOCATION)));
        add(DOJO_CONFIG);
        add(SLIDER_CALLBACK_SCRIPT);

        UserServices services = ((WebGameApplication)WebGameApplication.get()).getUserServices();

        //category tab rendering
        List<String> categories=services.getActivityCategories();
        add(new Label("tabSize","ul#tabs li{width:"+(99.8/categories.size())+"%;} "));
        add(new ListView("categoryTab",categories) {
            @Override
            protected void populateItem(ListItem item) {
                String category=(String) item.getModelObject();
                final int index=item.getIndex();

                Label categoryLink=new Label("categoryLink",category);

                if(index==tabIndex) categoryLink.add(selected);

                categoryLink.setOutputMarkupId(true);
                tabLabels.add(categoryLink);

                categoryLink.add(new AjaxEventBehavior("onclick") {

                    @Override
                    protected void onEvent(AjaxRequestTarget target) {
                        if(index!=tabIndex)
                        {
                            //destroy all previous dijit objects
                            target.appendJavascript("dijit.registry.forEach(function(widget, index, hash){ widget.destroy(); });");

                            tabLabels.get(tabIndex).remove(selected);
                            target.addComponent(tabLabels.get(tabIndex));
                            tabIndex=index;
                            tabLabels.get(tabIndex).add(selected);
                            target.addComponent(tabLabels.get(tabIndex));
                            target.appendJavascript("Nifty('a.topRounded','small transparent top');");
     

                            actvitiList.setList(activities.get(tabIndex));
                            target.addComponent(activityListContainer);
                            target.appendJavascript(" Nifty('span.activityDescription','small transparent');");
                            //create new dijit objects
                            target.appendJavascript("dojo.parser.parse(dojo.byId('inputContainer'))");
                            //target.appendJavascript("dojo.query('[dojoType=dijit.form.HorizontalSlider]',dojo.byId('inputContainer')).forEach(function(node, index, arr){ new });");
                        }
                    }
                });
                item.add(categoryLink);
            }
        });
       

        //get the user's name
        username=((CustomSession)getSession()).getUserName();

        //activities and choice rendering
        activities = services.getActivityList();

        //create the models for each activity partitioned by categories
        choices = new LinkedList<List<Model<ActivityChoice>>>();
        variables=new LinkedList<List<List<Model<Double>>>>();
        for(List<Activity> categoryPartition:activities)
        {
            List<Model<ActivityChoice>> buildingList=new LinkedList<Model<ActivityChoice>>();
            List<List<Model<Double>>> activVarList=new LinkedList<List<Model<Double>>>();
            
            for(Activity activity:categoryPartition)
            {
                //TEST THIS IF IT IS NEEDED -> make all choices of this activity be false by default

                Model<ActivityChoice> auxChoice=new Model<ActivityChoice>();

                //add here the ActivityChoice that is default to the user
                ActivityChoice defaultChoice=((WebGameApplication)WebGameApplication.get())
                                                .getUserServices().returnDefaultActivityChoice(activity,username);
                auxChoice.setObject(defaultChoice);
                if(defaultChoice!=null) defaultChoice.setWasChanged(false);

                buildingList.add(auxChoice);
                List<Model<Double>> varList=new LinkedList<Model<Double>>();
                for(Variable var:activity.getVariables())
                    varList.add(new Model<Double>(var.getValue()));//default value of the variable

                   activVarList.add(varList);
            }
            choices.add(buildingList);
            variables.add(activVarList);
        }

        activityListContainer=new WebMarkupContainer("activityListContainer");
        activityListContainer.setOutputMarkupId(true);
        add(activityListContainer);
        activityListContainer.add(actvitiList=new ListView("activityList", activities.get(tabIndex)) {
            @Override
            protected void populateItem(final ListItem item) {
                final Activity activityElement = (Activity) item.getModelObject();
                item.add(new Label("activityName", activityElement.getName()));

                item.add(new Label("activityDescription", activityElement.getDescription()) {
                    {
                        this.setVisible(activityElement.getDescription() != null && !activityElement.getDescription().isEmpty());
                    }
                });

                final Model<ActivityChoice> choiceModel = choices.get(tabIndex).get(item.getIndex());
                ChoiceRenderer aucr = new ChoiceRenderer("name", "name");
                DropDownChoice choiceOptions = new DropDownChoice("choiceDropdown", choiceModel, activityElement.getChoices(), aucr);
                choiceOptions.setRequired(true);
                item.add(choiceOptions);

                choiceOptions.add(new AjaxFormComponentUpdatingBehavior("onchange") {
                    @Override
                    protected void onUpdate(AjaxRequestTarget target) {
                        if (choiceModel.getObject() != null) 
                            optionDescriptionText = ((ActivityChoice) choiceModel.getObject()).getDescription();
                        if (optionDescriptionText != null && !optionDescriptionText.isEmpty()) {
                                visibilityModel.setObject("visibility:visible;");
                                target.appendJavascript("Nifty('span.activityChoiceDescription','small transparent');");
                            }
                        else
                        visibilityModel.setObject("visibility:hidden;");

                        target.addComponent(optionDescriptionLabel);
                        if(projectionPanel!=null)
                        projectionPanel.setCurrentChoice((ActivityChoice)choiceModel.getObject());
                        projectionPanel.setVariableList(((ActivityChoice)choiceModel.getObject()).getActivity().getVariables());
                        projectionPanel.redraw(target);
                    }
                });
                item.add(new ListView("variableList",activityElement.getVariables()) {

                        @Override
                        protected void populateItem(final ListItem varItem) {
                            Variable var=(Variable)varItem.getModelObject();
                            varItem.add(new Label("varName",var.getDescription()));
                            Model<Double> varModel=variables.get(tabIndex).get(item.getIndex()).get(varItem.getIndex());

                            final InputSlider slider=new InputSlider("varInputSlider",varModel);
                            slider.setDiscreteValue(var.isDiscrete());
                            slider.setMinValue(var.getMinValue());
                            slider.setMaxValue(var.getMaxValue());
                            slider.setDijitId("slider"+tabIndex+item.getIndex()+varItem.getIndex());
                            varItem.add(slider);
                            slider.getSliderValueField().add(new AjaxFormComponentUpdatingBehavior("onchange") {

                            @Override
                            protected void onUpdate(AjaxRequestTarget target) {
                               if(projectionPanel!=null)
                               {
                               double newValue=(Double)slider.getSliderValueField().getModel().getObject();
                               activityElement.getVariables().get(varItem.getIndex()).setValue(newValue);

                               ActivityChoice correspondingChoice=choices.get(tabIndex).get(item.getIndex()).getObject();
                               if(correspondingChoice!=null){
                                   if(!correspondingChoice.equals(projectionPanel.getCurrentChoice()))
                                   {
                                   projectionPanel.setCurrentChoice(choices.get(tabIndex).get(item.getIndex()).getObject());
                                   projectionPanel.setVariableList(activityElement.getVariables());
                                   }
                                   projectionPanel.setVariableValue(varItem.getIndex(),newValue);
                                   projectionPanel.redraw(target);
                                   }
                               }
                            }
                        });

                        }
                    });
            }
        });
        add(optionDescriptionLabel);
    }

    public List<List<Model<ActivityChoice>>> getSelectedChoices() {
        return choices;
    }

    public void setProjectionPanel(ActivityProjectionsPanel panel)
    {
        this.projectionPanel=panel;
    }

    public ActivityProjectionsPanel getProjectionPanel()
    {
        return this.projectionPanel;
    }
}
