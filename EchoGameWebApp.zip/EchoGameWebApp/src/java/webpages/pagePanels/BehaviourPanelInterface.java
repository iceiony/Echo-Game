/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package webpages.pagePanels;

import data.model.IndicatorOption;

/**
 *
 * @author icerrr
 */
public interface BehaviourPanelInterface {

    /**
     *
     * @return the indicator option selected by the user for this pannel with the all the setted values
     */
    public IndicatorOption getOption();
}
