/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package webpages.pagePanels;

import data.model.BehaviourIndicator;
import data.model.IndicatorOption;
import org.apache.wicket.AttributeModifier;
import org.apache.wicket.ajax.AjaxRequestTarget;
import org.apache.wicket.ajax.form.AjaxFormComponentUpdatingBehavior;

import org.apache.wicket.markup.html.basic.Label;
import org.apache.wicket.markup.html.form.ChoiceRenderer;
import org.apache.wicket.markup.html.form.DropDownChoice;
import org.apache.wicket.markup.html.form.CheckBox;
import org.apache.wicket.markup.html.panel.Panel;
import org.apache.wicket.model.Model;
import org.apache.wicket.model.PropertyModel;

/**
 *
 * @author icerrr
 */
public class BehaviourDropList extends Panel implements BehaviourPanelInterface{

    Model<IndicatorOption> optionModel;
    Model<Boolean> hidden=new Model<Boolean>();

    Model<String> visibilityModel=new Model<String>("visibility:hidden;");
    Label optionDescriptionLabel=new Label( "optionDescription", new PropertyModel(this,"optionDescriptionText") ){
    { setOutputMarkupId( true );
      add(new AttributeModifier("style",visibilityModel));
    }
    };
    private String optionDescriptionText="No Option Selected";

        public BehaviourDropList(String id,BehaviourIndicator indicator)
        {
            super(id);

            if(indicator.getDescription()!=null)
            add(new Label("indicatorDescription",indicator.getDescription()));
            else
            {
              Label description=new Label("indicatorDescription","no description");
              description.setVisible(false);//will not draw actually
              add(description);
            }

            add(new Label("indicatorName",indicator.getDisplayName()));

            optionModel=new Model<IndicatorOption>();
            ChoiceRenderer aucr = new ChoiceRenderer("displayText", "optionValue");
            DropDownChoice options = new DropDownChoice("indicatorOption", optionModel,indicator.getOptions(),aucr);
            options.setRequired(true);
           // options.setNullValid(true);
            add(options);

            options.add(new AjaxFormComponentUpdatingBehavior("onchange") {
                @Override
                protected void onUpdate(AjaxRequestTarget target) {
                   
                    if(optionModel.getObject()!=null)
                                optionDescriptionText=((IndicatorOption)optionModel.getObject()).getDescription();

                    if(optionDescriptionText!=null && !optionDescriptionText.isEmpty())
                        {
                            visibilityModel.setObject("visibility:visible;");
                             target.appendJavascript("Nifty('span.optionDescription','small transparent');");
                        }
                       else
                        visibilityModel.setObject("visibility:hidden;");

                   target.addComponent(optionDescriptionLabel);
                  
                }
            });
            add(optionDescriptionLabel);

            CheckBox hiddenCheck;
            add(hiddenCheck=new CheckBox("hidden",hidden));

            hiddenCheck.add(new AjaxFormComponentUpdatingBehavior("onchange") {
            @Override
            protected void onUpdate(AjaxRequestTarget target) {
                //this is here just to update the checkbox
            }
        });
        }

        public IndicatorOption getOption()
        {
            optionModel.getObject().setHidden(hidden.getObject());
            return optionModel.getObject();
        }

//        public String getOptionDescriptionText()
//        {
//            return optionDescriptionText;
//        }
}

