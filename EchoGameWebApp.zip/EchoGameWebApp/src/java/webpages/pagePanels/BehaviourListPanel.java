/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package webpages.pagePanels;

import data.model.BehaviourIndicator;
import data.model.IndicatorOption;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.apache.wicket.markup.html.list.ListItem;
import org.apache.wicket.markup.html.list.ListView;
import org.apache.wicket.markup.html.panel.Panel;
import services.UserServices;
import webpages.CustomSession;
import webpages.WebGameApplication;

/**
 *
 * @author icerrr
 */
public class BehaviourListPanel extends Panel{

    LinkedList<Panel> panelList=new LinkedList<Panel>();
    List<BehaviourIndicator> behaviourList;

    public BehaviourListPanel(String id)
    {
        this(id,null);
    }

    public BehaviourListPanel(String id,List<BehaviourIndicator> uncompleated)
    {
        super(id);
        UserServices services=((WebGameApplication)WebGameApplication.get()).getUserServices();
        if(uncompleated==null || uncompleated.size()==0)
            behaviourList=services.getBehaviourIndicators();
        else behaviourList=uncompleated;
        
        add(new ListView("indicatorList",behaviourList)
        {

            @Override
            protected void populateItem(ListItem item) {
                BehaviourIndicator indicator=(BehaviourIndicator)item.getModelObject();
                try {
                    Class panelClass=indicator.getWicketClass();
                    Constructor construct = panelClass.getConstructor(new Class[]{String.class, BehaviourIndicator.class});
                    Panel newPanel=(Panel)construct.newInstance(new Object[]{"panelElement",indicator});
                    panelList.add(newPanel);
                    item.add(newPanel);
                    
                } catch (InstantiationException ex) {
                    Logger.getLogger(BehaviourListPanel.class.getName()).log(Level.SEVERE, null, ex);
                } catch (IllegalAccessException ex) {
                    Logger.getLogger(BehaviourListPanel.class.getName()).log(Level.SEVERE, null, ex);
                } catch (IllegalArgumentException ex) {
                    Logger.getLogger(BehaviourListPanel.class.getName()).log(Level.SEVERE, null, ex);
                } catch (InvocationTargetException ex) {
                    Logger.getLogger(BehaviourListPanel.class.getName()).log(Level.SEVERE, null, ex);
                } catch (NoSuchMethodException ex) {
                    Logger.getLogger(BehaviourListPanel.class.getName()).log(Level.SEVERE, null, ex);
                } catch (SecurityException ex) {
                    Logger.getLogger(BehaviourListPanel.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
            
        });
    }

    public List<IndicatorOption>  getSelectedOptions()
    {
        List<IndicatorOption> optionList=new  LinkedList<IndicatorOption>();
        
        Iterator<Panel> panelIterator=panelList.iterator();

        for(BehaviourIndicator indicator:behaviourList)
            if(panelIterator.hasNext())
            {
            try {
                Panel panel = panelIterator.next();
                Class panelClass = indicator.getWicketClass();
                Method optionReturnMethod = panelClass.getMethod("getOption", new Class[0]);
                optionList.add((IndicatorOption)optionReturnMethod.invoke(panelClass.cast(panel), new Object[0]));
            } catch (IllegalAccessException ex) {
                Logger.getLogger(BehaviourListPanel.class.getName()).log(Level.SEVERE, null, ex);
            } catch (IllegalArgumentException ex) {
                Logger.getLogger(BehaviourListPanel.class.getName()).log(Level.SEVERE, null, ex);
            } catch (InvocationTargetException ex) {
                Logger.getLogger(BehaviourListPanel.class.getName()).log(Level.SEVERE, null, ex);
            } catch (NoSuchMethodException ex) {
                Logger.getLogger(BehaviourListPanel.class.getName()).log(Level.SEVERE, null, ex);
            } catch (SecurityException ex) {
                Logger.getLogger(BehaviourListPanel.class.getName()).log(Level.SEVERE, null, ex);
            }
            }

        return optionList;
    }


}
