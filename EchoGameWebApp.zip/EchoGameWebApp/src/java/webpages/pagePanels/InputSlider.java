/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package webpages.pagePanels;

import data.model.Variable;
import org.apache.wicket.Application;
import org.apache.wicket.AttributeModifier;
import org.apache.wicket.behavior.AttributeAppender;
import org.apache.wicket.markup.html.CSSPackageResource;
import org.apache.wicket.markup.html.JavascriptPackageResource;
import org.apache.wicket.behavior.StringHeaderContributor;

import org.apache.wicket.markup.html.basic.Label;
import org.apache.wicket.markup.html.form.TextField;
import org.apache.wicket.markup.html.panel.Panel;
import org.apache.wicket.model.Model;
import webpages.WebGameApplication;


/**
 *
 * @author icerrr
 */
public class InputSlider extends Panel{


    private Model<Double> sliderValue;
    private Model<Integer> minValue;
    private Model<Integer> maxValue;
    private Model<Integer> discreteValue;
    private Model<String> dijitId;

    private boolean discrete;

    private Label slider;
    private TextField sliderValueField;

    public static final StringHeaderContributor SLIDER_CALLBACK_SCRIPT =
    new StringHeaderContributor("<script type=\"text/javascript\">" +
                                "function run(inputId){" +
                                "if(dojo.byId(inputId).timeout) clearTimeout(dojo.byId(inputId).timeout);" +
                                "dojo.byId(inputId).timeout=setTimeout(\"dojo.byId(\"+inputId+\").onchange()\",500);}" +
                        	"</script>");
   public static final StringHeaderContributor SLIDER_IMPORTS =
    new StringHeaderContributor("<script type=\"text/javascript\">"+
                                "dojo.require(\"dijit.form.Slider\");"+
//                                "dojo.require(\"dijit.form.TextBox\");"+
                                "</script>");

    public InputSlider(String id) 
    {
        super(id);
        sliderValue=new Model<Double>(0.0);
        init();
    }

    public InputSlider(String id,Model<Double> model)
    {
        super(id);
        sliderValue=model;
        init();
    }

    private void init() {

        //add the dojo headers and styles
        add(WebGameApplication.DOJO_CONFIG_HEADER_CONTRIBUTOR);
        add(JavascriptPackageResource.getHeaderContribution(Application.get().getMetaData(WebGameApplication.DOJO_DIST_LOCATION)));
        add(CSSPackageResource.getHeaderContribution(WebGameApplication.STYLE_THUNDRA_CONTRIBUTOR));
        add(SLIDER_CALLBACK_SCRIPT);
        add(SLIDER_IMPORTS);

        discreteValue= new Model(1);
        minValue=new Model(0);
        maxValue=new Model(10);
        dijitId=new Model<String>("default_slider_ID");

        add(sliderValueField=new TextField("sliderValue", sliderValue,Double.class));
        sliderValueField.setOutputMarkupId(true);
        
        slider=new Label("slider");
        add(slider);

    }

    @Override
    protected void onBeforeRender() {

        if(discrete) discreteValue.setObject(maxValue.getObject()-minValue.getObject()+1);
        else discreteValue.setObject(1);

        slider.add(new AttributeModifier("value", sliderValue));
        slider.add(new AttributeModifier("minimum", minValue));
        slider.add(new AttributeModifier("maximum", maxValue));
        if(discrete)  slider.add(new AttributeModifier("discreteValues",discreteValue));
        slider.add( new AttributeModifier("onChange",
                    new Model("dojo.byId('"+sliderValueField.getMarkupId()+"').value =  dojo.number.round(this.value,2);" +
                    "run('"+sliderValueField.getMarkupId()+"')")));
        slider.add( new AttributeModifier("id",dijitId));

        super.onBeforeRender();
    }


    public TextField getSliderValueField()
    {
        return sliderValueField;
    }

    /**
     * @return the sliderValue
     */
    public Model<Double> getSliderValue() {
        return sliderValue;
    }

    /**
     * @param sliderValue the sliderValue to set
     */
    public void setSliderValue(Model<Double> sliderValue) {
        this.sliderValue = sliderValue;
    }

    /**
     * @return the minValue
     */
    public int getMinValue() {
        return minValue.getObject();
    }

    /**
     * @param minValue the minValue to set
     */
    public void setMinValue(int minValue) {
        this.minValue.setObject(minValue);
        if(sliderValue.getObject()<minValue) sliderValue.setObject(new Double(minValue));
    }

    /**
     * @return the maxValue
     */
    public int getMaxValue() {
        return maxValue.getObject();
    }

    /**
     * @param maxValue the maxValue to set
     */
    public void setMaxValue(int maxValue) {
        this.maxValue.setObject(maxValue);
        if(sliderValue.getObject()>maxValue) sliderValue.setObject(new Double(maxValue));
    }

    /**
     * @return the discreteValues
     */
    public boolean isDiscreteValue() {
        return discrete;
    }

    /**
     * @param discreteValues the discreteValues to set
     */
    public void setDiscreteValue(boolean value) {
        this.discrete = value;
    }

    /**
     * Since Dijit uses non DOM objects for managing its widgets , setting the wicketMarkupId true will
     * cause wicket to associate different id's to DOM nodes destroying the digit references.
     * The folowing method provides a work around for this problem.
     * wicketSetMarkupId will be false and ids will have to be generated on the fly
     * @return the dijitId
     */
    public String getDijitId() {
        return dijitId.getObject();
    }

    /**
     * Since Dijit uses non DOM objects for managing its widgets , setting the wicketMarkupId true will
     * cause wicket to associate different id's to DOM nodes destroying the digit references.
     * The folowing method provides a work around for this problem.
     * wicketSetMarkupId will be false and ids will have to be generated on the fly
     * @param dijitId the dijitId to set
     */
    public void setDijitId(String dijitId) {
        this.dijitId.setObject(dijitId);
    }
}
