package webpages;


import data.model.GameUser;
import org.acegisecurity.Authentication;
import org.acegisecurity.GrantedAuthority;
import org.acegisecurity.context.SecurityContextHolder;
import org.acegisecurity.userdetails.UserDetails;

import org.apache.wicket.Request;
import org.apache.wicket.authentication.AuthenticatedWebSession;
import org.apache.wicket.authorization.strategies.role.Roles;

import java.util.concurrent.locks.ReentrantLock;


public class CustomSession extends AuthenticatedWebSession
{
  public static int test;
  public ReentrantLock sessionLock;
  public int lastSave;//

    public CustomSession(Request request)
    {
        super(request);
        sessionLock=new ReentrantLock();
    }


    public boolean authenticate(String username, String password)
    {
        if(((WebGameApplication)WebGameApplication.get()).getUserServices().authenticate(username, password))
        {
            //the admin user does not get counted
            if(!((GameUser)SecurityContextHolder.getContext().getAuthentication().getPrincipal()).getRole().getName().equals("ROLE_admin"))
                ((WebGameApplication)WebGameApplication.get()).addLoggedSession(username,getId());
            return true;
        }
       return false;
    }

    /**
     * Returns the current user roles.
     *
     * @return current user roles
     */
    public Roles getRoles()
    {
        if (isSignedIn())
        {
            Roles roles = new Roles();

            GrantedAuthority[] authorities = SecurityContextHolder.getContext().getAuthentication().getAuthorities();
            for (GrantedAuthority authority : authorities)
            {
                roles.add(authority.getAuthority());
            }
            return roles;
        }
        return null;
    }

    /**
     * @return the currently logged in username, or null when no user is logged in
     */
    public String getUserName()
    {
        String user = null;
        if (isSignedIn())
        {
            Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
            user = ((UserDetails) authentication.getPrincipal()).getUsername();
        }
        return user;
    }


    

    /**
     * Signout, invalidates the session. After a signout, you should redirect the browser to the home booking.page.
     */
    public void signout()
    {
        String user = getUserName();
        if (user != null)
        {
        }
        setAuthentication(null);
        invalidate();
        
    }


    private void setAuthentication(Authentication authentication)
    {
        SecurityContextHolder.getContext().setAuthentication(authentication);
    }

    public ReentrantLock getSessionLock()
    {
        return sessionLock;
    }

    /**
     * LastSave indicates the turn the user made his changes . 
     * It is used in order to prevent users form submitting multiple times for the same turn
     * @param turnNr
     */
    public void setLastSave(int turnNr)
    {
        this.lastSave=turnNr;
    }

    public boolean madeLastSave(int turnNr)
    {
        return lastSave==turnNr;
    }

}
