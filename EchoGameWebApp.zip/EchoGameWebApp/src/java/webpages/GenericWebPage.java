package webpages;

import org.apache.wicket.markup.html.WebPage;
import services.AdminService;
import services.UserServices;

/**
 * Code Framework
 * User: Alan P. Sexton
 * Date: 17-Mar-2008
 * Time: 09:55:43
 *
 * Author
 * User: Adrian Ionita
 * Date: 2-Jul-2010
 * Time: 3:38:00
 */
public class GenericWebPage extends WebPage
{
    public GenericWebPage()
    {
        super();
    }

    public CustomSession getCustomSession()
    {
        return (CustomSession)getSession();
    }

    public UserServices getUserServices()
    {
        return ((WebGameApplication)WebGameApplication.get()).getUserServices();
    }

    public AdminService getAdminService()
    {
        return ((WebGameApplication)WebGameApplication.get()).getAdminService();
    }

    public int getNumberOfLoggedUsers()
    {
        return ((WebGameApplication)WebGameApplication.get()).getNumberOfLoggedUsers();
    }
    
}
