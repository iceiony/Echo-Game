/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package webpages;

import org.apache.wicket.AttributeModifier;
import org.apache.wicket.ajax.AjaxRequestTarget;
import org.apache.wicket.authorization.strategies.role.annotations.AuthorizeInstantiation;
import org.apache.wicket.markup.html.WebMarkupContainer;
import org.apache.wicket.markup.html.basic.Label;
import org.apache.wicket.model.Model;
import webpages.adminPanels.AdminNotificationPanel;
import org.apache.wicket.ajax.AjaxSelfUpdatingTimerBehavior;
import org.apache.wicket.ajax.AjaxEventBehavior;
import org.apache.wicket.markup.html.form.Button;
import org.apache.wicket.util.time.Duration;
import webpages.pagePanels.InputSlider;
import java.text.DateFormat;
import java.util.Date;
import org.apache.wicket.protocol.https.RequireHttps;
import webpages.adminPanels.DinamicFileDownloadLink;
import webpages.pagePanels.ChatPanel;
/**
 *
 * @author icerrr
 */
@RequireHttps
@AuthorizeInstantiation({"ROLE_admin"})
public class AdminPage extends GenericWebPage {

    WebMarkupContainer infoContainer;
    Model userNumberModel;
    Model eliminatedNumberModel;
    Model remainingTimeModel;
    Model turnModel;

    Model confirmLabelStyleModel;
    Model confirmLabelTextModel;
    Model buttonValueModel;

    Model clearLabelStyleModel;

    private static final DateFormat df = DateFormat.getTimeInstance(DateFormat.SHORT);

    public AdminPage()
    {
        GameBorder border=new GameBorder("border");

        border.add(new AdminNotificationPanel("notificationPanel"));

        //info container : number of users logged and number of minutes remaining
        infoContainer=new WebMarkupContainer("infoContainer");
        infoContainer.setOutputMarkupId(true);
        infoContainer.add(new Label("nrUsers",userNumberModel=new Model(getNumberOfLoggedUsers())));
        int elminiated=((WebGameApplication)WebGameApplication.get()).getUserServices().getEliminatedNumber();
        infoContainer.add(new Label("nrEliminated",eliminatedNumberModel=new Model(new Integer(elminiated))));

        long remainingTime=((WebGameApplication)WebGameApplication.get()).getUserServices().getTimeRemaining();
        infoContainer.add(new Label("timeRemaining",
            remainingTimeModel=new Model(String.valueOf(remainingTime/60)+" min "+String.valueOf(remainingTime%60)+" s")));

        int turnNr=((WebGameApplication)WebGameApplication.get()).getUserServices().getTurnNumber();
        infoContainer.add(new Label("turnNr",turnModel=new Model(new Integer(turnNr))));

        infoContainer.add(new AjaxSelfUpdatingTimerBehavior(Duration.seconds(30))
        {

            @Override
            protected void onPostProcessTarget(AjaxRequestTarget target) {
                userNumberModel.setObject(getNumberOfLoggedUsers());
                int elminiated=((WebGameApplication)WebGameApplication.get()).getUserServices().getEliminatedNumber();
                eliminatedNumberModel.setObject(new Integer(elminiated));
                long remainingTime=((WebGameApplication)WebGameApplication.get()).getUserServices().getTimeRemaining();
                remainingTimeModel.setObject(String.valueOf(remainingTime/60)+" min "+String.valueOf(remainingTime%60)+" s");
                int turnNr=((WebGameApplication)WebGameApplication.get()).getUserServices().getTurnNumber();
                turnModel.setObject(new Integer(turnNr));
            }

        });
        border.add(infoContainer);
        add(border);

        //start game button
        if(((WebGameApplication)WebGameApplication.get()).getUserServices().hasGameStarted())
        {
             buttonValueModel=new Model("End Session");
             confirmLabelTextModel=new Model("Game Ended");
        }
        else
        {
            buttonValueModel=new Model("Start Session");
            confirmLabelTextModel=new Model("Game Started");
        }
        
        
        final Label startConfirmLabel=new Label("startConfirm",confirmLabelTextModel);
        startConfirmLabel.setOutputMarkupId(true);
        startConfirmLabel.add(new AttributeModifier("style",confirmLabelStyleModel=new Model("visibility:hidden")));
        
        border.add(startConfirmLabel);

        final Button startGameButton=new Button("startButton");
        startGameButton.setOutputMarkupId(true);
        startGameButton.add(new AjaxEventBehavior("onclick") {

            @Override
            protected void onEvent(AjaxRequestTarget target) {
               if(!((WebGameApplication)WebGameApplication.get()).getUserServices().hasGameStarted())
               {
                ((WebGameApplication)WebGameApplication.get()).getUserServices().startGameSession();
                confirmLabelStyleModel.setObject("visibility:visible");
                buttonValueModel.setObject("End Session");
                confirmLabelTextModel.setObject("Game Started");
                target.addComponent(startConfirmLabel);
                target.addComponent(startGameButton);
               }
               else
               {
                 ((WebGameApplication)WebGameApplication.get()).getUserServices().endGameSession();
                 confirmLabelStyleModel.setObject("visibility:visible");
                 buttonValueModel.setObject("Start Session");
                 confirmLabelTextModel.setObject("Game Ended");
                 target.addComponent(startConfirmLabel);
                 target.addComponent(startGameButton);
               }
            }
        });
        startGameButton.add(new AttributeModifier("value",buttonValueModel));
        border.add(startGameButton);

        final Label clearConfirm=new Label("clearConfirm");
        clearConfirm.add(new AttributeModifier("style",clearLabelStyleModel=new Model("visibility:hidden")));
        final Button clearLogsButton=new Button("clearButton");
         clearLogsButton.add(new AjaxEventBehavior("onclick") {

            @Override
            protected void onEvent(AjaxRequestTarget target) {
              ((WebGameApplication)WebGameApplication.get()).getAdminService().clearLogs();
              clearLabelStyleModel.setObject("visibility:visible");
              target.addComponent(clearConfirm);
            }
        });
        border.add(clearLogsButton);
        border.add(clearConfirm);
        //download Behavioru XLS file
        border.add(new DinamicFileDownloadLink("behaviourXLSLink","behaviour.xls"));
        border.add(new DinamicFileDownloadLink("logsXLSLink","logs.xls"));


        border.add(new ChatPanel("chatPanel"));
        
    }
}
