/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package webpages;

import org.apache.wicket.AttributeModifier;
import org.apache.wicket.markup.html.border.Border;
import org.apache.wicket.authorization.strategies.role.annotations.AuthorizeInstantiation;
import org.apache.wicket.markup.html.basic.Label;
import org.apache.wicket.markup.html.panel.Panel;
import org.apache.wicket.model.Model;
import org.apache.wicket.protocol.https.RequireHttps;
import webpages.pagePanels.ActivityPanel;
import webpages.pagePanels.ActivityProjectionsPanel;
import webpages.pagePanels.GlobalProjectionsPanel;
import webpages.pagePanels.InputSlider;
import webpages.pagePanels.NotificationPanel;
import webpages.pagePanels.StatsPanel;
import webpages.pagePanels.ChatPanel;
/**
 *
 * @author icerrr
 */
@RequireHttps
@AuthorizeInstantiation({"ROLE_user"})
public class Game extends GenericWebPage{

    public Game()
    {
        Border pageBorder=new GameBorder("border");
        add(pageBorder);

        StatsPanel statsPanel=new StatsPanel("statsPanel");
        pageBorder.add(statsPanel);

        ActivityPanel activityPanel=new ActivityPanel("activityPanel");
        pageBorder.add(activityPanel);

        ActivityProjectionsPanel projectionPanel;
        pageBorder.add(projectionPanel=new ActivityProjectionsPanel("activityProjections"));
        activityPanel.setProjectionPanel(projectionPanel);

        GlobalProjectionsPanel globalProjections=new GlobalProjectionsPanel("globalProjections");
        globalProjections.setActivityPanel(activityPanel);
        globalProjections.setStatsPanel(statsPanel);
        pageBorder.add(globalProjections);

        add(new NotificationPanel("notificationPanel"));

        //chat panel and controlls
        //the panel
        ChatPanel chatPanel;
        pageBorder.add(chatPanel=new ChatPanel("chatPanel"));
        chatPanel.setOutputMarkupId(true);
        //controlls
        Label showChatLink=new Label("showChatLink","Show/Hide Chat");
        Model<String> linkAction=new Model<String>("ShowHideChat('"+chatPanel.getMarkupId()+"')");
        showChatLink.add(new AttributeModifier("onclick",linkAction));

        //note the show button is inside the stats panel !!
        statsPanel.add(showChatLink);
    }
}
